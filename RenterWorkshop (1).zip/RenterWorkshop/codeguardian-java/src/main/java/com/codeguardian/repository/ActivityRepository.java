package com.codeguardian.repository;

import com.codeguardian.model.Activity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ActivityRepository extends JpaRepository<Activity, Long> {
    
    /**
     * Find activities by repository ID
     * @param repositoryId Repository ID
     * @return List of activities
     */
    List<Activity> findByRepositoryId(Long repositoryId);
    
    /**
     * Find activities by repository ID with pagination and order by createdAt
     * @param repositoryId Repository ID
     * @param pageable Pagination information
     * @return List of activities
     */
    List<Activity> findByRepositoryIdOrderByCreatedAtDesc(Long repositoryId, Pageable pageable);
    
    /**
     * Find activities by vulnerability ID
     * @param vulnerabilityId Vulnerability ID
     * @return List of activities
     */
    List<Activity> findByVulnerabilityId(Long vulnerabilityId);
    
    /**
     * Find activities by vulnerability ID with pagination and order by createdAt
     * @param vulnerabilityId Vulnerability ID
     * @param pageable Pagination information
     * @return List of activities
     */
    List<Activity> findByVulnerabilityIdOrderByCreatedAtDesc(Long vulnerabilityId, Pageable pageable);
    
    /**
     * Find all activities ordered by createdAt with pagination
     * @param pageable Pagination information
     * @return List of activities
     */
    List<Activity> findAllByOrderByCreatedAtDesc(Pageable pageable);
    
    /**
     * Find activities by action type
     * @param action Action type
     * @return List of activities
     */
    List<Activity> findByAction(String action);
    
    /**
     * Find latest activities for dashboard
     * @param limit Maximum number of activities to return
     * @return List of activities
     */
    @Query(value = "SELECT * FROM activities ORDER BY created_at DESC LIMIT :limit", nativeQuery = true)
    List<Activity> findLatestActivities(@Param("limit") int limit);
}