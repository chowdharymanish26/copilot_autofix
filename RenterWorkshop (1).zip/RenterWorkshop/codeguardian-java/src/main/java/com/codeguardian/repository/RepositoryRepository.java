package com.codeguardian.repository;

import com.codeguardian.model.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RepositoryRepository extends JpaRepository<Repository, Long> {
    
    /**
     * Find repository by name
     * @param name Repository name
     * @return Optional repository
     */
    Optional<Repository> findByName(String name);
    
    /**
     * Find repository by URL
     * @param url Repository URL
     * @return Optional repository
     */
    Optional<Repository> findByUrl(String url);
    
    /**
     * Count total number of repositories
     * @return Count of repositories
     */
    @Query("SELECT COUNT(r) FROM Repository r")
    Long countRepositories();
}