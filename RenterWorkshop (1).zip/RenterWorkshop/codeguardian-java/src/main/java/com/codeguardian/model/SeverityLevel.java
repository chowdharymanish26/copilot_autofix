package com.codeguardian.model;

/**
 * Represents severity levels for vulnerabilities
 */
public enum SeverityLevel {
    CRITICAL,
    HIGH,
    MEDIUM,
    LOW,
    INFO
}