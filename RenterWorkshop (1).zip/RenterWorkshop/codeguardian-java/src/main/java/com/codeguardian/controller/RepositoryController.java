package com.codeguardian.controller;

import com.codeguardian.model.dto.RepositoryDTO;
import com.codeguardian.service.RepositoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/repositories")
@RequiredArgsConstructor
@Slf4j
public class RepositoryController {
    
    private final RepositoryService repositoryService;
    
    /**
     * Get all repositories
     * @return List of repositories
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<RepositoryDTO>>> getAllRepositories() {
        log.debug("REST request to get all repositories");
        List<RepositoryDTO> repositories = repositoryService.getAllRepositories();
        return ResponseEntity.ok(ApiResponse.success(repositories));
    }
    
    /**
     * Get repository by ID
     * @param id Repository ID
     * @return Repository data
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<RepositoryDTO>> getRepository(@PathVariable Long id) {
        log.debug("REST request to get repository with id: {}", id);
        RepositoryDTO repository = repositoryService.getRepositoryById(id);
        return ResponseEntity.ok(ApiResponse.success(repository));
    }
    
    /**
     * Create a new repository
     * @param repositoryDTO Repository data
     * @return Created repository
     */
    @PostMapping
    public ResponseEntity<ApiResponse<RepositoryDTO>> createRepository(@Valid @RequestBody RepositoryDTO repositoryDTO) {
        log.debug("REST request to create repository: {}", repositoryDTO.getName());
        
        if (repositoryDTO.getId() != null) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("A new repository cannot already have an ID"));
        }
        
        RepositoryDTO result = repositoryService.createRepository(repositoryDTO);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(result, "Repository created successfully"));
    }
    
    /**
     * Update an existing repository
     * @param id Repository ID
     * @param repositoryDTO Updated repository data
     * @return Updated repository
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<RepositoryDTO>> updateRepository(
            @PathVariable Long id, 
            @Valid @RequestBody RepositoryDTO repositoryDTO) {
        log.debug("REST request to update repository with id: {}", id);
        
        if (repositoryDTO.getId() == null) {
            repositoryDTO.setId(id);
        } else if (!id.equals(repositoryDTO.getId())) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("ID in path doesn't match ID in request body"));
        }
        
        RepositoryDTO result = repositoryService.updateRepository(id, repositoryDTO);
        return ResponseEntity.ok(ApiResponse.success(result, "Repository updated successfully"));
    }
    
    /**
     * Delete a repository
     * @param id Repository ID
     * @return No content response
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRepository(@PathVariable Long id) {
        log.debug("REST request to delete repository with id: {}", id);
        repositoryService.deleteRepository(id);
        return ResponseEntity.noContent().build();
    }
}