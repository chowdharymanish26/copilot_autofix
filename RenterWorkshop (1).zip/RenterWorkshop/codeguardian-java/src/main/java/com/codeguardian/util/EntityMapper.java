package com.codeguardian.util;

import com.codeguardian.model.Activity;
import com.codeguardian.model.Repository;
import com.codeguardian.model.Vulnerability;
import com.codeguardian.model.dto.ActivityDTO;
import com.codeguardian.model.dto.RepositoryDTO;
import com.codeguardian.model.dto.VulnerabilityDTO;
import lombok.experimental.UtilityClass;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@UtilityClass
public class EntityMapper {

    public RepositoryDTO mapToDTO(Repository repository) {
        if (repository == null) {
            return null;
        }
        
        return RepositoryDTO.builder()
                .id(repository.getId())
                .name(repository.getName())
                .description(repository.getDescription())
                .url(repository.getUrl())
                .languages(repository.getLanguages())
                .lastScanned(repository.getLastScanned())
                .createdAt(repository.getCreatedAt())
                .updatedAt(repository.getUpdatedAt())
                .vulnerabilityCount((long) repository.getVulnerabilities().size())
                .build();
    }
    
    public Repository mapToEntity(RepositoryDTO dto) {
        if (dto == null) {
            return null;
        }
        
        return Repository.builder()
                .id(dto.getId())
                .name(dto.getName())
                .description(dto.getDescription())
                .url(dto.getUrl())
                .languages(dto.getLanguages())
                .lastScanned(dto.getLastScanned())
                .build();
    }
    
    public List<RepositoryDTO> mapToDTOList(List<Repository> repositories) {
        return repositories.stream()
                .map(EntityMapper::mapToDTO)
                .collect(Collectors.toList());
    }
    
    public VulnerabilityDTO mapToDTO(Vulnerability vulnerability) {
        if (vulnerability == null) {
            return null;
        }
        
        VulnerabilityDTO dto = VulnerabilityDTO.builder()
                .id(vulnerability.getId())
                .title(vulnerability.getTitle())
                .description(vulnerability.getDescription())
                .filePath(vulnerability.getFilePath())
                .lineNumber(vulnerability.getLineNumber())
                .columnNumber(vulnerability.getColumnNumber())
                .vulnerableCode(vulnerability.getVulnerableCode())
                .fixedCode(vulnerability.getFixedCode())
                .severity(vulnerability.getSeverity())
                .status(vulnerability.getStatus())
                .cweId(vulnerability.getCweId())
                .vulnerabilityType(vulnerability.getVulnerabilityType())
                .repositoryId(Optional.ofNullable(vulnerability.getRepository())
                        .map(Repository::getId)
                        .orElse(null))
                .repositoryName(Optional.ofNullable(vulnerability.getRepository())
                        .map(Repository::getName)
                        .orElse(null))
                .createdAt(vulnerability.getCreatedAt())
                .updatedAt(vulnerability.getUpdatedAt())
                .reviewedAt(vulnerability.getReviewedAt())
                .fixedAt(vulnerability.getFixedAt())
                .pullRequestUrl(vulnerability.getPullRequestUrl())
                .build();
        
        return dto;
    }
    
    public Vulnerability mapToEntity(VulnerabilityDTO dto, Repository repository) {
        if (dto == null) {
            return null;
        }
        
        return Vulnerability.builder()
                .id(dto.getId())
                .title(dto.getTitle())
                .description(dto.getDescription())
                .filePath(dto.getFilePath())
                .lineNumber(dto.getLineNumber())
                .columnNumber(dto.getColumnNumber())
                .vulnerableCode(dto.getVulnerableCode())
                .fixedCode(dto.getFixedCode())
                .severity(dto.getSeverity())
                .status(dto.getStatus())
                .cweId(dto.getCweId())
                .vulnerabilityType(dto.getVulnerabilityType())
                .repository(repository)
                .reviewedAt(dto.getReviewedAt())
                .fixedAt(dto.getFixedAt())
                .pullRequestUrl(dto.getPullRequestUrl())
                .build();
    }
    
    public List<VulnerabilityDTO> mapVulnerabilityToDTOList(List<Vulnerability> vulnerabilities) {
        return vulnerabilities.stream()
                .map(EntityMapper::mapToDTO)
                .collect(Collectors.toList());
    }
    
    public ActivityDTO mapToDTO(Activity activity) {
        if (activity == null) {
            return null;
        }
        
        ActivityDTO dto = ActivityDTO.builder()
                .id(activity.getId())
                .action(activity.getAction())
                .description(activity.getDescription())
                .repositoryId(Optional.ofNullable(activity.getRepository())
                        .map(Repository::getId)
                        .orElse(null))
                .repositoryName(Optional.ofNullable(activity.getRepository())
                        .map(Repository::getName)
                        .orElse(null))
                .vulnerabilityId(Optional.ofNullable(activity.getVulnerability())
                        .map(Vulnerability::getId)
                        .orElse(null))
                .vulnerabilityTitle(Optional.ofNullable(activity.getVulnerability())
                        .map(Vulnerability::getTitle)
                        .orElse(null))
                .entityType(activity.getEntityType())
                .entityId(activity.getEntityId())
                .createdAt(activity.getCreatedAt())
                .build();
        
        return dto;
    }
    
    public Activity mapToEntity(ActivityDTO dto, Repository repository, Vulnerability vulnerability) {
        if (dto == null) {
            return null;
        }
        
        return Activity.builder()
                .id(dto.getId())
                .action(dto.getAction())
                .description(dto.getDescription())
                .repository(repository)
                .vulnerability(vulnerability)
                .entityType(dto.getEntityType())
                .entityId(dto.getEntityId())
                .build();
    }
    
    public List<ActivityDTO> mapActivityToDTOList(List<Activity> activities) {
        return activities.stream()
                .map(EntityMapper::mapToDTO)
                .collect(Collectors.toList());
    }
}