package com.codeguardian.service.impl;

import com.codeguardian.model.Activity;
import com.codeguardian.model.Repository;
import com.codeguardian.model.Vulnerability;
import com.codeguardian.model.dto.ActivityDTO;
import com.codeguardian.repository.ActivityRepository;
import com.codeguardian.repository.RepositoryRepository;
import com.codeguardian.repository.VulnerabilityRepository;
import com.codeguardian.service.ActivityService;
import com.codeguardian.util.EntityMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ActivityServiceImpl implements ActivityService {

    private final ActivityRepository activityRepository;
    private final RepositoryRepository repositoryRepository;
    private final VulnerabilityRepository vulnerabilityRepository;

    @Override
    @Transactional(readOnly = true)
    public List<ActivityDTO> getAllActivities(Integer limit) {
        log.debug("Fetching all activities with limit: {}", limit);
        
        List<Activity> activities;
        if (limit != null && limit > 0) {
            Pageable pageable = PageRequest.of(0, limit);
            activities = activityRepository.findAllByOrderByCreatedAtDesc(pageable);
        } else {
            activities = activityRepository.findAll();
        }
        
        return EntityMapper.mapActivityToDTOList(activities);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ActivityDTO> getActivitiesByRepository(Long repositoryId, Integer limit) {
        log.debug("Fetching activities for repository id: {} with limit: {}", repositoryId, limit);
        
        List<Activity> activities;
        if (limit != null && limit > 0) {
            Pageable pageable = PageRequest.of(0, limit);
            activities = activityRepository.findByRepositoryIdOrderByCreatedAtDesc(repositoryId, pageable);
        } else {
            activities = activityRepository.findByRepositoryId(repositoryId);
        }
        
        return EntityMapper.mapActivityToDTOList(activities);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ActivityDTO> getActivitiesByVulnerability(Long vulnerabilityId, Integer limit) {
        log.debug("Fetching activities for vulnerability id: {} with limit: {}", vulnerabilityId, limit);
        
        List<Activity> activities;
        if (limit != null && limit > 0) {
            Pageable pageable = PageRequest.of(0, limit);
            activities = activityRepository.findByVulnerabilityIdOrderByCreatedAtDesc(vulnerabilityId, pageable);
        } else {
            activities = activityRepository.findByVulnerabilityId(vulnerabilityId);
        }
        
        return EntityMapper.mapActivityToDTOList(activities);
    }

    @Override
    @Transactional
    public ActivityDTO recordActivity(ActivityDTO activityDTO) {
        log.debug("Recording activity: {}", activityDTO.getAction());
        
        Repository repository = null;
        if (activityDTO.getRepositoryId() != null) {
            repository = repositoryRepository.findById(activityDTO.getRepositoryId()).orElse(null);
        }
        
        Vulnerability vulnerability = null;
        if (activityDTO.getVulnerabilityId() != null) {
            vulnerability = vulnerabilityRepository.findById(activityDTO.getVulnerabilityId()).orElse(null);
        }
        
        Activity activity = EntityMapper.mapToEntity(activityDTO, repository, vulnerability);
        activity = activityRepository.save(activity);
        
        return EntityMapper.mapToDTO(activity);
    }

    @Override
    @Transactional
    public ActivityDTO recordRepositoryActivity(String action, String description, Long repositoryId) {
        log.debug("Recording repository activity: {} for repository id: {}", action, repositoryId);
        
        ActivityDTO activityDTO = ActivityDTO.builder()
                .action(action)
                .description(description)
                .repositoryId(repositoryId)
                .entityType("Repository")
                .entityId(repositoryId)
                .build();
        
        return recordActivity(activityDTO);
    }

    @Override
    @Transactional
    public ActivityDTO recordVulnerabilityActivity(String action, String description, Long vulnerabilityId) {
        log.debug("Recording vulnerability activity: {} for vulnerability id: {}", action, vulnerabilityId);
        
        Vulnerability vulnerability = null;
        Long repositoryId = null;
        
        if (vulnerabilityId != null) {
            vulnerability = vulnerabilityRepository.findById(vulnerabilityId).orElse(null);
            if (vulnerability != null && vulnerability.getRepository() != null) {
                repositoryId = vulnerability.getRepository().getId();
            }
        }
        
        ActivityDTO activityDTO = ActivityDTO.builder()
                .action(action)
                .description(description)
                .vulnerabilityId(vulnerabilityId)
                .repositoryId(repositoryId)
                .entityType("Vulnerability")
                .entityId(vulnerabilityId)
                .build();
        
        return recordActivity(activityDTO);
    }
}