package com.codeguardian.service;

import com.codeguardian.model.dto.DashboardStatsDTO;

public interface DashboardService {
    
    /**
     * Get dashboard statistics
     * @return Dashboard statistics
     */
    DashboardStatsDTO getDashboardStats();
}