package com.codeguardian.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Data Transfer Object for Repository entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RepositoryDTO {
    
    private Long id;
    private String name;
    private String description;
    private String url;
    private List<String> languages;
    private LocalDateTime lastScanned;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    // Statistics
    private Long vulnerabilityCount;
    private Long openVulnerabilityCount;
    private Long fixedVulnerabilityCount;
}