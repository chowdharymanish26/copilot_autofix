package com.codeguardian.service;

import com.codeguardian.model.dto.RepositoryDTO;
import java.util.List;

public interface RepositoryService {
    
    /**
     * Get all repositories
     * @return List of repositories
     */
    List<RepositoryDTO> getAllRepositories();
    
    /**
     * Get repository by ID
     * @param id Repository ID
     * @return Repository data
     */
    RepositoryDTO getRepositoryById(Long id);
    
    /**
     * Create a new repository
     * @param repositoryDTO Repository data
     * @return Created repository
     */
    RepositoryDTO createRepository(RepositoryDTO repositoryDTO);
    
    /**
     * Update an existing repository
     * @param id Repository ID
     * @param repositoryDTO Updated repository data
     * @return Updated repository
     */
    RepositoryDTO updateRepository(Long id, RepositoryDTO repositoryDTO);
    
    /**
     * Delete a repository
     * @param id Repository ID
     */
    void deleteRepository(Long id);
    
    /**
     * Update the lastScanned timestamp of a repository
     * @param id Repository ID
     * @return Updated repository
     */
    RepositoryDTO updateLastScanned(Long id);
}