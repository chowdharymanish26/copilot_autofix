# Architecture Documentation

## Overview

CodeGuardian is a comprehensive code vulnerability scanning and fixing tool. The application detects security vulnerabilities in code repositories, suggests fixes, and allows users to review and remediate issues. It includes features such as automated vulnerability detection, code analysis, fix suggestions, and a dashboard for monitoring security status.

The system is built as a full-stack application with a modern React frontend and a dual-backend approach, supporting both Node.js/Express and Java/Spring Boot implementations.

## System Architecture

CodeGuardian follows a client-server architecture with the following major components:

1. **Client** - A React-based frontend application built with Vite
2. **Server** - Two implementation options:
   - Node.js/Express backend (primary implementation)
   - Java Spring Boot backend (alternative implementation)
3. **Database** - PostgreSQL database accessed through:
   - Drizzle ORM (Node.js implementation)
   - Spring Data JPA (Java implementation)

The system uses a shared schema approach, where the database structure is defined in a common location and used by both implementations. This enables consistent data modeling regardless of which backend is deployed.

### Architecture Diagram

```
┌─────────────────────┐     ┌──────────────────────┐     ┌─────────────────┐
│                     │     │                      │     │                 │
│  React Frontend     │────▶│  Express/Spring API  │────▶│  PostgreSQL DB  │
│  (Vite + TailwindCSS)│    │  (Node.js/Java)      │     │                 │
│                     │◀────│                      │◀────│                 │
└─────────────────────┘     └──────────────────────┘     └─────────────────┘
```

## Key Components

### Frontend Architecture

The frontend is built with React and uses the following key technologies:

1. **UI Framework**: 
   - Uses a custom UI component library (shadcn-ui based on Radix UI primitives)
   - Styled with TailwindCSS
   - Follows a component-based architecture

2. **State Management**:
   - Leverages React Query (@tanstack/react-query) for server state management
   - Uses React hooks for local state management

3. **Routing**:
   - Implemented with Wouter, a lightweight router for React

4. **Key Pages**:
   - Dashboard - Overview statistics and recent activities
   - Repositories - Management of code repositories 
   - Vulnerabilities - Review and manage detected vulnerabilities

### Backend Architecture

The application supports two backend implementations:

#### Node.js/Express Backend (Primary)

1. **API Layer**:
   - RESTful API endpoints defined in `server/routes.ts`
   - Standard Express middleware pattern

2. **Service Layer**:
   - Code analysis logic in `server/codeAnalyzer.ts`
   - Data access through `server/storage.ts`

3. **Database Access**:
   - Uses Drizzle ORM for type-safe database queries
   - Database schema defined in `shared/schema.ts`

#### Java/Spring Boot Backend (Alternative)

1. **API Layer**:
   - REST controllers in `controller` package
   - Standardized API responses

2. **Service Layer**:
   - Implements business logic and code analysis
   - Interface-based design with separate implementations

3. **Repository Layer**:
   - Spring Data JPA repositories for database access
   - Repository interfaces extend JpaRepository

4. **Model Layer**:
   - Entity classes mapped to database tables
   - DTOs for API request/response 

### Database Schema

The database schema includes the following key entities:

1. **Repositories**:
   - Stores information about code repositories
   - Properties include name, description, URL, languages, and scan status

2. **Vulnerabilities**:
   - Records detected security issues
   - Includes severity, status, file path, line number, and remediation details

3. **Activities**:
   - Logs user and system actions
   - Enables activity tracking and audit trail

4. **Users**:
   - Stores user accounts and authentication details
   - Present in Java implementation but not fully implemented in Node.js version

## Data Flow

### Vulnerability Detection Flow

1. User adds a repository for scanning
2. The system clones/analyzes the repository code
3. The code analyzer identifies potential vulnerabilities
4. Detected issues are stored in the database
5. The system suggests possible fixes for each vulnerability
6. Users review the vulnerabilities and approve/reject suggested fixes
7. For approved fixes, the system can generate pull requests (PR)

### API Structure

The API follows a RESTful design with these main endpoints:

1. **Repository Management**:
   - `GET /api/repositories` - List all repositories
   - `GET /api/repositories/:id` - Get repository details
   - `POST /api/repositories` - Add a new repository
   - `PATCH /api/repositories/:id` - Update repository

2. **Vulnerability Management**:
   - `GET /api/vulnerabilities` - List vulnerabilities
   - `GET /api/vulnerabilities/:id` - Get vulnerability details
   - `PATCH /api/vulnerabilities/:id` - Update vulnerability status

3. **Code Analysis**:
   - `POST /api/analyze` - Analyze code for vulnerabilities
   - `POST /api/scan/:repositoryId` - Scan entire repository

4. **Dashboard**:
   - `GET /api/stats` - Get dashboard statistics

## External Dependencies

### Frontend Dependencies

1. **UI Components**:
   - Radix UI primitives (@radix-ui/*)
   - Lucide React for icons
   - Class Variance Authority (cva) for component variants

2. **Data Fetching**:
   - TanStack Query (@tanstack/react-query)

3. **Styling**:
   - TailwindCSS
   - PostCSS

### Backend Dependencies

1. **Node.js Backend**:
   - Express.js for API server
   - Drizzle ORM for database access
   - Zod for validation

2. **Java Backend**:
   - Spring Boot framework
   - Spring Data JPA
   - Lombok for boilerplate reduction
   - PostgreSQL JDBC driver

### Database

- PostgreSQL accessed via:
  - Neon Serverless Postgres (@neondatabase/serverless)
  - Drizzle ORM (Node.js)
  - Spring Data JPA (Java)

## Deployment Strategy

The application is configured for deployment on Replit with a strategy that supports continuous development:

1. **Development Mode**:
   - `npm run dev` starts the development server
   - Uses Vite for hot module reloading
   - Serves the frontend from Vite dev server

2. **Production Build**:
   - Frontend: Vite builds static assets
   - Backend: esbuild bundles the server code
   - Combined into a single distribution

3. **Production Runtime**:
   - Node.js Express server serves both API and static assets
   - Environment variables used for configuration
   - Production optimizations enabled

### Environment Configuration

- `NODE_ENV` - Controls development/production modes
- `DATABASE_URL` - PostgreSQL connection string
- Additional configuration in application properties (Java version)

## Design Decisions and Rationale

1. **Dual Backend Implementation**:
   - **Decision**: Support both Node.js/Express and Java/Spring Boot backends
   - **Rationale**: Provides flexibility for different deployment scenarios and team expertise
   - **Pros**: Demonstrates interoperability, supports diverse technology stacks
   - **Cons**: Increases maintenance burden, requires synchronization of features

2. **Shared Schema Approach**:
   - **Decision**: Define data schema in a central location
   - **Rationale**: Ensures consistency between frontend, Node.js, and Java implementations
   - **Pros**: Single source of truth for data structures, facilitates consistency
   - **Cons**: Requires careful coordination when making schema changes

3. **React Query for State Management**:
   - **Decision**: Use React Query for server state
   - **Rationale**: Simplifies data fetching, caching, and synchronization
   - **Pros**: Reduces boilerplate, handles loading/error states, provides caching
   - **Cons**: Adds dependency and learning curve

4. **Component-Based UI Architecture**:
   - **Decision**: Use shadcn/ui approach with Radix UI primitives
   - **Rationale**: Provides accessible, composable components without third-party dependency
   - **Pros**: Highly customizable, accessible by default, reduces bundle size
   - **Cons**: Requires more initial setup than using a complete UI library

5. **Vulnerability Scanning Approach**:
   - **Decision**: Pattern-based code analysis with remediation suggestions
   - **Rationale**: Balance between accuracy and implementation complexity
   - **Pros**: Provides valuable security insights without complex analysis engines
   - **Cons**: May produce false positives/negatives compared to advanced tools