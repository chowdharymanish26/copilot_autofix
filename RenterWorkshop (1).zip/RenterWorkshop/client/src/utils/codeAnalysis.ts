import { VulnerabilityStatus } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

/**
 * Helper function to log to console
 */
export function logDebug(message: string, data?: any) {
  console.log(`[DEBUG] ${message}`, data || "");
}

/**
 * Updates the status of a vulnerability
 * @param vulnerabilityId Vulnerability ID
 * @param status New status
 */
export async function updateVulnerabilityStatus(vulnerabilityId: number, status: VulnerabilityStatus) {
  try {
    logDebug(`Updating vulnerability ${vulnerabilityId} to status ${status}`);
    const result = await apiRequest('PATCH', `/api/vulnerabilities/${vulnerabilityId}`, { status });
    logDebug('Update result', result);
    return result;
  } catch (error) {
    console.error("Error updating vulnerability status:", error);
    throw error;
  }
}

/**
 * Creates a pull request for a vulnerability fix and pushes the changes
 * to the vulnerable repository
 * @param vulnerabilityId Vulnerability ID
 * @returns The PR details
 */
export async function createPullRequest(vulnerabilityId: number) {
  try {
    logDebug(`Creating pull request for vulnerability ${vulnerabilityId}`);
    
    // Define the response type
    interface PushFixResult {
      success: boolean;
      message: string;
      prNumber: number;
      prUrl: string;
      prTitle: string;
      prBody: string;
      branch: string;
    }
    
    // Call the backend to create and push a PR with the fix
    const result = await apiRequest<PushFixResult>('POST', `/api/push-fix/${vulnerabilityId}`);
    
    if (!result || !result.success) {
      throw new Error(result?.message || "Failed to create pull request");
    }
    
    return {
      number: result.prNumber,
      url: result.prUrl,
      title: result.prTitle,
      body: result.prBody
    };
  } catch (error) {
    console.error("Error creating pull request:", error);
    throw error;
  }
}

/**
 * Scans a repository by fetching and analyzing code from GitHub
 * Focuses on Java files for vulnerability detection
 * Uses multiple scanning methods: pattern-based, CodeQL, and Snyk (with hardcoded token)
 * @param repositoryId Repository ID
 * @param options Optional params like GitHub token
 * @returns The scan results
 */
export async function scanRepository(
  repositoryId: number, 
  options?: { 
    githubToken?: string;
  }
): Promise<any> {
  try {
    logDebug(`Scanning repository ${repositoryId}`);
    
    // Prepare request body with GitHub token if provided
    const body: Record<string, any> = {};
    if (options?.githubToken) body.githubToken = options.githubToken;
    
    // Make the request with GitHub token if provided
    const result = await apiRequest<{
      success: boolean;
      vulnerabilitiesFound: number;
      codeQLUsed?: boolean;
      codeQLFindings?: number;
      snykUsed?: boolean;
      snykFindings?: number;
      message: string;
    }>('POST', `/api/scan/${repositoryId}`, Object.keys(body).length ? body : undefined);
    
    // Log results for debugging
    if (result.codeQLUsed) {
      logDebug(`CodeQL analysis found ${result.codeQLFindings} vulnerabilities`);
    }
    
    if (result.snykUsed) {
      logDebug(`Snyk analysis found ${result.snykFindings} vulnerabilities`);
    }
    
    if (!result.codeQLUsed && !result.snykUsed) {
      logDebug('Pattern-based scanning only (advanced scanning not available)');
    }
    
    return result;
  } catch (error) {
    console.error("Error scanning repository:", error);
    throw error;
  }
}

/**
 * Analyzes code for a specific repository
 * @param code Source code to analyze
 * @param filePath Path to the file
 * @param repositoryId Repository ID
 * @returns The analysis result
 */
export async function analyzeCode(code: string, filePath: string, repositoryId: number) {
  try {
    logDebug(`Analyzing code for repository ${repositoryId}`);
    const result = await apiRequest<{
      vulnerabilitiesFound: number;
      vulnerabilities: any[];
      message?: string;
    }>('POST', '/api/analyze', { 
      code, 
      filePath, 
      repositoryId 
    });
    return result;
  } catch (error) {
    console.error("Error analyzing code:", error);
    throw error;
  }
}