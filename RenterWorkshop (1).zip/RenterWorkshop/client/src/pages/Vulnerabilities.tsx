import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import VulnerabilityItem from "@/components/VulnerabilityItem";
import VulnerabilityDetails from "@/components/VulnerabilityDetails";
import { Vulnerability, VulnerabilityStatus } from "@shared/schema";
import { CheckCircle, XCircle, Clock, AlertTriangle } from "lucide-react";

export default function Vulnerabilities() {
  const [selectedVulnerabilityId, setSelectedVulnerabilityId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<VulnerabilityStatus | "all">("all");
  const [activeTab, setActiveTab] = useState("all");
  
  // Fetch all vulnerabilities
  const { data: vulnerabilities, isLoading } = useQuery({
    queryKey: ['/api/vulnerabilities'],
  });
  
  // Filter vulnerabilities based on status
  const filteredVulnerabilities = vulnerabilities?.filter((v: Vulnerability) => {
    if (statusFilter === "all") return true;
    return v.status === statusFilter;
  });
  
  // Get selected vulnerability details
  const selectedVulnerability = vulnerabilities?.find(
    (v: Vulnerability) => v.id === selectedVulnerabilityId
  );
  
  // Get count for each status
  const getCounts = () => {
    if (!vulnerabilities) return { all: 0, open: 0, pendingReview: 0, approved: 0, rejected: 0, fixed: 0 };
    
    return {
      all: vulnerabilities.length,
      open: vulnerabilities.filter((v: Vulnerability) => v.status === VulnerabilityStatus.OPEN).length,
      pendingReview: vulnerabilities.filter((v: Vulnerability) => v.status === VulnerabilityStatus.PENDING_REVIEW).length,
      approved: vulnerabilities.filter((v: Vulnerability) => v.status === VulnerabilityStatus.APPROVED).length,
      rejected: vulnerabilities.filter((v: Vulnerability) => v.status === VulnerabilityStatus.REJECTED).length,
      fixed: vulnerabilities.filter((v: Vulnerability) => v.status === VulnerabilityStatus.FIXED).length
    };
  };
  
  const counts = getCounts();
  
  // Map tab to status filter
  const tabToStatus: Record<string, VulnerabilityStatus | "all"> = {
    all: "all",
    open: VulnerabilityStatus.OPEN,
    pendingReview: VulnerabilityStatus.PENDING_REVIEW,
    approved: VulnerabilityStatus.APPROVED,
    rejected: VulnerabilityStatus.REJECTED,
    fixed: VulnerabilityStatus.FIXED
  };
  
  // Handle tab change
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setStatusFilter(tabToStatus[tab]);
  };
  
  return (
    <>
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Vulnerabilities</h1>
        <p className="text-gray-600">Review and manage security vulnerabilities across all repositories</p>
      </div>
      
      {/* Tabs */}
      <Tabs defaultValue="all" value={activeTab} onValueChange={handleTabChange} className="mb-6">
        <TabsList className="grid grid-cols-6 w-full">
          <TabsTrigger value="all">
            All ({counts.all})
          </TabsTrigger>
          <TabsTrigger value="open">
            <AlertTriangle className="h-4 w-4 mr-1" /> Open ({counts.open})
          </TabsTrigger>
          <TabsTrigger value="pendingReview">
            <Clock className="h-4 w-4 mr-1" /> Pending ({counts.pendingReview})
          </TabsTrigger>
          <TabsTrigger value="approved">
            <CheckCircle className="h-4 w-4 mr-1" /> Approved ({counts.approved})
          </TabsTrigger>
          <TabsTrigger value="rejected">
            <XCircle className="h-4 w-4 mr-1" /> Rejected ({counts.rejected})
          </TabsTrigger>
          <TabsTrigger value="fixed">
            <i className="ri-checkbox-circle-line mr-1"></i> Fixed ({counts.fixed})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab} className="mt-6">
          <div className="bg-white rounded-lg shadow overflow-hidden">
            {/* Table Header */}
            <div className="border-b border-gray-200 bg-gray-50 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              <div className="grid grid-cols-12 gap-4">
                <div className="col-span-5">Issue</div>
                <div className="col-span-2">Severity</div>
                <div className="col-span-3">Repository</div>
                <div className="col-span-2">Actions</div>
              </div>
            </div>

            {/* Table Body */}
            <div>
              {isLoading ? (
                // Skeleton loaders
                Array(5).fill(0).map((_, index) => (
                  <div key={index} className="border-b border-gray-200 px-6 py-4">
                    <div className="grid grid-cols-12 gap-4 items-center">
                      <div className="col-span-5">
                        <Skeleton className="h-5 w-48 mb-2" />
                        <Skeleton className="h-4 w-72" />
                      </div>
                      <div className="col-span-2">
                        <Skeleton className="h-6 w-16 rounded-full" />
                      </div>
                      <div className="col-span-3">
                        <Skeleton className="h-4 w-24" />
                      </div>
                      <div className="col-span-2">
                        <Skeleton className="h-8 w-16 rounded" />
                      </div>
                    </div>
                  </div>
                ))
              ) : filteredVulnerabilities?.length ? (
                // Actual vulnerabilities
                filteredVulnerabilities.map((vulnerability: Vulnerability) => (
                  <VulnerabilityItem
                    key={vulnerability.id}
                    vulnerability={vulnerability}
                    onReview={(id) => setSelectedVulnerabilityId(id)}
                  />
                ))
              ) : (
                // Empty state
                <div className="px-6 py-8 text-center">
                  <p className="text-gray-500">No vulnerabilities found with the selected filter</p>
                </div>
              )}
            </div>

            {/* Expanded Vulnerability Details */}
            {selectedVulnerability && (
              <VulnerabilityDetails
                vulnerability={selectedVulnerability}
                onClose={() => setSelectedVulnerabilityId(null)}
              />
            )}
          </div>
        </TabsContent>
      </Tabs>
    </>
  );
}
