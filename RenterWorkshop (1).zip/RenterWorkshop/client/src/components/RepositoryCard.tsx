import { Card } from "@/components/ui/card";
import { Repository } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

interface RepositoryCardProps {
  repository: Repository;
  onClick?: () => void;
}

// Get status badge based on issue count
const getStatusBadge = (issueCount: number) => {
  if (issueCount === 0) {
    return {
      text: "Secure",
      classes: "bg-success-50 text-success-700"
    };
  } else if (issueCount <= 2) {
    return {
      text: `${issueCount} issue${issueCount === 1 ? "" : "s"}`,
      classes: "bg-warning-50 text-warning-700"
    };
  } else {
    return {
      text: `${issueCount} issues`,
      classes: "bg-danger-50 text-danger-700"
    };
  }
};

// Language badge colors
const getLanguageBadgeColor = (language: string) => {
  switch (language.toLowerCase()) {
    case 'javascript':
      return 'bg-blue-100 text-blue-800';
    case 'typescript':
      return 'bg-blue-100 text-blue-800';
    case 'python':
      return 'bg-green-100 text-green-800';
    case 'java':
      return 'bg-red-100 text-red-800';
    case 'node.js':
    case 'nodejs':
      return 'bg-green-100 text-green-800';
    case 'react':
      return 'bg-purple-100 text-purple-800';
    case 'vue':
      return 'bg-green-100 text-green-800';
    case 'angular':
      return 'bg-red-100 text-red-800';
    case 'spring':
      return 'bg-gray-100 text-gray-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export default function RepositoryCard({ repository, onClick }: RepositoryCardProps) {
  const statusBadge = getStatusBadge(repository.issueCount || 0);
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow duration-200" onClick={onClick}>
      <div className="p-4 border-b border-gray-200">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <i className="ri-github-fill text-gray-700 mr-2 text-lg"></i>
            <h3 className="font-medium text-gray-900">{repository.name}</h3>
          </div>
          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusBadge.classes}`}>
            {statusBadge.text}
          </span>
        </div>
        <p className="mt-2 text-sm text-gray-600">{repository.description || "No description available"}</p>
      </div>
      <div className="p-4 bg-gray-50">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-gray-500">Languages:</span>
          <div className="flex space-x-1 flex-wrap justify-end">
            {repository.languages?.map((language, index) => (
              <Badge key={index} variant="outline" className={`${getLanguageBadgeColor(language)} text-xs`}>
                {language}
              </Badge>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">Last scan:</span>
          <span className="text-xs text-gray-700">
            {repository.lastScanDate 
              ? new Date(repository.lastScanDate).toLocaleDateString() 
              : "Never"}
          </span>
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="text-xs text-gray-500">Sample code:</span>
          <span className="text-xs text-gray-700">
            {repository.code ? "Available" : "None"}
          </span>
        </div>
        
        {/* Scan methods badges */}
        {repository.lastScanDate && (
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-gray-500">Scan methods:</span>
            <div className="flex space-x-1">
              {/* Always show basic pattern scanning */}
              <Badge className="bg-blue-100 text-blue-800 text-xs">
                Pattern Scan
              </Badge>
              
              {/* Show CodeQL badge if used */}
              {repository.codeQLUsed && (
                <Badge className="bg-purple-100 text-purple-800 text-xs">
                  CodeQL
                </Badge>
              )}
              
              {/* Show Snyk badge if used */}
              {repository.snykUsed && (
                <Badge className="bg-green-100 text-green-800 text-xs">
                  Snyk
                </Badge>
              )}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
