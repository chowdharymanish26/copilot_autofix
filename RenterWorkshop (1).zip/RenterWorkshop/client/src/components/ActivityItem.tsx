import { Activity } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface ActivityItemProps {
  activity: Activity;
}

// Icon mapping for activity types
const getActivityIcon = (type: string) => {
  switch (true) {
    case type.includes('pull_request'):
      return { icon: "ri-git-pull-request-line", bgColor: "bg-success-50", textColor: "text-success-600" };
    case type.includes('scan'):
      return { icon: "ri-radar-line", bgColor: "bg-warning-50", textColor: "text-warning-600" };
    case type.includes('repository'):
      return { icon: "ri-git-repository-line", bgColor: "bg-primary-50", textColor: "text-primary-600" };
    case type.includes('vulnerability_detected'):
      return { icon: "ri-shield-flash-line", bgColor: "bg-danger-50", textColor: "text-danger-600" };
    case type.includes('fix_approved'):
      return { icon: "ri-check-line", bgColor: "bg-success-50", textColor: "text-success-600" };
    case type.includes('fix_rejected'):
      return { icon: "ri-close-line", bgColor: "bg-danger-50", textColor: "text-danger-600" };
    default:
      return { icon: "ri-information-line", bgColor: "bg-gray-50", textColor: "text-gray-600" };
  }
};

export default function ActivityItem({ activity }: ActivityItemProps) {
  const { icon, bgColor, textColor } = getActivityIcon(activity.activityType);
  
  return (
    <div className="p-4 flex items-start space-x-4">
      <div className={`flex-shrink-0 ${bgColor} p-2 rounded-full`}>
        <i className={`${icon} ${textColor}`}></i>
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-gray-900">
          {activity.description}
        </p>
        <p className="text-sm text-gray-500">
          {activity.timestamp ? formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true }) : "Just now"}
        </p>
      </div>
    </div>
  );
}
