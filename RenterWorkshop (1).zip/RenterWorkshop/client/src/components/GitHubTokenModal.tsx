import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GitBranch } from "lucide-react";

interface GitHubTokenModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (token: string) => void;
  isPending: boolean;
}

export default function GitHubTokenModal({ isOpen, onClose, onSubmit, isPending }: GitHubTokenModalProps) {
  const [token, setToken] = useState('');

  const handleSubmit = () => {
    if (token.trim()) {
      onSubmit(token.trim());
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5 text-green-600" />
            GitHub Authentication Required
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="text-sm text-gray-600">
            <p>
              To push fixes to the GitHub repository, CodeGuardian needs a personal access token with
              repository write permissions.
            </p>
            <ul className="list-disc ml-6 mt-2 space-y-1">
              <li>The token is used only for this operation</li>
              <li>It's not stored on our servers</li>
              <li>Your token remains secure</li>
            </ul>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="token">GitHub Personal Access Token</Label>
            <Input
              id="token"
              type="password"
              placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
              value={token}
              onChange={(e) => setToken(e.target.value)}
            />
            <p className="text-xs text-gray-500">
              Need a token? 
              <a 
                href="https://github.com/settings/tokens/new" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-800 ml-1"
              >
                Create one here
              </a>
              . Ensure it has "repo" scope.
            </p>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isPending}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={!token.trim() || isPending}
            className="bg-green-600 hover:bg-green-700"
          >
            {isPending ? "Submitting..." : "Submit Token & Push Fix"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}