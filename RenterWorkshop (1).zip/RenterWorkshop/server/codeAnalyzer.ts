import { SeverityLevel, VulnerabilityStatus, InsertVulnerability } from '@shared/schema';

// This is a simple implementation of a code analyzer that would typically
// use AST parsing libraries and more sophisticated pattern matching
export class CodeAnalyzer {
  
  // Common vulnerability patterns to detect
  private patterns = {
    // Add Java-specific vulnerability types first
    javaXXE: {
      patterns: [
        // Java XML parsers without secure processing
        /DocumentBuilderFactory\s+\w+\s*=\s*DocumentBuilderFactory\.newInstance\(\)/i,
        /SAXParserFactory\s+\w+\s*=\s*SAXParserFactory\.newInstance\(\)/i,
        /XMLInputFactory\s+\w+\s*=\s*XMLInputFactory\.newInstance\(\)/i,
        /DocumentBuilder\s+\w+\s*=\s*\w+\.newDocumentBuilder\(\)/i,
        /SAXParser\s+\w+\s*=\s*\w+\.newSAXParser\(\)/i,
        /XMLStreamReader\s+\w+\s*=\s*\w+\.createXMLStreamReader\(/i,
        /\.parse\(\s*new\s+File\(/i,
        /\.parse\(\s*new\s+FileInputStream\(/i,
        /\.parse\(\s*new\s+InputSource\(/i,
        /\.parse\(\s*new\s+StreamSource\(/i,
      ],
      fix: (code: string): string => {
        let fixedCode = code;
        
        // Fix DocumentBuilderFactory
        if (code.includes('DocumentBuilderFactory')) {
          fixedCode = fixedCode.replace(
            /(DocumentBuilderFactory\s+\w+\s*=\s*DocumentBuilderFactory\.newInstance\(\))/i,
            '$1;\n  $1.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);\n  $1.setExpandEntityReferences(false)'
          );
        }
        
        // Fix SAXParserFactory
        if (code.includes('SAXParserFactory')) {
          fixedCode = fixedCode.replace(
            /(SAXParserFactory\s+\w+\s*=\s*SAXParserFactory\.newInstance\(\))/i,
            '$1;\n  $1.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true)'
          );
        }
        
        // Fix XMLInputFactory
        if (code.includes('XMLInputFactory')) {
          fixedCode = fixedCode.replace(
            /(XMLInputFactory\s+\w+\s*=\s*XMLInputFactory\.newInstance\(\))/i,
            '$1;\n  $1.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);\n  $1.setProperty(XMLInputFactory.SUPPORT_DTD, false)'
          );
        }
        
        return fixedCode;
      },
      severity: SeverityLevel.HIGH,
      title: "XML External Entity (XXE) Vulnerability",
      description: "Insecure XML processing allows XXE attacks",
      potentialImpact: [
        "Server-side request forgery",
        "Local file disclosure",
        "Denial of service",
        "Server-side code execution"
      ],
      recommendations: [
        "Enable secure processing features",
        "Disable external entity resolution",
        "Use the latest XML parsers",
        "Implement XML parsing security best practices"
      ]
    },
    
    javaCommandInjection: {
      patterns: [
        // Java command injection patterns
        /Runtime\.getRuntime\(\)\.exec\(/i,
        /ProcessBuilder\s+\w+\s*=\s*new\s+ProcessBuilder\(/i,
        /ProcessBuilder\(\s*.*\+/i,
        /\.exec\(\s*.*\+/i,
        /\.command\(\s*.*\+/i,
        /\.command\(.*\.split\(/i,
        /new\s+ProcessBuilder\(\s*.*\+/i,
        /new\s+ProcessBuilder\(.*\.split\(/i,
        /ShellExecute\(/i,
        /system\(/i,
      ],
      fix: (code: string): string => {
        // Replace direct command execution with safer alternatives
        let fixedCode = code;
        
        // Fix Runtime.exec with string concatenation
        fixedCode = fixedCode.replace(
          /Runtime\.getRuntime\(\)\.exec\(\s*"([^"]*)"\s*\+\s*(.*?)\)/i,
          'List<String> commandList = new ArrayList<>();\n' +
          '  commandList.add("$1");\n' +
          '  // Add safely escaped command parameters\n' +
          '  // commandList.add(secureParameter);\n' +
          '  Runtime.getRuntime().exec(commandList.toArray(new String[0]))'
        );
        
        // Fix ProcessBuilder with string concatenation
        fixedCode = fixedCode.replace(
          /new\s+ProcessBuilder\(\s*"([^"]*)"\s*\+\s*(.*?)\)/i,
          'List<String> commandList = new ArrayList<>();\n' +
          '  commandList.add("$1");\n' +
          '  // Add safely escaped command parameters\n' +
          '  // commandList.add(secureParameter);\n' +
          '  new ProcessBuilder(commandList)'
        );
        
        // Fix unsafe string splitting for commands
        fixedCode = fixedCode.replace(
          /new\s+ProcessBuilder\(\s*(.*?)\.split\("\\s+"\)\)/i,
          'List<String> commandList = new ArrayList<>();\n' +
          '  // Parse and validate command arguments instead of direct splitting\n' +
          '  // validateAndAddToCommandList($1, commandList);\n' +
          '  new ProcessBuilder(commandList)'
        );
        
        return fixedCode;
      },
      severity: SeverityLevel.CRITICAL,
      title: "Command Injection Vulnerability",
      description: "Unsanitized user input in system command execution",
      potentialImpact: [
        "Remote code execution",
        "System compromise",
        "Data breach",
        "Complete system access"
      ],
      recommendations: [
        "Use command argument lists instead of strings",
        "Validate and sanitize all input",
        "Implement input whitelisting",
        "Use library functions instead of shell commands" 
      ]
    },
    
    sqlInjection: {
      patterns: [
        // Java-specific SQL Injection patterns
        /execute\s*\(\s*"SELECT.*\+.*\)/i,
        /executeQuery\s*\(\s*"SELECT.*\+.*\)/i,
        /executeUpdate\s*\(\s*".*"\s*\+.*\)/i,
        /createStatement\s*\(\s*\)/i,
        /prepareStatement\s*\(\s*".*"\s*\+.*\)/i,
        /Statement\s+\w+\s*=\s*\w+\.createStatement\(\)/i,
        /String\s+query\s*=\s*(['"`])SELECT[^"'`]+\+/i,
        /String\s+sql\s*=\s*(['"`])(SELECT|INSERT|UPDATE|DELETE)[^"'`]+\+/i,
        /executeQuery\s*\(".*WHERE.*=\s*"\s*\+/i,
        /executeUpdate\s*\(".*"\s*\+/i,
        /createQuery\s*\(\s*".*"\s*\+/i,
        /jdbc:mysql:\/\/.*"/i,
        /Connection\s+\w+\s*=\s*DriverManager\.getConnection\(/i,
        
        // More advanced Java SQL injection patterns
        /ResultSet\s+\w+\s*=\s*\w+\.executeQuery\(".*"\s*\+/i,
        /PreparedStatement\s+\w+\s*=\s*\w+\.prepareStatement\(".*"\s*\+/i,
        /String\s+\w+\s*=\s*".*WHERE\s+\w+\s*=\s*'"\s*\+.*\+\s*"'"/i,
        /String\s+\w+\s*=\s*".*WHERE\s+\w+\s*=\s*"\s*\+.*\+\s*"/i,
        
        // Spring JDBC and Hibernate patterns
        /jdbcTemplate\.queryForObject\(".*"\s*\+/i,
        /jdbcTemplate\.update\(".*"\s*\+/i,
        /entityManager\.createQuery\(".*"\s*\+/i,
        /entityManager\.createNativeQuery\(".*"\s*\+/i,
        /session\.createQuery\(".*"\s*\+/i,
        /session\.createSQLQuery\(".*"\s*\+/i,
        
        // Also keep basic JavaScript/TypeScript patterns for completeness
        /execute\s*\(\s*[`'"]\s*SELECT.+\$\{.+\}/i,
        /query\s*\(\s*[`'"]\s*SELECT.+\$\{.+\}/i,
        /db\.query\s*\(\s*[`'"]\s*SELECT.+\$\{.+\}/i,
      ],
      fix: (code: string): string => {
        // JavaScript/TypeScript fixes
        let fixedCode = code
          .replace(/(`|"|')SELECT .* WHERE .* = \${(.*)}(`|"|')/g, '$1SELECT * FROM users WHERE id = ?$3')
          .replace(/(`|"|')SELECT .* WHERE .* = \' \+ (.*) \+ \'(`|"|')/g, '$1SELECT * FROM users WHERE id = ?$3')
          .replace(/\.execute\((.*)\)/g, '.execute($1, [$2])');
          
        // Java fixes
        fixedCode = fixedCode
          // Fix executeQuery with string concatenation
          .replace(/executeQuery\s*\(\s*"SELECT.*WHERE.*=\s*"\s*\+\s*(.*?)\s*(\+\s*".*")?\)/i, 
                   'executeQuery("SELECT * FROM users WHERE id = ?", new Object[] {$1})')
          
          // Fix prepareStatement with string concatenation
          .replace(/prepareStatement\s*\(\s*"SELECT.*WHERE.*=\s*"\s*\+\s*(.*?)\s*(\+\s*".*")?\)/i, 
                   'prepareStatement("SELECT * FROM users WHERE id = ?")\n  stmt.setObject(1, $1)')
                   
          // Fix createStatement and execute with string concatenation
          .replace(/stmt\.execute\("SELECT.*WHERE.*=\s*"\s*\+\s*(.*?)\s*(\+\s*".*")?\)/i,
                   'preparedStmt = conn.prepareStatement("SELECT * FROM users WHERE id = ?")\n  preparedStmt.setObject(1, $1)\n  preparedStmt.execute()');
        
        return fixedCode;
      },
      severity: SeverityLevel.CRITICAL,
      title: "SQL Injection Vulnerability",
      description: "Unparameterized SQL query with user input",
      potentialImpact: [
        "Unauthorized data access",
        "Data modification",
        "Potential system compromise"
      ],
      recommendations: [
        "Use parameterized queries with placeholders",
        "Implement input validation",
        "Consider using ORM libraries",
        "Implement proper error handling"
      ]
    },
    xss: {
      patterns: [
        /innerHTML\s*=\s*.+/,
        /document\.write\s*\(.+\)/,
        /\$\(.+\)\.html\s*\(.+\)/,
        /dangerouslySetInnerHTML\s*=\s*\{\s*\{.*\}\s*\}/,
        /eval\s*\(.+\)/,
        /setTimeout\s*\(\s*['"`].*['"`]\s*\)/,
        /setInterval\s*\(\s*['"`].*['"`]\s*\)/,
        /\.insertAdjacentHTML\s*\(.+\)/
      ],
      fix: (code: string): string => {
        // Replace direct DOM manipulation with safer alternatives
        return code
          .replace(/\.innerHTML\s*=\s*(.*)/g, '.textContent = $1')
          .replace(/document\.write\s*\((.*)\)/g, 'element.textContent = $1')
          .replace(/\$\((.*)\)\.html\s*\((.*)\)/g, '$($1).text($2)')
          .replace(/dangerouslySetInnerHTML\s*=\s*\{\s*\{.*\}\s*\}/g, 'children={sanitizedContent}');
      },
      severity: SeverityLevel.HIGH,
      title: "Cross-Site Scripting (XSS)",
      description: "Unsanitized user input rendered in HTML",
      potentialImpact: [
        "Execution of malicious scripts in user browsers",
        "Session hijacking",
        "Data theft"
      ],
      recommendations: [
        "Use textContent instead of innerHTML",
        "Implement content security policy",
        "Sanitize user input",
        "Use framework escape mechanisms"
      ]
    },
    insecureDirectObjectRef: {
      patterns: [
        /\.(get|find|findOne)\s*\(\s*req\.params\.(id|userId|fileId)/i,
        /\.(get|find|findOne)\s*\(\s*req\.query\.(id|userId|fileId)/i,
        /findById\s*\(\s*req\.params\.(id|userId|fileId)/i,
        /getById\s*\(\s*req\.params\.(id|userId|fileId)/i,
        /User\.findOne\s*\(\s*\{\s*_id\s*:\s*req\.params\.id\s*\}\)/i,
        /Repository\.findOne\s*\(\s*\{\s*_id\s*:\s*req\.params\.id\s*\}\)/i
      ],
      fix: (code: string): string => {
        // Add authorization checks
        if (code.includes('req.params.id')) {
          return code.replace(
            /(const|let|var)\s+(\w+)\s+=\s+await\s+(\w+)\.(get|find|findOne|findById)\(\s*req\.params\.(\w+)\s*\)/,
            'const currentUser = req.user;\n' +
            '  if (!currentUser || !currentUser.hasAccess) {\n' +
            '    return res.status(403).json({ error: "Unauthorized access" });\n' +
            '  }\n' +
            '  $1 $2 = await $3.$4(req.params.$5)'
          );
        }
        return code;
      },
      severity: SeverityLevel.MEDIUM,
      title: "Insecure Direct Object Reference",
      description: "Direct access to resources without authorization checks",
      potentialImpact: [
        "Unauthorized access to protected resources",
        "Information disclosure",
        "Data tampering"
      ],
      recommendations: [
        "Implement proper authorization checks",
        "Use indirect reference maps",
        "Validate user access permissions"
      ]
    },
    hardcodedSecrets: {
      patterns: [
        // JavaScript/TypeScript patterns
        /const\s+(password|secret|key|token|apiKey|apiSecret)\s*=\s*['"`][^'"`]{8,}['"`]/i,
        /let\s+(password|secret|key|token|apiKey|apiSecret)\s*=\s*['"`][^'"`]{8,}['"`]/i,
        /var\s+(password|secret|key|token|apiKey|apiSecret)\s*=\s*['"`][^'"`]{8,}['"`]/i,
        
        // Java patterns
        /private\s+static\s+final\s+String\s+(PASSWORD|SECRET|KEY|TOKEN|API_KEY)\s*=\s*"[^"]{8,}"/i,
        /private\s+String\s+(password|secret|key|token|apiKey)\s*=\s*"[^"]{8,}"/i,
        /public\s+static\s+final\s+String\s+(PASSWORD|SECRET|KEY|TOKEN|API_KEY)\s*=\s*"[^"]{8,}"/i,
        /public\s+String\s+(password|secret|key|token|apiKey)\s*=\s*"[^"]{8,}"/i,
        /static\s+final\s+String\s+(PASSWORD|SECRET|KEY|TOKEN|API_KEY)\s*=\s*"[^"]{8,}"/i,
        /String\s+(password|secret|key|token|apiKey|apiSecret|dbPassword|authToken)\s*=\s*"[^"]{8,}"/i
      ],
      fix: (code: string): string => {
        // JavaScript/TypeScript fix
        let fixedCode = code.replace(
          /(const|let|var)\s+(password|secret|key|token|apiKey|apiSecret)\s*=\s*['"`]([^'"`]{8,})['"`]/i,
          '$1 $2 = process.env.$2'
        );
        
        // Java fixes - handle different variations of Java variable declarations
        fixedCode = fixedCode.replace(
          /(private|public)?\s*(static\s+final\s+)?String\s+(PASSWORD|SECRET|KEY|TOKEN|API_KEY|password|secret|key|token|apiKey|apiSecret|dbPassword|authToken)\s*=\s*"([^"]{8,})"/i,
          '$1 $2String $3 = System.getenv("$3")'
        );
        
        // Handle simple String declarations
        fixedCode = fixedCode.replace(
          /String\s+(password|secret|key|token|apiKey|apiSecret|dbPassword|authToken)\s*=\s*"([^"]{8,})"/i,
          'String $1 = System.getenv("$1")'
        );
        
        return fixedCode;
      },
      severity: SeverityLevel.CRITICAL,
      title: "Hardcoded Secrets",
      description: "Sensitive data hardcoded in source files",
      potentialImpact: [
        "Secret exposure in source control",
        "Unauthorized access to protected systems",
        "Credential theft"
      ],
      recommendations: [
        "Use environment variables for secrets",
        "Implement secure secret management",
        "Never commit secrets to source control"
      ]
    }
  };

  /**
   * Analyzes code for vulnerabilities
   * @param code The source code to analyze
   * @param filePath Path to the source file
   * @param repositoryId ID of the repository
   * @returns Array of detected vulnerabilities
   */
  analyzeCode(code: string, filePath: string, repositoryId: number): InsertVulnerability[] {
    const vulnerabilities: InsertVulnerability[] = [];
    const lines = code.split('\n');
    
    // Determine if this is a Java file
    const isJavaFile = filePath.toLowerCase().endsWith('.java');
    
    // Check each line for vulnerabilities
    lines.forEach((line, index) => {
      const lineNumber = index + 1;
      
      // Check for Java-specific vulnerabilities first if it's a Java file
      if (isJavaFile) {
        // Check for Java XXE vulnerability
        if (this.checkPatterns(line, this.patterns.javaXXE.patterns)) {
          const fixedCode = this.patterns.javaXXE.fix(line);
          vulnerabilities.push(this.createVulnerability(
            this.patterns.javaXXE,
            repositoryId,
            filePath,
            lineNumber,
            line,
            fixedCode
          ));
        }
        
        // Check for Java Command Injection
        if (this.checkPatterns(line, this.patterns.javaCommandInjection.patterns)) {
          const fixedCode = this.patterns.javaCommandInjection.fix(line);
          vulnerabilities.push(this.createVulnerability(
            this.patterns.javaCommandInjection,
            repositoryId,
            filePath,
            lineNumber,
            line,
            fixedCode
          ));
        }
      }
      
      // Check for SQL injection (applies to all languages but patterns are enhanced for Java)
      if (this.checkPatterns(line, this.patterns.sqlInjection.patterns)) {
        const fixedCode = this.patterns.sqlInjection.fix(line);
        vulnerabilities.push(this.createVulnerability(
          this.patterns.sqlInjection,
          repositoryId,
          filePath,
          lineNumber,
          line,
          fixedCode
        ));
      }
      
      // Check for XSS (primarily for web languages, but included for completeness)
      if (this.checkPatterns(line, this.patterns.xss.patterns)) {
        const fixedCode = this.patterns.xss.fix(line);
        vulnerabilities.push(this.createVulnerability(
          this.patterns.xss,
          repositoryId,
          filePath,
          lineNumber,
          line,
          fixedCode
        ));
      }
      
      // Check for IDOR
      if (this.checkPatterns(line, this.patterns.insecureDirectObjectRef.patterns)) {
        // For IDOR, we need context (surrounding lines)
        const contextStart = Math.max(0, index - 2);
        const contextEnd = Math.min(lines.length - 1, index + 2);
        const contextCode = lines.slice(contextStart, contextEnd + 1).join('\n');
        const fixedCode = this.patterns.insecureDirectObjectRef.fix(contextCode);
        
        vulnerabilities.push(this.createVulnerability(
          this.patterns.insecureDirectObjectRef,
          repositoryId,
          filePath,
          lineNumber,
          contextCode,
          fixedCode
        ));
      }
      
      // Check for hardcoded secrets (applies to all languages)
      if (this.checkPatterns(line, this.patterns.hardcodedSecrets.patterns)) {
        const fixedCode = this.patterns.hardcodedSecrets.fix(line);
        vulnerabilities.push(this.createVulnerability(
          this.patterns.hardcodedSecrets,
          repositoryId,
          filePath,
          lineNumber,
          line,
          fixedCode
        ));
      }
    });
    
    return vulnerabilities;
  }
  
  /**
   * Checks if a line of code matches any of the vulnerability patterns
   */
  private checkPatterns(line: string, patterns: RegExp[]): boolean {
    return patterns.some(pattern => pattern.test(line));
  }
  
  /**
   * Creates a vulnerability object
   */
  private createVulnerability(
    vulnerabilityType: any,
    repositoryId: number,
    filePath: string,
    lineNumber: number,
    originalCode: string,
    fixedCode: string
  ): InsertVulnerability {
    return {
      repositoryId,
      title: vulnerabilityType.title,
      description: vulnerabilityType.description,
      filePath,
      lineNumber,
      severity: vulnerabilityType.severity,
      status: VulnerabilityStatus.PENDING_REVIEW,
      detectionMethod: "Pattern Analysis",
      originalCode,
      fixedCode,
      potentialImpact: vulnerabilityType.potentialImpact,
      recommendations: vulnerabilityType.recommendations
    };
  }
}

export const codeAnalyzer = new CodeAnalyzer();
