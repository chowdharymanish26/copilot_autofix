import * as exec from '@actions/exec';
import * as fs from 'fs/promises';
import * as path from 'path';
import shelljs from 'shelljs';
import * as tmp from 'tmp';
import { promisify } from 'util';
import { InsertVulnerability, SeverityLevel, VulnerabilityStatus } from '@shared/schema';

// Create temp directory with promise support
const tmpDir = promisify(tmp.dir) as () => Promise<string>;

/**
 * Service for CodeQL integration
 * This service handles interactions with the CodeQL CLI
 */
export class CodeQLService {
  private isCodeQLInstalled = false;

  constructor() {
    // Check if CodeQL is installed
    this.checkCodeQLInstallation();
  }

  /**
   * Checks if CodeQL CLI is installed and available in PATH
   */
  private async checkCodeQLInstallation(): Promise<boolean> {
    try {
      // Try to execute 'codeql --version'
      const result = shelljs.exec('codeql --version', { silent: true });
      
      if (result.code === 0) {
        console.log('CodeQL is installed:', result.stdout.trim());
        this.isCodeQLInstalled = true;
        return true;
      } else {
        console.log('CodeQL is not installed or not in PATH');
        this.isCodeQLInstalled = false;
        return false;
      }
    } catch (error) {
      console.error('Error checking for CodeQL installation:', error);
      this.isCodeQLInstalled = false;
      return false;
    }
  }

  /**
   * Check if CodeQL is available for use
   */
  public isAvailable(): boolean {
    return this.isCodeQLInstalled;
  }

  /**
   * Creates a CodeQL database for analysis
   * @param repoPath Path to the repository
   * @param language Language to analyze (java, javascript, etc.)
   * @returns Path to the created database
   */
  public async createDatabase(repoPath: string, language: string): Promise<string> {
    if (!this.isCodeQLInstalled) {
      throw new Error('CodeQL is not installed. Please install CodeQL CLI first.');
    }

    try {
      // Create a temporary directory for the database
      const tempDbPath = await tmpDir();
      
      console.log(`Creating CodeQL database at ${tempDbPath} for ${language} code in ${repoPath}`);
      
      // Build the command to create the database
      const exitCode = await exec.exec('codeql', [
        'database',
        'create',
        tempDbPath,
        `--language=${language}`,
        `--source-root=${repoPath}`
      ]);
      
      if (exitCode !== 0) {
        throw new Error(`Failed to create CodeQL database (exit code: ${exitCode})`);
      }
      
      return tempDbPath;
    } catch (error: any) {
      console.error('Error creating CodeQL database:', error);
      throw new Error(`Failed to create CodeQL database: ${error?.message || 'Unknown error'}`);
    }
  }

  /**
   * Analyzes a CodeQL database using specified query packs
   * @param dbPath Path to the CodeQL database
   * @param queryPack Query pack to use (e.g., 'security-and-quality')
   * @returns Path to the SARIF results file
   */
  public async analyzeDatabase(dbPath: string, queryPack: string = 'security-and-quality'): Promise<string> {
    if (!this.isCodeQLInstalled) {
      throw new Error('CodeQL is not installed. Please install CodeQL CLI first.');
    }

    try {
      // Create a temporary file for the results
      const resultsPath = path.join(dbPath, 'results.sarif');
      
      console.log(`Analyzing CodeQL database at ${dbPath} with query pack ${queryPack}`);
      
      // Build the command to analyze the database
      const exitCode = await exec.exec('codeql', [
        'database',
        'analyze',
        dbPath,
        queryPack,
        '--format=sarif-latest',
        `--output=${resultsPath}`
      ]);
      
      if (exitCode !== 0) {
        throw new Error(`Failed to analyze CodeQL database (exit code: ${exitCode})`);
      }
      
      return resultsPath;
    } catch (error: any) {
      console.error('Error analyzing CodeQL database:', error);
      throw new Error(`Failed to analyze CodeQL database: ${error?.message || 'Unknown error'}`);
    }
  }

  /**
   * Parses SARIF results file into vulnerability objects
   * @param sarifPath Path to the SARIF results file
   * @param repositoryId ID of the repository
   * @returns Array of vulnerabilities
   */
  public async parseSarifResults(sarifPath: string, repositoryId: number): Promise<InsertVulnerability[]> {
    try {
      // Read the SARIF file
      const sarifContent = await fs.readFile(sarifPath, 'utf8');
      const sarifData = JSON.parse(sarifContent);
      
      if (!sarifData.runs || sarifData.runs.length === 0 || !sarifData.runs[0].results) {
        console.log('No results found in SARIF file');
        return [];
      }
      
      // Convert SARIF results to vulnerability objects
      const vulnerabilities: InsertVulnerability[] = [];
      
      for (const result of sarifData.runs[0].results) {
        // Skip results without locations
        if (!result.locations || result.locations.length === 0) {
          continue;
        }
        
        const location = result.locations[0].physicalLocation;
        if (!location || !location.artifactLocation || !location.region) {
          continue;
        }
        
        const filePath = location.artifactLocation.uri;
        const lineNumber = location.region.startLine;
        const rule = sarifData.runs[0].tool.driver.rules?.find((r: any) => r.id === result.ruleId) || {};
        
        // Map CodeQL severity to our severity levels
        let severity: SeverityLevel = SeverityLevel.MEDIUM;
        if (rule.properties?.security_severity) {
          const securitySeverity = parseFloat(rule.properties.security_severity);
          if (securitySeverity >= 9.0) severity = SeverityLevel.CRITICAL;
          else if (securitySeverity >= 7.0) severity = SeverityLevel.HIGH;
          else if (securitySeverity >= 4.0) severity = SeverityLevel.MEDIUM;
          else severity = SeverityLevel.LOW;
        }
        
        // Extract code snippets if available
        let originalCode = '';
        if (location.region.snippet?.text) {
          originalCode = location.region.snippet.text;
        }
        
        // Create vulnerability object
        const vulnerability: InsertVulnerability = {
          repositoryId,
          title: `CodeQL: ${rule.shortDescription?.text || result.ruleId}`,
          description: rule.fullDescription?.text || result.message.text,
          filePath,
          lineNumber,
          severity,
          status: VulnerabilityStatus.OPEN,
          detectionMethod: "codeql",
          originalCode,
          fixedCode: '', // CodeQL doesn't provide fixes
          potentialImpact: [
            rule.properties?.description || 'Security vulnerability detected by CodeQL'
          ],
          recommendations: [
            rule.help?.text || 'Review and fix this issue according to best practices'
          ]
        };
        
        vulnerabilities.push(vulnerability);
      }
      
      return vulnerabilities;
    } catch (error: any) {
      console.error('Error parsing SARIF results:', error);
      throw new Error(`Failed to parse SARIF results: ${error?.message || 'Unknown error'}`);
    }
  }

  /**
   * Scans a repository using CodeQL
   * @param repoUrl URL of the GitHub repository
   * @param repoPath Local path to the cloned repository
   * @param repositoryId ID of the repository in our system
   * @returns Array of detected vulnerabilities
   */
  public async scanRepository(repoUrl: string, repoPath: string, repositoryId: number): Promise<InsertVulnerability[]> {
    if (!this.isCodeQLInstalled) {
      console.log('CodeQL is not installed, skipping CodeQL scan');
      return [];
    }

    try {
      console.log(`Starting CodeQL scan for repository ${repoUrl}`);
      
      // Create CodeQL database
      const dbPath = await this.createDatabase(repoPath, 'java');
      
      // Analyze the database
      const resultsPath = await this.analyzeDatabase(dbPath);
      
      // Parse results
      const vulnerabilities = await this.parseSarifResults(resultsPath, repositoryId);
      
      console.log(`CodeQL scan completed. Found ${vulnerabilities.length} vulnerabilities.`);
      
      return vulnerabilities;
    } catch (error: any) {
      console.error('Error during CodeQL scan:', error);
      throw new Error(`CodeQL scan failed: ${error?.message || 'Unknown error'}`);
    }
  }

  /**
   * Clones a repository to a temporary directory
   * @param repoUrl URL of the GitHub repository
   * @returns Path to the cloned repository
   */
  public async cloneRepository(repoUrl: string): Promise<string> {
    try {
      // Create a temporary directory
      const tempPath = await tmpDir();
      
      console.log(`Cloning repository ${repoUrl} to ${tempPath}`);
      
      // Build the command to clone the repository
      const exitCode = await exec.exec('git', [
        'clone',
        repoUrl,
        tempPath
      ]);
      
      if (exitCode !== 0) {
        throw new Error(`Failed to clone repository (exit code: ${exitCode})`);
      }
      
      return tempPath;
    } catch (error: any) {
      console.error('Error cloning repository:', error);
      throw new Error(`Failed to clone repository: ${error?.message || 'Unknown error'}`);
    }
  }
}

// Export a singleton instance
export const codeQLService = new CodeQLService();