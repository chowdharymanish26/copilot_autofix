import { mysqlTable, varchar, text, int, serial, boolean, timestamp, json } from "drizzle-orm/mysql-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define severity levels
export enum SeverityLevel {
  CRITICAL = "critical",
  HIGH = "high",
  MEDIUM = "medium",
  LOW = "low",
  INFO = "info"
}

// Define vulnerability status
export enum VulnerabilityStatus {
  OPEN = "open",
  PENDING_REVIEW = "pending_review",
  APPROVED = "approved",
  REJECTED = "rejected",
  FIXED = "fixed"
}

// Define repositories table
export const repositories = mysqlTable("repositories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  url: varchar("url", { length: 255 }).notNull(),
  languages: json("languages").$type<string[]>(),
  code: text("code"),  // Store sample code for scanning
  lastScanDate: timestamp("last_scan_date"),
  issueCount: int("issue_count").default(0),
  codeQLUsed: boolean("codeql_used").default(false), // Track if CodeQL was used in last scan
  codeQLFindings: int("codeql_findings").default(0),  // Number of findings from CodeQL
  snykUsed: boolean("snyk_used").default(false), // Track if Snyk was used in last scan
  snykFindings: int("snyk_findings").default(0)  // Number of findings from Snyk
});

// Define vulnerabilities table
export const vulnerabilities = mysqlTable("vulnerabilities", {
  id: serial("id").primaryKey(),
  repositoryId: int("repository_id").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  filePath: varchar("file_path", { length: 255 }).notNull(),
  lineNumber: int("line_number").notNull(),
  severity: varchar("severity", { length: 50 }).notNull(),
  status: varchar("status", { length: 50 }).notNull().default(VulnerabilityStatus.OPEN),
  detectionMethod: varchar("detection_method", { length: 100 }),
  originalCode: text("original_code"),
  fixedCode: text("fixed_code"),
  potentialImpact: json("potential_impact").$type<string[]>(),
  recommendations: json("recommendations").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow()
});

// Define activities table
export const activities = mysqlTable("activities", {
  id: serial("id").primaryKey(),
  activityType: varchar("activity_type", { length: 100 }).notNull(),
  description: text("description").notNull(),
  repositoryId: int("repository_id"),
  vulnerabilityId: int("vulnerability_id"),
  timestamp: timestamp("timestamp").defaultNow()
});

// User table
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  avatarUrl: varchar("avatar_url", { length: 255 })
});

// Define insert schemas
export const insertRepositorySchema = createInsertSchema(repositories).omit({
  id: true,
  issueCount: true
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilities).omit({
  id: true,
  createdAt: true
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  timestamp: true
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true
});

// Define response types
export type Repository = typeof repositories.$inferSelect;
export type Vulnerability = typeof vulnerabilities.$inferSelect;
export type Activity = typeof activities.$inferSelect;
export type User = typeof users.$inferSelect;

// Define insert types
export type InsertRepository = z.infer<typeof insertRepositorySchema>;
export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Define dashboard statistics type
export type DashboardStats = {
  repoCount: number;
  vulnerabilityCount: number;
  fixedCount: number;
  pendingReviewCount: number;
};
