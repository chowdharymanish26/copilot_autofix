// Python vulnerability patterns

import { VulnerabilityPattern } from './patterns-interface';

// SQL Injection vulnerabilities
const sqlInjectionPatterns: VulnerabilityPattern[] = [
  {
    id: 'PY-SQL-INJ-01',
    name: 'Raw SQL Query in Python',
    severity: 'critical',
    regex: /cursor\.execute\(\s*["'](SELECT|INSERT|UPDATE|DELETE).*?\+\s*\w+/i,
    description: 'Unsanitized user input used in SQL queries can lead to SQL injection attacks.',
    fixExample: `# Use parameterized queries
cursor.execute("SELECT * FROM users WHERE username = %s", (username,))`,
    language: 'python'
  },
  {
    id: 'PY-SQL-INJ-02',
    name: 'String Formatting in SQL',
    severity: 'high',
    regex: /cursor\.execute\(\s*f["'](SELECT|INSERT|UPDATE|DELETE)/i,
    description: 'Using f-strings in SQL queries can lead to SQL injection.',
    fixExample: `# Use parameterized queries instead of string formatting
cursor.execute("SELECT * FROM users WHERE username = %s", (username,))`,
    language: 'python'
  },
  {
    id: 'PY-SQL-INJ-03',
    name: 'String Concatenation in SQL',
    severity: 'high',
    regex: /cursor\.execute\(\s*["'](SELECT|INSERT|UPDATE|DELETE).*?\s*%\s*\(/i,
    description: 'Using string formatting (%) in SQL queries can lead to SQL injection.',
    fixExample: `# Use parameterized queries
cursor.execute("SELECT * FROM users WHERE username = %s", (username,))`,
    language: 'python'
  }
];

// Path Traversal vulnerabilities
const pathTraversalPatterns: VulnerabilityPattern[] = [
  {
    id: 'PY-PATH-TRAV-01',
    name: 'Unsanitized File Path',
    severity: 'high',
    regex: /open\(\s*(?!os\.path\.(?:abspath|basename|dirname|join|normpath))[^,)]+\s*,\s*["'](?:r|w|a|r\+|w\+|a\+)/,
    description: 'Using unsanitized file paths can lead to path traversal vulnerabilities.',
    fixExample: `from os.path import normpath, join, abspath
base_dir = '/safe/directory'
# Sanitize and validate the file path
file_path = join(base_dir, normpath(filename))
if not abspath(file_path).startswith(base_dir):
    raise ValueError("Invalid file path")
with open(file_path, 'r') as file:
    data = file.read()`,
    language: 'python'
  },
  {
    id: 'PY-PATH-TRAV-02',
    name: 'Direct Path Access',
    severity: 'high',
    regex: /(?:os\.(?:system|popen|execl|execle|execlp|execlpe|execv|execve|execvp|execvpe|spawn[lp]e?|popen[23]?)|subprocess\.(?:call|check_call|check_output|Popen|run))\(\s*(?!os\.path\.(?:abspath|basename|dirname|join|normpath))/,
    description: 'Executing commands with unsanitized paths can lead to path traversal vulnerabilities.',
    fixExample: `from os.path import normpath, join, abspath
import subprocess

base_dir = '/safe/directory'
# Sanitize and validate the file path
file_path = join(base_dir, normpath(filename))
if not abspath(file_path).startswith(base_dir):
    raise ValueError("Invalid file path")
subprocess.run(['cat', file_path], check=True)`,
    language: 'python'
  }
];

// Command Injection vulnerabilities
const commandInjectionPatterns: VulnerabilityPattern[] = [
  {
    id: 'PY-CMD-INJ-01',
    name: 'OS Command Injection',
    severity: 'critical',
    regex: /os\.system\(\s*(?:f["']|["'].*?\s*\+\s*|["'].*?\s*%\s*|["'].*?{)/,
    description: 'Using unsanitized user input in os.system() calls can lead to command injection.',
    fixExample: `import subprocess
# Use subprocess module with a list of arguments instead of a shell command
subprocess.run(['program', 'arg1', user_input], check=True)`,
    language: 'python'
  },
  {
    id: 'PY-CMD-INJ-02',
    name: 'Subprocess Shell Command',
    severity: 'critical',
    regex: /subprocess\.(?:call|check_call|check_output|Popen|run)\(\s*(?:f["']|["'].*?\s*\+\s*|["'].*?\s*%\s*|["'].*?{).*?shell\s*=\s*True/,
    description: 'Using shell=True with unsanitized input in subprocess calls can lead to command injection.',
    fixExample: `import subprocess
# Use a list of arguments instead of shell=True
subprocess.run(['program', 'arg1', user_input], check=True)`,
    language: 'python'
  }
];

// Pickle/Marshal vulnerabilities
const deserializationPatterns: VulnerabilityPattern[] = [
  {
    id: 'PY-DESER-01',
    name: 'Unsafe Pickle Deserialization',
    severity: 'critical',
    regex: /pickle\.(?:loads|load)\(/,
    description: 'Deserializing untrusted pickle data can lead to remote code execution.',
    fixExample: `# Consider using a safer serialization format like JSON
import json
data = json.loads(user_input)

# If you must use pickle, verify the source of the data
# and consider using restrictions like pickle.HIGHEST_PROTOCOL
import pickle
import hmac
import base64

def verify_and_load(signed_data, secret_key):
    try:
        signature, data = signed_data.split(':', 1)
        expected_sig = hmac.new(secret_key, data.encode(), 'sha256').hexdigest()
        if hmac.compare_digest(signature, expected_sig):
            return pickle.loads(base64.b64decode(data))
        else:
            raise ValueError("Invalid signature")
    except Exception as e:
        raise ValueError("Invalid data") from e`,
    language: 'python'
  },
  {
    id: 'PY-DESER-02',
    name: 'Unsafe yaml.load Usage',
    severity: 'high',
    regex: /yaml\.(?:load|unsafe_load)\(\s*(?!.*?Loader\s*=\s*yaml\.(?:Safe|CSafe)Loader)/,
    description: 'Using yaml.load without SafeLoader can lead to remote code execution.',
    fixExample: `import yaml
# Use yaml.safe_load instead of yaml.load
data = yaml.safe_load(user_input)

# Or explicitly specify the SafeLoader
data = yaml.load(user_input, Loader=yaml.SafeLoader)`,
    language: 'python'
  }
];

// Insecure Hashing/Crypto vulnerabilities
const insecureHashPatterns: VulnerabilityPattern[] = [
  {
    id: 'PY-HASH-01',
    name: 'MD5 Hash Usage',
    severity: 'high',
    regex: /hashlib\.md5\(/,
    description: 'MD5 is cryptographically broken. Use a more secure hashing algorithm.',
    fixExample: `import hashlib
# Use SHA-256 or better for hashing
hash_obj = hashlib.sha256(data)
digest = hash_obj.hexdigest()`,
    language: 'python'
  },
  {
    id: 'PY-HASH-02',
    name: 'SHA-1 Hash Usage',
    severity: 'moderate',
    regex: /hashlib\.sha1\(/,
    description: 'SHA-1 is cryptographically weak. Use a more secure algorithm like SHA-256.',
    fixExample: `import hashlib
# Use SHA-256 or better for hashing
hash_obj = hashlib.sha256(data)
digest = hash_obj.hexdigest()`,
    language: 'python'
  },
  {
    id: 'PY-CRYPT-01',
    name: 'Weak Password Hashing',
    severity: 'high',
    regex: /(?:hashlib\.(?:md5|sha1|sha224|sha256|sha384|sha512)\((?:password|passwd))|(?:password|passwd)\.encode\(\)/,
    description: 'Simple hashing is insufficient for passwords. Use specialized password hashing.',
    fixExample: `import bcrypt
# Use a proper password hashing library like bcrypt
hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

# Or use Python's built-in functions
from passlib.hash import pbkdf2_sha256
hash = pbkdf2_sha256.hash(password)

# Or use Python 3.6+ stdlib
import hashlib
import os
salt = os.urandom(32)
key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)`,
    language: 'python'
  }
];

// Combine all patterns
export const pythonVulnerabilityPatterns: VulnerabilityPattern[] = [
  ...sqlInjectionPatterns,
  ...pathTraversalPatterns,
  ...commandInjectionPatterns,
  ...deserializationPatterns,
  ...insecureHashPatterns
];

// Function to analyze Python code for vulnerabilities
export function analyzePythonCode(
  filePath: string, 
  code: string
): Array<{ 
  pattern: VulnerabilityPattern; 
  line: number; 
  matchedCode: string;
  fixedCode: string;
}> {
  const results = [];
  const lines = code.split('\n');

  for (const pattern of pythonVulnerabilityPatterns) {
    // Reset regex lastIndex to avoid issues with global regex
    pattern.regex.lastIndex = 0;
    
    // Match against entire code
    const matches = code.match(pattern.regex);
    
    if (matches) {
      for (const match of [matches[0]]) {
        // Find the line number(s) for this match
        let lineNumber = -1;
        
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].includes(match)) {
            lineNumber = i + 1;
            break;
          }
        }
        
        // If we couldn't find the exact line, try to get close
        if (lineNumber === -1) {
          const codeChunks = match.split('\n');
          if (codeChunks.length > 0) {
            for (let i = 0; i < lines.length; i++) {
              if (lines[i].includes(codeChunks[0])) {
                lineNumber = i + 1;
                break;
              }
            }
          }
        }
        
        // Generate a simple fixed code example by replacing vulnerable code
        // with a fixed version tailored to the found vulnerability
        let fixedCode = pattern.fixExample;
        
        results.push({
          pattern,
          line: lineNumber,
          matchedCode: match,
          fixedCode
        });
      }
    }
  }

  return results;
}