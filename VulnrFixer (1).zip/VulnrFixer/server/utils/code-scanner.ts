// Unified code scanner for multiple languages

import { vulnerabilityPatterns } from './java-patterns';
import { pythonVulnerabilityPatterns, analyzePythonCode } from './python-patterns';
import { javascriptVulnerabilityPatterns, analyzeJavaScriptCode } from './javascript-patterns';
import { analyzeJavaCode } from './java-patterns';
import { findCodeFilesByLanguage, readFileContent } from './github';
import { VulnerabilityPattern } from './patterns-interface';

// Results interface for consistency
export interface VulnerabilityResult {
  pattern: VulnerabilityPattern;
  line: number;
  matchedCode: string;
  fixedCode: string;
  language: string;
  filePath: string;
}

// Detect language from file extension
export function detectLanguage(filePath: string): string | null {
  if (filePath.endsWith('.java')) {
    return 'java';
  } else if (filePath.endsWith('.py')) {
    return 'python';
  } else if (filePath.endsWith('.js')) {
    return 'javascript';
  } else if (filePath.endsWith('.ts') && !filePath.endsWith('.d.ts')) {
    return 'typescript';
  }
  return null;
}

// Scan a repository for vulnerabilities in all supported languages
export async function scanRepositoryCode(
  repoPath: string,
  supportedLanguages = ['java', 'python', 'javascript', 'typescript']
): Promise<VulnerabilityResult[]> {
  const allResults: VulnerabilityResult[] = [];
  
  // Scan each supported language
  for (const language of supportedLanguages) {
    try {
      console.log(`Scanning for ${language} files...`);
      
      // Find files of the current language
      const files = await findCodeFilesByLanguage(repoPath, language);
      console.log(`Found ${files.length} ${language} files`);
      
      // Process each file
      for (const filePath of files) {
        try {
          const fileContent = await readFileContent(filePath);
          let analysisResults: any[] = [];
          
          // Analyze based on language
          switch (language) {
            case 'java':
              analysisResults = analyzeJavaCode(filePath, fileContent);
              break;
            case 'python':
              analysisResults = analyzePythonCode(filePath, fileContent);
              break;
            case 'javascript':
            case 'typescript': // Use same analyzer for TS files
              analysisResults = analyzeJavaScriptCode(filePath, fileContent);
              break;
          }
          
          // Map results to standard format
          const formattedResults: VulnerabilityResult[] = analysisResults.map(result => ({
            ...result,
            language,
            filePath: filePath.substring(repoPath.length + 1) // Relative path
          }));
          
          allResults.push(...formattedResults);
          
        } catch (error) {
          console.error(`Error analyzing file ${filePath}:`, error);
        }
      }
    } catch (error) {
      console.error(`Error scanning ${language} files:`, error);
    }
  }
  
  return allResults;
}

// Get a count of vulnerabilities by detection method
export function getVulnerabilityCountByDetectionMethod(
  results: VulnerabilityResult[]
): { pattern: number; snyk: number; both: number } {
  return {
    pattern: results.length,
    snyk: 0, // Will be filled in separately from Snyk results
    both: 0  // Will be calculated after merging results
  };
}

// Get a count of vulnerabilities by language
export function getVulnerabilityCountByLanguage(
  results: VulnerabilityResult[]
): Record<string, number> {
  const counts: Record<string, number> = {};
  
  for (const result of results) {
    const language = result.language || 'unknown';
    counts[language] = (counts[language] || 0) + 1;
  }
  
  return counts;
}

// Get a count of vulnerabilities by severity
export function getVulnerabilityCountBySeverity(
  results: VulnerabilityResult[]
): { critical: number; high: number; moderate: number; total: number } {
  const counts = {
    critical: 0,
    high: 0,
    moderate: 0,
    total: 0
  };
  
  for (const result of results) {
    const severity = result.pattern.severity;
    if (severity === 'critical') counts.critical++;
    else if (severity === 'high') counts.high++;
    else if (severity === 'moderate') counts.moderate++;
    counts.total++;
  }
  
  return counts;
}