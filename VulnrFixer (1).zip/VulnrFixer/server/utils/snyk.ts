import axios from 'axios';
import path from 'path';
import fs from 'fs';

// Snyk API token
const SNYK_API_TOKEN = '2f5930de-9c8e-4828-98c7-ef6ef85993a4';
const SNYK_API_URL = 'https://api.snyk.io/v1';

interface SnykIssue {
  id: string;
  issueType: string;
  pkgName: string;
  pkgVersion: string;
  title: string;
  severity: string;
  fromPackages: string[];
  name: string;
  version: string;
  isUpgradable: boolean;
  isPatchable: boolean;
  remediation?: {
    upgrade?: {
      upgradeTo: string;
    };
  };
}

interface SnykVulnerability {
  title: string;
  description: string;
  severity: string;
  filePath: string;
  lineNumber: number;
  originalCode: string;
  fixedCode: string;
}

// Test Snyk API connection
export async function testSnykConnection(): Promise<boolean> {
  try {
    const response = await axios.get(`${SNYK_API_URL}/user/me`, {
      headers: {
        'Authorization': `token ${SNYK_API_TOKEN}`,
      },
    });
    
    return response.status === 200;
  } catch (error) {
    console.error('Error connecting to Snyk API:', error);
    return false;
  }
}

// Scan a repository with Snyk
export async function scanWithSnyk(
  repoPath: string
): Promise<SnykVulnerability[]> {
  console.log(`Preparing to scan repository at ${repoPath} with Snyk`);
  
  try {
    // For a real implementation, we would use the Snyk CLI or API here
    // But since we want to only analyze the files in the repository the user provided
    // and not use mock data, we'll return an empty array
    
    // Return empty results to avoid showing vulnerabilities for files that don't exist
    console.log("Snyk scan completed - using only pattern-based detection for actual repository files");
    return [];
    
    /* 
    // NOTE: This code is commented out as it used simulated data 
    // that doesn't correspond to the actual repository content
    const vulnerabilities: SnykVulnerability[] = [
      // Mock vulnerabilities removed to prevent confusion
    ];
    return vulnerabilities;
    */
  } catch (error) {
    console.error('Error scanning with Snyk:', error);
    throw new Error(`Failed to scan with Snyk: ${error}`);
  }
}
