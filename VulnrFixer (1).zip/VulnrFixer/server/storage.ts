import { 
  repositories, 
  vulnerabilities, 
  type Repository, 
  type InsertRepository, 
  type Vulnerability, 
  type InsertVulnerability
} from "@shared/schema";

export interface IStorage {
  // Repository methods
  getRepositories(): Promise<Repository[]>;
  getRepository(id: number): Promise<Repository | undefined>;
  getRepositoryByUrl(url: string): Promise<Repository | undefined>;
  createRepository(repo: InsertRepository): Promise<Repository>;
  updateRepositoryStatus(id: number, status: string): Promise<Repository | undefined>;

  // Vulnerability methods
  getVulnerabilities(repositoryId: number): Promise<Vulnerability[]>;
  getVulnerability(id: number): Promise<Vulnerability | undefined>;
  createVulnerability(vulnerability: InsertVulnerability): Promise<Vulnerability>;
  updateVulnerabilityStatus(id: number, status: string): Promise<Vulnerability | undefined>;
}

export class MemStorage implements IStorage {
  private repos: Map<number, Repository>;
  private vulns: Map<number, Vulnerability>;
  private repoCurrentId: number;
  private vulnCurrentId: number;

  constructor() {
    this.repos = new Map();
    this.vulns = new Map();
    this.repoCurrentId = 1;
    this.vulnCurrentId = 1;
  }

  // Repository methods
  async getRepositories(): Promise<Repository[]> {
    return Array.from(this.repos.values());
  }

  async getRepository(id: number): Promise<Repository | undefined> {
    return this.repos.get(id);
  }

  async getRepositoryByUrl(url: string): Promise<Repository | undefined> {
    return Array.from(this.repos.values()).find(
      (repo) => repo.url === url,
    );
  }

  async createRepository(repo: InsertRepository): Promise<Repository> {
    const id = this.repoCurrentId++;
    const repository: Repository = { 
      ...repo, 
      id, 
      scannedAt: new Date(),
      status: "pending" 
    };
    this.repos.set(id, repository);
    return repository;
  }

  async updateRepositoryStatus(id: number, status: string): Promise<Repository | undefined> {
    const repository = this.repos.get(id);
    if (repository) {
      const updatedRepo = { ...repository, status };
      this.repos.set(id, updatedRepo);
      return updatedRepo;
    }
    return undefined;
  }

  // Vulnerability methods
  async getVulnerabilities(repositoryId: number): Promise<Vulnerability[]> {
    return Array.from(this.vulns.values()).filter(
      (vuln) => vuln.repositoryId === repositoryId,
    );
  }

  async getVulnerability(id: number): Promise<Vulnerability | undefined> {
    return this.vulns.get(id);
  }

  async createVulnerability(vulnerability: InsertVulnerability): Promise<Vulnerability> {
    const id = this.vulnCurrentId++;
    
    // Detect language from file path if not specified
    let language = vulnerability.language;
    if (!language && vulnerability.filePath) {
      const filePath = vulnerability.filePath;
      if (filePath.endsWith('.java')) {
        language = 'java';
      } else if (filePath.endsWith('.py')) {
        language = 'python';
      } else if (filePath.endsWith('.js')) {
        language = 'javascript';
      } else if (filePath.endsWith('.ts') && !filePath.endsWith('.d.ts')) {
        language = 'typescript';
      } else {
        // Log unknown file types for debugging
        console.log(`Unknown file type for vulnerability in: ${filePath}`);
        language = 'unknown';
      }
    }
    
    console.log(`Creating vulnerability record for ${vulnerability.filePath} (${language || 'unknown language'})`);
    const vuln: Vulnerability = { ...vulnerability, id, status: "pending", language };
    this.vulns.set(id, vuln);
    return vuln;
  }

  async updateVulnerabilityStatus(id: number, status: string): Promise<Vulnerability | undefined> {
    const vulnerability = this.vulns.get(id);
    if (vulnerability) {
      const updatedVuln = { ...vulnerability, status };
      this.vulns.set(id, updatedVuln);
      return updatedVuln;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
