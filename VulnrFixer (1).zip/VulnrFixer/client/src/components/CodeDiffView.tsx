import React from 'react';
import { cn } from "@/lib/utils";

interface CodeLine {
  number: number;
  content: string;
  type: 'context' | 'added' | 'removed';
}

interface CodeDiffViewProps {
  originalCode: string;
  fixedCode: string;
  className?: string;
}

export function CodeDiffView({ originalCode, fixedCode, className }: CodeDiffViewProps) {
  // Parse the code strings into lines
  const originalLines = originalCode.split('\n');
  const fixedLines = fixedCode.split('\n');
  
  // Generate display lines - simplistic diff approach for demo
  // In a real app, we'd use a proper diff algorithm
  const displayLines: CodeLine[] = [];
  
  // Find common prefix
  let prefixLength = 0;
  while (
    prefixLength < originalLines.length && 
    prefixLength < fixedLines.length && 
    originalLines[prefixLength] === fixedLines[prefixLength]
  ) {
    displayLines.push({
      number: prefixLength + 1,
      content: originalLines[prefixLength],
      type: 'context'
    });
    prefixLength++;
  }
  
  // Add removed lines
  for (let i = prefixLength; i < originalLines.length; i++) {
    displayLines.push({
      number: i + 1,
      content: originalLines[i],
      type: 'removed'
    });
  }
  
  // Add added lines
  for (let i = prefixLength; i < fixedLines.length; i++) {
    displayLines.push({
      number: i + 1,
      content: fixedLines[i],
      type: 'added'
    });
  }

  return (
    <div className={cn("bg-slate-800 rounded-lg overflow-x-auto", className)}>
      <table className="min-w-full">
        <tbody>
          {displayLines.map((line, index) => (
            <tr 
              key={index} 
              className={cn({
                "removed-line": line.type === 'removed',
                "added-line": line.type === 'added'
              })}
            >
              <td className="line-number">{line.number}</td>
              <td className="code-line">{line.content}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
