import React, { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Checkbox } from '@/components/ui/checkbox';
import { SNYK_API_TOKEN_MASKED } from '@/lib/constants';
import { useScanRepository } from '@/hooks/use-scan-repository';

const formSchema = z.object({
  url: z
    .string({
      required_error: 'Repository URL is required',
    })
    .url('Please enter a valid GitHub URL')
    .refine(url => url.includes('github.com'), {
      message: 'URL must be a GitHub repository',
    }),
  usePatternDetection: z.boolean().default(true),
  useSnyk: z.boolean().default(true),
});

interface RepositoryFormProps {
  onScanComplete?: (repositoryId: number) => void;
}

export function RepositoryForm({ onScanComplete }: RepositoryFormProps) {
  const { scanRepository, isScanning, repositoryId } = useScanRepository();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      url: '',
      usePatternDetection: true,
      useSnyk: true,
    },
  });
  
  function onSubmit(values: z.infer<typeof formSchema>) {
    scanRepository(values, {
      onSuccess: (data) => {
        if (onScanComplete) {
          onScanComplete(data.repositoryId);
        }
      }
    });
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <FormField
            control={form.control}
            name="url"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium text-slate-400">GitHub Repository URL</FormLabel>
                <FormControl>
                  <div className="flex">
                    <Input
                      placeholder="https://github.com/username/repository"
                      className="flex-1 bg-background border border-slate-700 rounded-l-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary"
                      {...field}
                      disabled={isScanning}
                    />
                    <Button
                      type="submit"
                      className="bg-primary hover:bg-blue-600 text-white px-6 py-3 rounded-r-lg font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary focus:ring-offset-background transition-colors"
                      disabled={isScanning}
                    >
                      {isScanning ? 'Scanning...' : 'Scan Repository'}
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <div className="flex items-center space-x-4">
          <FormField
            control={form.control}
            name="usePatternDetection"
            render={({ field }) => (
              <FormItem className="flex items-center space-x-2">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    id="pattern-detection"
                    className="rounded bg-slate-700 border-slate-600 text-primary focus:ring-primary"
                  />
                </FormControl>
                <FormLabel htmlFor="pattern-detection" className="text-sm text-slate-300">
                  Pattern Detection
                </FormLabel>
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="useSnyk"
            render={({ field }) => (
              <FormItem className="flex items-center space-x-2">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    id="snyk-integration"
                    className="rounded bg-slate-700 border-slate-600 text-primary focus:ring-primary"
                  />
                </FormControl>
                <FormLabel htmlFor="snyk-integration" className="text-sm text-slate-300">
                  Snyk Integration
                </FormLabel>
              </FormItem>
            )}
          />
          
          <div className="flex items-center">
            <span className="material-icons text-slate-400 text-sm mr-1">info</span>
            <span className="text-xs text-slate-400">Snyk API Token: {SNYK_API_TOKEN_MASKED}</span>
          </div>
        </div>
      </form>
    </Form>
  );
}
