import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Vulnerability } from '@/types';
import { 
  getVulnerabilityStats, 
  getVulnerabilityDistribution, 
  getVulnerabilityLanguageDistribution,
  getVulnerabilityCountByLanguage
} from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

interface ScanResultsSummaryProps {
  repositoryId: number;
}

export function ScanResultsSummary({ repositoryId }: ScanResultsSummaryProps) {
  const { data: vulnerabilities, isLoading } = useQuery<Vulnerability[]>({
    queryKey: [`/api/repositories/${repositoryId}/vulnerabilities`]
  });
  
  if (isLoading) {
    return (
      <div className="bg-background-light rounded-xl shadow-lg p-6 mb-8">
        <h3 className="text-lg font-medium mb-6">Scan Results Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-background rounded-lg p-4 border border-slate-700">
              <Skeleton className="h-20 w-full" />
            </div>
          ))}
        </div>
        <div className="bg-background rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-700">
            <Skeleton className="h-6 w-48" />
          </div>
          <div className="p-6">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-6 w-full mt-2" />
          </div>
        </div>
      </div>
    );
  }
  
  if (!vulnerabilities || vulnerabilities.length === 0) {
    return (
      <div className="bg-background-light rounded-xl shadow-lg p-6 mb-8">
        <h3 className="text-lg font-medium mb-6">Scan Results Summary</h3>
        <div className="text-center p-8">
          <p className="text-slate-400">No vulnerabilities found in this repository.</p>
        </div>
      </div>
    );
  }
  
  const stats = getVulnerabilityStats(vulnerabilities);
  const distribution = getVulnerabilityDistribution(stats);
  const languageCounts = getVulnerabilityCountByLanguage(vulnerabilities);
  const languageDistribution = getVulnerabilityLanguageDistribution(vulnerabilities);

  // Define colors for language distribution
  const languageColors: Record<string, string> = {
    java: '#f89820', // Java orange
    python: '#306998', // Python blue
    javascript: '#f0db4f', // JavaScript yellow
    typescript: '#007acc', // TypeScript blue
    unknown: '#5c5c5c' // Dark gray for unknown
  };

  return (
    <div className="bg-background-light rounded-xl shadow-lg p-6 mb-8">
      <h3 className="text-lg font-medium mb-6">Scan Results Summary</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-background rounded-lg p-4 border border-critical/30">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-critical/20 flex items-center justify-center mr-4">
              <span className="material-icons text-critical">error</span>
            </div>
            <div>
              <div className="text-3xl font-bold">{stats.critical}</div>
              <div className="text-sm text-slate-400">Critical Vulnerabilities</div>
            </div>
          </div>
        </div>
        
        <div className="bg-background rounded-lg p-4 border border-high/30">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-high/20 flex items-center justify-center mr-4">
              <span className="material-icons text-high">warning</span>
            </div>
            <div>
              <div className="text-3xl font-bold">{stats.high}</div>
              <div className="text-sm text-slate-400">High Vulnerabilities</div>
            </div>
          </div>
        </div>
        
        <div className="bg-background rounded-lg p-4 border border-moderate/30">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-moderate/20 flex items-center justify-center mr-4">
              <span className="material-icons text-moderate">info</span>
            </div>
            <div>
              <div className="text-3xl font-bold">{stats.moderate}</div>
              <div className="text-sm text-slate-400">Moderate Vulnerabilities</div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="bg-background rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-700">
            <h4 className="font-medium">Vulnerability Distribution</h4>
          </div>
          <div className="p-6">
            <div className="w-full h-8 flex rounded-lg overflow-hidden">
              <div className="bg-critical h-full" style={{ width: `${distribution.critical}%` }}></div>
              <div className="bg-high h-full" style={{ width: `${distribution.high}%` }}></div>
              <div className="bg-moderate h-full" style={{ width: `${distribution.moderate}%` }}></div>
            </div>
            <div className="flex justify-between mt-2 text-xs">
              <div className="flex items-center">
                <span className="w-3 h-3 bg-critical rounded-full mr-1"></span>
                <span>Critical ({distribution.critical}%)</span>
              </div>
              <div className="flex items-center">
                <span className="w-3 h-3 bg-high rounded-full mr-1"></span>
                <span>High ({distribution.high}%)</span>
              </div>
              <div className="flex items-center">
                <span className="w-3 h-3 bg-moderate rounded-full mr-1"></span>
                <span>Moderate ({distribution.moderate}%)</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-background rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-700">
            <h4 className="font-medium">Distribution by Language</h4>
          </div>
          <div className="p-6">
            {Object.keys(languageCounts).length > 0 ? (
              <>
                <div className="w-full h-8 flex rounded-lg overflow-hidden">
                  {Object.entries(languageDistribution).map(([language, percentage]) => (
                    <div 
                      key={language}
                      className="h-full"
                      style={{ 
                        width: `${percentage}%`, 
                        backgroundColor: languageColors[language] || '#5c5c5c' 
                      }}
                    ></div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-4 mt-2 text-xs">
                  {Object.entries(languageCounts).map(([language, count]) => (
                    <div key={language} className="flex items-center">
                      <span 
                        className="w-3 h-3 rounded-full mr-1"
                        style={{ backgroundColor: languageColors[language] || '#5c5c5c' }}
                      ></span>
                      <span className="capitalize">{language} ({languageDistribution[language]}%)</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-center text-slate-400 py-2">No language data available</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
