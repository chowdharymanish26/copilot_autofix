import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { ScanRequest, ScanProgress } from '@/types';

export function useScanRepository() {
  const [repositoryId, setRepositoryId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { mutate, isPending } = useMutation({
    mutationFn: async (data: ScanRequest) => {
      const res = await apiRequest('POST', '/api/scan', data);
      return res.json();
    },
    onSuccess: (data) => {
      setRepositoryId(data.repositoryId);
      toast({
        title: 'Repository scan started',
        description: 'The scanning process has been initiated.',
      });
      
      // Set up polling for scan progress
      const interval = setInterval(async () => {
        try {
          const res = await fetch(`/api/scan/${data.repositoryId}/progress`);
          if (!res.ok) {
            clearInterval(interval);
            return;
          }
          
          const progress: ScanProgress = await res.json();
          
          // If completed or failed, stop polling
          if (progress.status === 'completed' || progress.status === 'failed') {
            clearInterval(interval);
            
            // Invalidate queries to fetch updated data
            queryClient.invalidateQueries({ queryKey: ['/api/repositories'] });
            queryClient.invalidateQueries({ 
              queryKey: [`/api/repositories/${data.repositoryId}`] 
            });
            queryClient.invalidateQueries({ 
              queryKey: [`/api/repositories/${data.repositoryId}/vulnerabilities`] 
            });
            
            // Show toast based on status
            if (progress.status === 'completed') {
              toast({
                title: 'Scan completed',
                description: 'Repository scan has been completed successfully.',
              });
            } else {
              toast({
                title: 'Scan failed',
                description: 'There was an error scanning the repository.',
                variant: 'destructive',
              });
            }
          }
        } catch (error) {
          console.error('Error polling scan progress:', error);
          clearInterval(interval);
        }
      }, 2000);
      
      // Clean up interval on component unmount
      return () => clearInterval(interval);
    },
    onError: (error) => {
      console.error('Error scanning repository:', error);
      toast({
        title: 'Error',
        description: `Failed to scan repository: ${error}`,
        variant: 'destructive',
      });
    },
  });

  return {
    scanRepository: mutate,
    isScanning: isPending,
    repositoryId,
  };
}
