import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Repository, Vulnerability } from '@/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getVulnerabilityStats } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

export default function Dashboard() {
  const { data: repositories, isLoading: isLoadingRepos } = useQuery<Repository[]>({
    queryKey: ['/api/repositories']
  });
  
  // Helper function to get all vulnerabilities for all repositories
  const getVulnerabilities = async () => {
    if (!repositories || repositories.length === 0) return [];
    
    const allVulnerabilities: Vulnerability[] = [];
    
    for (const repo of repositories) {
      const response = await fetch(`/api/repositories/${repo.id}/vulnerabilities`);
      if (response.ok) {
        const vulnerabilities: Vulnerability[] = await response.json();
        allVulnerabilities.push(...vulnerabilities);
      }
    }
    
    return allVulnerabilities;
  };
  
  const { data: vulnerabilities, isLoading: isLoadingVulns } = useQuery<Vulnerability[]>({
    queryKey: ['/api/vulnerabilities/all'],
    queryFn: getVulnerabilities,
    enabled: !!repositories && repositories.length > 0
  });
  
  const isLoading = isLoadingRepos || isLoadingVulns;
  
  if (isLoading) {
    return (
      <div className="p-6 max-w-6xl mx-auto">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">Dashboard</h2>
          <p className="text-slate-400">Overview of your repositories and vulnerabilities</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {[1, 2, 3].map(i => (
            <Card key={i} className="bg-background-light border-slate-700">
              <CardHeader className="pb-2">
                <Skeleton className="h-5 w-32" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-2" />
                <Skeleton className="h-4 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="bg-background-light border-slate-700">
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-40 w-full" />
            </CardContent>
          </Card>
          
          <Card className="bg-background-light border-slate-700">
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-40 w-full" />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }
  
  const repoCount = repositories?.length || 0;
  const stats = vulnerabilities ? getVulnerabilityStats(vulnerabilities) : { critical: 0, high: 0, moderate: 0, total: 0 };
  
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">Dashboard</h2>
        <p className="text-slate-400">Overview of your repositories and vulnerabilities</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-background-light border-slate-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Repositories</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold mb-1">{repoCount}</p>
            <p className="text-sm text-slate-400">
              {repoCount === 0 
                ? "No repositories scanned yet" 
                : `${repoCount} ${repoCount === 1 ? 'repository' : 'repositories'} scanned`}
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-background-light border-slate-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Vulnerabilities</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold mb-1">{stats.total}</p>
            <p className="text-sm text-slate-400">
              {stats.total === 0 
                ? "No vulnerabilities found" 
                : `Across all scanned repositories`}
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-background-light border-slate-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Critical Issues</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-critical mb-1">{stats.critical}</p>
            <p className="text-sm text-slate-400">
              {stats.critical === 0 
                ? "No critical vulnerabilities" 
                : `Requiring immediate attention`}
            </p>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="bg-background-light border-slate-700">
          <CardHeader>
            <CardTitle>Recent Repositories</CardTitle>
            <CardDescription>Your recently scanned repositories</CardDescription>
          </CardHeader>
          <CardContent>
            {!repositories || repositories.length === 0 ? (
              <div className="text-center py-6">
                <p className="text-slate-400 mb-4">No repositories scanned yet</p>
                <Button asChild>
                  <Link href="/scanner">Scan Repository</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {repositories.slice(0, 5).map(repo => (
                  <div key={repo.id} className="flex justify-between items-center p-3 bg-background rounded-lg">
                    <div>
                      <p className="font-medium">
                        {repo.owner}/{repo.name}
                      </p>
                      <p className="text-xs text-slate-400">
                        Status: {repo.status.charAt(0).toUpperCase() + repo.status.slice(1)}
                      </p>
                    </div>
                    <Button asChild variant="outline" size="sm">
                      <Link href={`/scanner?repo=${repo.id}`}>View Details</Link>
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card className="bg-background-light border-slate-700">
          <CardHeader>
            <CardTitle>Vulnerability Breakdown</CardTitle>
            <CardDescription>Distribution of vulnerabilities by severity</CardDescription>
          </CardHeader>
          <CardContent>
            {!vulnerabilities || vulnerabilities.length === 0 ? (
              <div className="text-center py-6">
                <p className="text-slate-400">No vulnerabilities found yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Critical</span>
                    <span className="text-sm font-medium">{stats.critical}</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div 
                      className="bg-critical h-2 rounded-full" 
                      style={{ width: `${stats.total ? (stats.critical / stats.total) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">High</span>
                    <span className="text-sm font-medium">{stats.high}</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div 
                      className="bg-high h-2 rounded-full" 
                      style={{ width: `${stats.total ? (stats.high / stats.total) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Moderate</span>
                    <span className="text-sm font-medium">{stats.moderate}</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div 
                      className="bg-moderate h-2 rounded-full" 
                      style={{ width: `${stats.total ? (stats.moderate / stats.total) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="bg-slate-800 rounded-xl p-6 flex flex-col items-center text-center">
          <div className="rounded-lg mb-4 w-full h-48 bg-slate-700 flex items-center justify-center">
            <span className="material-icons text-6xl text-slate-500">code</span>
          </div>
          <h3 className="text-lg font-medium mb-2">Advanced Pattern Detection</h3>
          <p className="text-sm text-slate-400">Our pattern detection engine scans your Java code for common security vulnerabilities and suggests the best fixes.</p>
        </div>
        
        <div className="bg-slate-800 rounded-xl p-6 flex flex-col items-center text-center">
          <div className="rounded-lg mb-4 w-full h-48 bg-slate-700 flex items-center justify-center">
            <span className="material-icons text-6xl text-slate-500">security</span>
          </div>
          <h3 className="text-lg font-medium mb-2">Snyk Integration</h3>
          <p className="text-sm text-slate-400">VulnrFixer combines both custom pattern detection and Snyk's powerful vulnerability database for comprehensive coverage.</p>
        </div>
      </div>
    </div>
  );
}
