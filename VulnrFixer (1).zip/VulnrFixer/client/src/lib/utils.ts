import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Vulnerability, VulnerabilityStats } from "@/types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getVulnerabilityStats(vulnerabilities: Vulnerability[]): VulnerabilityStats {
  const stats = vulnerabilities.reduce(
    (acc, vuln) => {
      if (vuln.severity === 'critical') acc.critical++;
      else if (vuln.severity === 'high') acc.high++;
      else if (vuln.severity === 'moderate') acc.moderate++;
      
      acc.total++;
      return acc;
    },
    { critical: 0, high: 0, moderate: 0, total: 0 }
  );
  
  return stats;
}

export function getVulnerabilityCountByLanguage(vulnerabilities: Vulnerability[]): Record<string, number> {
  const languageCounts: Record<string, number> = {};
  
  for (const vuln of vulnerabilities) {
    const language = vuln.language || 'unknown';
    languageCounts[language] = (languageCounts[language] || 0) + 1;
  }
  
  return languageCounts;
}

export function getVulnerabilityLanguageDistribution(vulnerabilities: Vulnerability[]): Record<string, number> {
  const languageCounts = getVulnerabilityCountByLanguage(vulnerabilities);
  const totalVulnerabilities = vulnerabilities.length;
  
  if (totalVulnerabilities === 0) {
    return {};
  }
  
  const distribution: Record<string, number> = {};
  
  for (const [language, count] of Object.entries(languageCounts)) {
    distribution[language] = parseFloat(((count / totalVulnerabilities) * 100).toFixed(1));
  }
  
  return distribution;
}

export function getVulnerabilityDistribution(stats: VulnerabilityStats): { 
  critical: number; 
  high: number; 
  moderate: number; 
} {
  const total = stats.total;
  
  if (total === 0) {
    return { critical: 0, high: 0, moderate: 0 };
  }
  
  return {
    critical: parseFloat(((stats.critical / total) * 100).toFixed(1)),
    high: parseFloat(((stats.high / total) * 100).toFixed(1)),
    moderate: parseFloat(((stats.moderate / total) * 100).toFixed(1))
  };
}

export function parseGitHubUrl(url: string): { owner: string; repo: string } | null {
  try {
    const urlObj = new URL(url);
    if (urlObj.hostname !== 'github.com') {
      return null;
    }
    
    const pathParts = urlObj.pathname.split('/').filter(Boolean);
    if (pathParts.length < 2) {
      return null;
    }
    
    return { owner: pathParts[0], repo: pathParts[1] };
  } catch (error) {
    return null;
  }
}

export function formatDateFromISOString(isoString: string | undefined): string {
  if (!isoString) return 'N/A';
  
  try {
    const date = new Date(isoString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(date);
  } catch (error) {
    return 'Invalid date';
  }
}

export function getElapsedTime(isoString: string | undefined): string {
  if (!isoString) return '';
  
  try {
    const startDate = new Date(isoString);
    const now = new Date();
    const differenceMs = now.getTime() - startDate.getTime();
    
    // Convert to seconds
    const differenceSeconds = Math.floor(differenceMs / 1000);
    
    if (differenceSeconds < 60) {
      return `${differenceSeconds} seconds ago`;
    }
    
    // Convert to minutes
    const differenceMinutes = Math.floor(differenceSeconds / 60);
    
    if (differenceMinutes < 60) {
      return `${differenceMinutes} minute${differenceMinutes > 1 ? 's' : ''} ago`;
    }
    
    // Convert to hours
    const differenceHours = Math.floor(differenceMinutes / 60);
    
    if (differenceHours < 24) {
      return `${differenceHours} hour${differenceHours > 1 ? 's' : ''} ago`;
    }
    
    // Convert to days
    const differenceDays = Math.floor(differenceHours / 24);
    return `${differenceDays} day${differenceDays > 1 ? 's' : ''} ago`;
    
  } catch (error) {
    return '';
  }
}

export function truncateUrl(url: string, maxLength = 30): string {
  if (url.length <= maxLength) return url;
  
  // Extract domain and path
  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname;
    const path = urlObj.pathname;
    
    // If just the domain is too long
    if (domain.length >= maxLength - 3) {
      return domain.substring(0, maxLength - 3) + '...';
    }
    
    // Otherwise truncate the path
    const availableSpace = maxLength - domain.length - 4; // -4 for ellipsis and slashes
    const truncatedPath = path.substring(0, availableSpace) + '...';
    
    return `${domain}${truncatedPath}`;
  } catch (error) {
    // Fallback to simple truncation
    return url.substring(0, maxLength - 3) + '...';
  }
}

export function parseCodeForDiff(code: string): string[] {
  if (!code) return [];
  return code.split('\n');
}
