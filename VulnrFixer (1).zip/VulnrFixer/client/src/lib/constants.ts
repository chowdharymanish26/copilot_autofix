export const APP_NAME = "VulnrFixer";
export const APP_VERSION = "1.0.0";

export const SEVERITY_COLORS = {
  critical: "text-critical bg-critical/20 border-critical/30",
  high: "text-high bg-high/20 border-high/30",
  moderate: "text-moderate bg-moderate/20 border-moderate/30"
};

export const SEVERITY_LABELS = {
  critical: "Critical",
  high: "High",
  moderate: "Moderate"
};

export const STATUS_LABELS = {
  pending: "Pending",
  scanning: "Scanning",
  pattern_detection: "Pattern Detection",
  snyk_scanning: "Snyk Scanning",
  analyzing: "Analyzing Results",
  completed: "Completed",
  failed: "Failed"
};

export const SNYK_API_TOKEN = "2f5930de-9c8e-4828-98c7-ef6ef85993a4";
export const SNYK_API_TOKEN_MASKED = "2f5930de-9c8e-*****-****-**********";
