// Repository types
export interface Repository {
  id: number;
  url: string;
  name: string;
  owner: string;
  scannedAt: string;
  status: 'pending' | 'scanning' | 'completed' | 'failed';
}

// Vulnerability types
export interface Vulnerability {
  id: number;
  repositoryId: number;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'moderate';
  filePath: string;
  lineNumber: number;
  detectedBy: 'pattern' | 'snyk' | 'both';
  originalCode: string;
  fixedCode: string;
  status: 'pending' | 'accepted' | 'rejected';
  language?: string; // Optional language field
}

// Scan progress types
export interface ScanProgress {
  id: number;
  repositoryId: number;
  status: 'scanning' | 'pattern_detection' | 'snyk_scanning' | 'analyzing' | 'completed' | 'failed';
  patternDetectionProgress: number;
  snykProgress: number;
  analysisProgress: number;
}

// Scan request type
export interface ScanRequest {
  url: string;
  usePatternDetection: boolean;
  useSnyk: boolean;
}

// Statistics types
export interface VulnerabilityStats {
  critical: number;
  high: number;
  moderate: number;
  total: number;
}

// Code diff line
export interface DiffLine {
  lineNumber: number;
  content: string;
  type: 'context' | 'added' | 'removed';
}

// Form input error
export interface InputError {
  message: string;
}
