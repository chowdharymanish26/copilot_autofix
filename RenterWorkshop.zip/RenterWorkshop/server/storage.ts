import { 
  repositories, 
  vulnerabilities, 
  activities, 
  users,
  type Repository, 
  type InsertRepository,
  type Vulnerability,
  type InsertVulnerability,
  type Activity,
  type InsertActivity,
  type User,
  type InsertUser,
  type DashboardStats,
  VulnerabilityStatus
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Repository operations
  getRepositories(): Promise<Repository[]>;
  getRepository(id: number): Promise<Repository | undefined>;
  createRepository(repository: InsertRepository): Promise<Repository>;
  updateRepository(id: number, data: Partial<Repository>): Promise<Repository | undefined>;
  
  // Vulnerability operations
  getVulnerabilities(): Promise<Vulnerability[]>;
  getVulnerability(id: number): Promise<Vulnerability | undefined>;
  getVulnerabilitiesByRepository(repositoryId: number): Promise<Vulnerability[]>;
  getVulnerabilitiesByRepositoryAndFilePath(repositoryId: number, filePath: string): Promise<Vulnerability[]>;
  getVulnerabilitiesByStatus(status: VulnerabilityStatus): Promise<Vulnerability[]>;
  createVulnerability(vulnerability: InsertVulnerability): Promise<Vulnerability>;
  updateVulnerability(id: number, data: Partial<Vulnerability>): Promise<Vulnerability | undefined>;
  
  // Activity operations
  getActivities(limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Dashboard stats
  getDashboardStats(): Promise<DashboardStats>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private repositories: Map<number, Repository>;
  private vulnerabilities: Map<number, Vulnerability>;
  private activities: Map<number, Activity>;
  
  private userIdCounter: number;
  private repoIdCounter: number;
  private vulnIdCounter: number;
  private activityIdCounter: number;

  constructor() {
    this.users = new Map();
    this.repositories = new Map();
    this.vulnerabilities = new Map();
    this.activities = new Map();
    
    this.userIdCounter = 1;
    this.repoIdCounter = 1;
    this.vulnIdCounter = 1;
    this.activityIdCounter = 1;
    
    // Initialize with some sample data
    this.initializeData();
  }

  private initializeData() {
    // This would normally be empty in production, but for demonstration purposes
    // we'll add some initial data to make the app functional from the start
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id,
      avatarUrl: insertUser.avatarUrl || null
    };
    this.users.set(id, user);
    return user;
  }

  // Repository operations
  async getRepositories(): Promise<Repository[]> {
    return Array.from(this.repositories.values());
  }

  async getRepository(id: number): Promise<Repository | undefined> {
    return this.repositories.get(id);
  }

  async createRepository(insertRepo: InsertRepository): Promise<Repository> {
    const id = this.repoIdCounter++;
    const repo: Repository = { 
      ...insertRepo, 
      id, 
      description: insertRepo.description || null,
      code: insertRepo.code || null,
      languages: Array.isArray(insertRepo.languages) ? (insertRepo.languages as string[]) : [],
      lastScanDate: insertRepo.lastScanDate || null,
      issueCount: 0
    };
    
    this.repositories.set(id, repo);
    
    await this.createActivity({
      activityType: "repository_added",
      description: `Repository ${repo.name} added`,
      repositoryId: id
    });
    
    return repo;
  }

  async updateRepository(id: number, data: Partial<Repository>): Promise<Repository | undefined> {
    const repo = this.repositories.get(id);
    if (!repo) return undefined;
    
    const updatedRepo = { ...repo, ...data };
    this.repositories.set(id, updatedRepo);
    return updatedRepo;
  }

  // Vulnerability operations
  async getVulnerabilities(): Promise<Vulnerability[]> {
    return Array.from(this.vulnerabilities.values());
  }

  async getVulnerability(id: number): Promise<Vulnerability | undefined> {
    return this.vulnerabilities.get(id);
  }

  async getVulnerabilitiesByRepository(repositoryId: number): Promise<Vulnerability[]> {
    return Array.from(this.vulnerabilities.values()).filter(
      (vuln) => vuln.repositoryId === repositoryId
    );
  }
  
  async getVulnerabilitiesByRepositoryAndFilePath(repositoryId: number, filePath: string): Promise<Vulnerability[]> {
    return Array.from(this.vulnerabilities.values()).filter(
      (vuln) => vuln.repositoryId === repositoryId && vuln.filePath === filePath
    );
  }

  async getVulnerabilitiesByStatus(status: VulnerabilityStatus): Promise<Vulnerability[]> {
    return Array.from(this.vulnerabilities.values()).filter(
      (vuln) => vuln.status === status
    );
  }

  async createVulnerability(insertVuln: InsertVulnerability): Promise<Vulnerability> {
    const id = this.vulnIdCounter++;
    const createdAt = new Date();
    const vulnerability: Vulnerability = { 
      ...insertVuln, 
      id, 
      createdAt,
      // Ensure required fields have values
      status: insertVuln.status || VulnerabilityStatus.PENDING_REVIEW,
      detectionMethod: insertVuln.detectionMethod || null,
      originalCode: insertVuln.originalCode || null,
      fixedCode: insertVuln.fixedCode || null,
      potentialImpact: Array.isArray(insertVuln.potentialImpact) ? (insertVuln.potentialImpact as string[]) : [],
      recommendations: Array.isArray(insertVuln.recommendations) ? (insertVuln.recommendations as string[]) : []
    };
    
    this.vulnerabilities.set(id, vulnerability);
    
    // Update repository issue count
    const repo = this.repositories.get(vulnerability.repositoryId);
    if (repo) {
      this.repositories.set(repo.id, {
        ...repo,
        issueCount: typeof repo.issueCount === 'number' ? repo.issueCount + 1 : 1
      });
    }
    
    // Create activity for this vulnerability
    await this.createActivity({
      activityType: "vulnerability_detected",
      description: `${vulnerability.severity.toUpperCase()} vulnerability detected: ${vulnerability.title}`,
      repositoryId: vulnerability.repositoryId,
      vulnerabilityId: id
    });
    
    return vulnerability;
  }

  async updateVulnerability(id: number, data: Partial<Vulnerability>): Promise<Vulnerability | undefined> {
    const vuln = this.vulnerabilities.get(id);
    if (!vuln) return undefined;
    
    const updatedVuln = { ...vuln, ...data };
    this.vulnerabilities.set(id, updatedVuln);
    
    // Create activity for status changes
    if (data.status && data.status !== vuln.status) {
      let activityType: string;
      let description: string;
      
      switch (data.status) {
        case VulnerabilityStatus.APPROVED:
          activityType = "vulnerability_fix_approved";
          description = `Fix approved for vulnerability: ${vuln.title}`;
          break;
        case VulnerabilityStatus.REJECTED:
          activityType = "vulnerability_fix_rejected";
          description = `Fix rejected for vulnerability: ${vuln.title}`;
          break;
        case VulnerabilityStatus.FIXED:
          activityType = "vulnerability_fixed";
          description = `Vulnerability fixed: ${vuln.title}`;
          // Update repository issue count
          const repo = this.repositories.get(vuln.repositoryId);
          if (repo) {
            const currentIssueCount = typeof repo.issueCount === 'number' ? repo.issueCount : 0;
            const newIssueCount = Math.max(0, currentIssueCount - 1);
            this.repositories.set(repo.id, {
              ...repo,
              issueCount: newIssueCount
            });
          }
          break;
        default:
          activityType = "vulnerability_updated";
          description = `Vulnerability updated: ${vuln.title}`;
      }
      
      await this.createActivity({
        activityType,
        description,
        repositoryId: vuln.repositoryId,
        vulnerabilityId: id
      });
    }
    
    return updatedVuln;
  }

  // Activity operations
  async getActivities(limit?: number): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .sort((a, b) => {
        const timeA = a.timestamp ? a.timestamp.getTime() : 0;
        const timeB = b.timestamp ? b.timestamp.getTime() : 0;
        return timeB - timeA;
      });
    
    if (limit) {
      return activities.slice(0, limit);
    }
    
    return activities;
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const timestamp = new Date();
    const activity: Activity = { 
      ...insertActivity, 
      id, 
      timestamp,
      // Make sure optional fields are properly set
      repositoryId: insertActivity.repositoryId || null,
      vulnerabilityId: insertActivity.vulnerabilityId || null
    };
    
    this.activities.set(id, activity);
    return activity;
  }

  // Dashboard stats
  async getDashboardStats(): Promise<DashboardStats> {
    const vulnerabilities = await this.getVulnerabilities();
    const pendingReview = vulnerabilities.filter(
      v => v.status === VulnerabilityStatus.PENDING_REVIEW
    ).length;
    const fixed = vulnerabilities.filter(
      v => v.status === VulnerabilityStatus.FIXED
    ).length;
    const open = vulnerabilities.filter(
      v => v.status === VulnerabilityStatus.OPEN
    ).length;
    
    return {
      repoCount: this.repositories.size,
      vulnerabilityCount: open,
      fixedCount: fixed,
      pendingReviewCount: pendingReview
    };
  }
}

export const storage = new MemStorage();
