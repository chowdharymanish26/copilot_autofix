import { useState, useEffect } from "react";

interface CodeDiffProps {
  originalCode: string;
  fixedCode: string;
}

type LineType = "removed" | "added" | "unchanged";

interface CodeLine {
  number: number;
  content: string;
  type: LineType;
}

export default function CodeDiff({ originalCode, fixedCode }: CodeDiffProps) {
  const [diffLines, setDiffLines] = useState<CodeLine[]>([]);
  
  useEffect(() => {
    const createDiff = () => {
      // Make sure we have valid input
      if (!originalCode || !fixedCode) {
        return [];
      }
      
      const originalLines = originalCode.split('\n');
      const fixedLines = fixedCode.split('\n');
      const result: CodeLine[] = [];
      
      // Simple line-by-line diff
      // In a real application, you would use a proper diff algorithm
      if (originalLines.length === fixedLines.length) {
        // Same number of lines, compare each line
        for (let i = 0; i < originalLines.length; i++) {
          if (originalLines[i] !== fixedLines[i]) {
            result.push({
              number: i + 1,
              content: originalLines[i],
              type: "removed"
            });
            result.push({
              number: i + 1,
              content: fixedLines[i],
              type: "added"
            });
          } else {
            result.push({
              number: i + 1,
              content: originalLines[i],
              type: "unchanged"
            });
          }
        }
      } else {
        // Special case: Check if the fixedCode is a multiline string that should be shown in context
        // For example, when fixing a single line to a more complex, multi-line solution
        if (originalLines.length === 1 && fixedLines.length > 1) {
          const lineNumber = originalLines[0].match(/\d+/) ? parseInt(originalLines[0].match(/\d+/)![0]) : 1;
          
          result.push({
            number: lineNumber,
            content: originalLines[0],
            type: "removed"
          });
          
          // Add fixed code lines with sequential numbers
          fixedLines.forEach((line, idx) => {
            result.push({
              number: lineNumber + idx,
              content: line,
              type: "added"
            });
          });
        } else {
          // Different number of lines, add context
          // First add some unchanged lines before the change if available
          const contextLines = 3;
          const minOriginal = Math.min(originalLines.length, fixedLines.length);
          
          // Find the first line that differs
          let firstDiff = 0;
          for (; firstDiff < minOriginal; firstDiff++) {
            if (originalLines[firstDiff] !== fixedLines[firstDiff]) {
              break;
            }
          }
          
          // Add context before the change
          const startContext = Math.max(0, firstDiff - contextLines);
          for (let i = startContext; i < firstDiff; i++) {
            result.push({
              number: i + 1,
              content: originalLines[i],
              type: "unchanged"
            });
          }
          
          // Add removed lines
          originalLines.slice(firstDiff).forEach((line, index) => {
            result.push({
              number: firstDiff + index + 1,
              content: line,
              type: "removed"
            });
          });
          
          // Add added lines
          fixedLines.slice(firstDiff).forEach((line, index) => {
            result.push({
              number: firstDiff + index + 1,
              content: line,
              type: "added"
            });
          });
        }
      }
      
      return result;
    };
    
    setDiffLines(createDiff());
  }, [originalCode, fixedCode]);

  // GitHub-like styling for diff lines
  const lineStyles: Record<LineType, string> = {
    removed: "bg-red-100",
    added: "bg-green-100",
    unchanged: ""
  };
  
  const lineWrapperStyles: Record<LineType, string> = {
    removed: "border-l-4 border-red-500",
    added: "border-l-4 border-green-500",
    unchanged: "border-l-4 border-transparent"
  };
  
  const textStyles: Record<LineType, string> = {
    removed: "text-red-800",
    added: "text-green-800 font-medium",
    unchanged: "text-gray-800"
  };

  const getPrefix = (type: LineType) => {
    switch (type) {
      case "removed": return "- ";
      case "added": return "+ ";
      default: return "  ";
    }
  };

  if (diffLines.length === 0) {
    return (
      <div className="p-4 text-gray-500 italic">
        No code changes available.
      </div>
    );
  }

  return (
    <div className="code-block overflow-x-auto text-sm font-mono" style={{ maxHeight: "300px" }}>
      {/* GitHub-like diff header */}
      <div className="flex items-center px-3 py-1 bg-gray-50 border-b border-gray-200 text-xs text-gray-700">
        <span className="flex-1">Diff: Security fix</span>
      </div>
      
      {/* Diff content */}
      <table className="min-w-full border-collapse">
        <tbody>
          {diffLines.map((line, index) => (
            <tr key={index} className={`${lineStyles[line.type]} hover:bg-gray-50 ${lineWrapperStyles[line.type]}`}>
              <td className="py-0 pl-2 pr-2 text-right text-gray-500 select-none w-10 text-xs border-r border-gray-200 bg-gray-50">
                {line.number}
              </td>
              <td className={`py-0 pl-3 pr-6 whitespace-pre ${textStyles[line.type]}`}>
                {getPrefix(line.type)}{line.content}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {/* Diff footer - GitHub style */}
      <div className="flex items-center px-3 py-1 bg-gray-50 border-t border-gray-200 text-xs text-gray-700 justify-between">
        <span>Showing changes</span>
        <span>Generated by CodeGuardian</span>
      </div>
    </div>
  );
}
