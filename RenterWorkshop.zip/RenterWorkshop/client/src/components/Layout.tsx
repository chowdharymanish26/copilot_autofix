import { ReactNode, useState } from "react";
import Sidebar from "./Sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Menu, Search } from "lucide-react";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar for desktop */}
      <div className={`hidden md:flex md:flex-col md:w-64 bg-gray-800 text-white`}>
        <Sidebar />
      </div>
      
      {/* Mobile sidebar */}
      <div 
        className={`fixed inset-0 bg-gray-800 text-white z-50 transform md:hidden transition-transform duration-300 ease-in-out ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <Sidebar onClose={() => setIsSidebarOpen(false)} />
      </div>
      
      {/* Main content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Navigation */}
        <header className="bg-white border-b border-gray-200">
          <div className="flex justify-between items-center px-4 py-3">
            <div className="flex items-center md:hidden">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setIsSidebarOpen(true)}
                aria-label="Open menu"
              >
                <Menu className="h-5 w-5" />
              </Button>
              <h1 className="ml-3 font-bold text-lg">CodeGuardian</h1>
            </div>
            
            <div className="flex-1 max-w-3xl mx-auto md:mx-0 md:ml-8">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input 
                  type="text" 
                  placeholder="Search repositories or vulnerabilities..." 
                  className="w-full pl-10 pr-4 py-2" 
                />
              </div>
            </div>
            
            <div className="flex items-center">
              <Button variant="ghost" size="icon" className="ml-1">
                <span className="relative">
                  <i className="ri-notification-3-line text-xl"></i>
                  <span className="absolute -top-1 -right-1 bg-red-500 rounded-full w-2 h-2"></span>
                </span>
              </Button>
              <Button variant="ghost" size="icon" className="ml-1">
                <i className="ri-settings-4-line text-xl"></i>
              </Button>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-6 pb-24">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
