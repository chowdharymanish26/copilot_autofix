import { ReactNode } from "react";
import { Card } from "@/components/ui/card";

interface StatCardProps {
  title: string;
  value: number;
  icon: ReactNode;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
  changeValue: number;
  changePeriod: string;
}

export default function StatCard({
  title,
  value,
  icon,
  iconBgColor,
  iconColor,
  borderColor,
  changeValue,
  changePeriod
}: StatCardProps) {
  const isPositiveChange = changeValue >= 0;
  
  return (
    <Card className={`border-l-4 ${borderColor}`}>
      <div className="p-5">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-gray-500 text-sm font-medium">{title}</p>
            <p className="mt-2 text-3xl font-bold text-gray-900">{value}</p>
          </div>
          <div className={`p-2 rounded-lg ${iconBgColor}`}>
            <div className={iconColor}>{icon}</div>
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <span className={`flex items-center ${isPositiveChange ? 'text-success-500' : 'text-danger-600'}`}>
            <i className={`${isPositiveChange ? 'ri-arrow-up-line' : 'ri-arrow-down-line'} mr-1`}></i> {Math.abs(changeValue)}
          </span>
          <span className="text-gray-500 ml-2">since {changePeriod}</span>
        </div>
      </div>
    </Card>
  );
}
