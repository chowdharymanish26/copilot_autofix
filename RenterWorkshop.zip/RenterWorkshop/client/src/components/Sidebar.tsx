import { Link, useLocation } from "wouter";

interface SidebarProps {
  onClose?: () => void;
}

export default function Sidebar({ onClose }: SidebarProps) {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  const navItems = [
    { path: "/", label: "Dashboard", icon: "ri-dashboard-line" },
    { path: "/repositories", label: "Repositories", icon: "ri-git-repository-line" },
    { path: "/vulnerabilities", label: "Vulnerabilities", icon: "ri-error-warning-line" },
  ];
  
  return (
    <div className="flex flex-col h-full">
      <div className="p-4 flex items-center border-b border-gray-700">
        {onClose && (
          <button 
            onClick={onClose} 
            className="mr-2 text-gray-400 hover:text-white md:hidden"
            aria-label="Close menu"
          >
            <i className="ri-close-line text-xl"></i>
          </button>
        )}
        <i className="ri-shield-check-line text-primary-500 text-2xl mr-2"></i>
        <h1 className="font-bold text-lg">CodeGuardian</h1>
      </div>
      
      <nav className="flex-1 overflow-y-auto py-4">
        <div className="px-4 mb-2 text-gray-400 text-xs font-semibold uppercase tracking-wider">
          Main
        </div>
        
        {navItems.map((item) => (
          <Link 
            key={item.path}
            href={item.path}
            onClick={onClose}
            className={`flex items-center px-4 py-2 ${
              isActive(item.path) 
                ? "text-gray-100 bg-gray-700" 
                : "text-gray-300 hover:bg-gray-700"
            }`}
          >
            <i className={`${item.icon} mr-3 text-lg`}></i>
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
