import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import StatCard from "@/components/StatCard";
import VulnerabilityItem from "@/components/VulnerabilityItem";
import VulnerabilityDetails from "@/components/VulnerabilityDetails";
import ActivityItem from "@/components/ActivityItem";
import RepositoryCard from "@/components/RepositoryCard";
import { ExternalLink, RefreshCw, GitBranch, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { scanRepository } from "@/utils/codeAnalysis";
import { Vulnerability, VulnerabilityStatus } from "@shared/schema";

export default function Dashboard() {
  const [isScanning, setIsScanning] = useState(false);
  const [selectedVulnerabilityId, setSelectedVulnerabilityId] = useState<number | null>(null);
  const { toast } = useToast();

  // Fetch dashboard stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/stats'],
  });

  // Fetch pending review vulnerabilities
  const { data: pendingVulnerabilities, isLoading: isLoadingVulnerabilities } = useQuery({
    queryKey: ['/api/vulnerabilities', { status: VulnerabilityStatus.PENDING_REVIEW }],
  });

  // Fetch recent activities
  const { data: activities, isLoading: isLoadingActivities } = useQuery({
    queryKey: ['/api/activities', { limit: 4 }],
  });

  // Fetch repositories
  const { data: repositories, isLoading: isLoadingRepositories } = useQuery({
    queryKey: ['/api/repositories'],
  });

  // Get selected vulnerability details
  const selectedVulnerability = pendingVulnerabilities?.find(
    (v: Vulnerability) => v.id === selectedVulnerabilityId
  );

  // Handle scan button click
  const handleScan = async () => {
    setIsScanning(true);
    try {
      if (repositories && repositories.length > 0) {
        await scanRepository(repositories[0].id);
        toast({
          title: "Scan Complete",
          description: "Repository scan completed successfully.",
        });
      }
    } catch (error) {
      toast({
        title: "Scan Failed",
        description: "Failed to scan repositories. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <>
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Overview of security vulnerabilities and fixes</p>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {isLoadingStats ? (
          // Skeleton loaders for stats
          Array(4).fill(0).map((_, index) => (
            <div key={index} className="bg-white rounded-lg shadow p-5">
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-10 w-16 mt-2 mb-4" />
              <Skeleton className="h-4 w-32" />
            </div>
          ))
        ) : (
          // Actual stat cards
          <>
            <StatCard
              title="Repositories"
              value={stats?.repoCount || 0}
              icon={<GitBranch className="h-5 w-5" />}
              iconBgColor="bg-primary-50"
              iconColor="text-primary-500"
              borderColor="border-primary-500"
              changeValue={3}
              changePeriod="last month"
            />
            <StatCard
              title="Open Vulnerabilities"
              value={stats?.vulnerabilityCount || 0}
              icon={<AlertTriangle className="h-5 w-5" />}
              iconBgColor="bg-danger-50"
              iconColor="text-danger-600"
              borderColor="border-danger-600"
              changeValue={7}
              changePeriod="yesterday"
            />
            <StatCard
              title="Fixed Issues"
              value={stats?.fixedCount || 0}
              icon={<CheckCircle className="h-5 w-5" />}
              iconBgColor="bg-success-50"
              iconColor="text-success-600"
              borderColor="border-success-600"
              changeValue={12}
              changePeriod="last week"
            />
            <StatCard
              title="Pending Review"
              value={stats?.pendingReviewCount || 0}
              icon={<Clock className="h-5 w-5" />}
              iconBgColor="bg-warning-50"
              iconColor="text-warning-600"
              borderColor="border-warning-600"
              changeValue={-2}
              changePeriod="yesterday"
            />
          </>
        )}
      </div>

      {/* Vulnerability Review Section */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900">Pending Reviews</h2>
          <Button 
            onClick={handleScan} 
            disabled={isScanning}
            className="bg-primary-600 hover:bg-primary-700"
          >
            <RefreshCw className={`mr-1 h-4 w-4 ${isScanning ? 'animate-spin' : ''}`} /> Scan Again
          </Button>
        </div>

        <div className="bg-white rounded-lg shadow overflow-hidden">
          {/* Table Header */}
          <div className="border-b border-gray-200 bg-gray-50 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
            <div className="grid grid-cols-12 gap-4">
              <div className="col-span-5">Issue</div>
              <div className="col-span-2">Severity</div>
              <div className="col-span-3">Repository</div>
              <div className="col-span-2">Actions</div>
            </div>
          </div>

          {/* Table Body */}
          <div>
            {isLoadingVulnerabilities ? (
              // Skeleton loaders for vulnerabilities
              Array(3).fill(0).map((_, index) => (
                <div key={index} className="border-b border-gray-200 px-6 py-4">
                  <div className="grid grid-cols-12 gap-4 items-center">
                    <div className="col-span-5">
                      <Skeleton className="h-5 w-48 mb-2" />
                      <Skeleton className="h-4 w-72" />
                    </div>
                    <div className="col-span-2">
                      <Skeleton className="h-6 w-16 rounded-full" />
                    </div>
                    <div className="col-span-3">
                      <Skeleton className="h-4 w-24" />
                    </div>
                    <div className="col-span-2">
                      <Skeleton className="h-8 w-16 rounded" />
                    </div>
                  </div>
                </div>
              ))
            ) : pendingVulnerabilities?.length ? (
              // Actual vulnerabilities
              pendingVulnerabilities.map((vulnerability: Vulnerability) => (
                <VulnerabilityItem
                  key={vulnerability.id}
                  vulnerability={vulnerability}
                  onReview={(id) => setSelectedVulnerabilityId(id)}
                />
              ))
            ) : (
              // Empty state
              <div className="px-6 py-8 text-center">
                <p className="text-gray-500 mb-4">No vulnerabilities pending review</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleScan} 
                  disabled={isScanning}
                >
                  <RefreshCw className={`mr-1 h-4 w-4 ${isScanning ? 'animate-spin' : ''}`} /> Scan repositories
                </Button>
              </div>
            )}
          </div>

          {/* Expanded Vulnerability Details */}
          {selectedVulnerability && (
            <VulnerabilityDetails
              vulnerability={selectedVulnerability}
              onClose={() => setSelectedVulnerabilityId(null)}
            />
          )}
        </div>

        <div className="mt-4 text-center">
          <Link href="/vulnerabilities">
            <Button variant="link" className="text-primary-600 hover:text-primary-800">
              View all vulnerabilities <ExternalLink className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Recent Activity Section */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
        
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="divide-y divide-gray-200">
            {isLoadingActivities ? (
              // Skeleton loaders for activities
              Array(4).fill(0).map((_, index) => (
                <div key={index} className="p-4 flex items-start space-x-4">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-64 mb-2" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                </div>
              ))
            ) : activities?.length ? (
              // Actual activities
              activities.map((activity) => (
                <ActivityItem key={activity.id} activity={activity} />
              ))
            ) : (
              // Empty state
              <div className="p-8 text-center">
                <p className="text-gray-500">No recent activity</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Repository Overview Section */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900">Repository Health</h2>
          <Link href="/repositories">
            <Button variant="link" className="text-primary-600 hover:text-primary-800">
              All repositories <ExternalLink className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoadingRepositories ? (
            // Skeleton loaders for repositories
            Array(3).fill(0).map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow overflow-hidden">
                <div className="p-4 border-b border-gray-200">
                  <div className="flex justify-between items-start">
                    <Skeleton className="h-5 w-32 mb-2" />
                    <Skeleton className="h-6 w-16 rounded-full" />
                  </div>
                  <Skeleton className="h-4 w-full mt-2" />
                </div>
                <div className="p-4 bg-gray-50">
                  <div className="flex items-center justify-between mb-2">
                    <Skeleton className="h-4 w-16" />
                    <div className="flex space-x-1">
                      <Skeleton className="h-5 w-16 rounded-full" />
                      <Skeleton className="h-5 w-16 rounded-full" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
              </div>
            ))
          ) : repositories?.length ? (
            // Actual repositories
            repositories.slice(0, 3).map((repository) => (
              <RepositoryCard
                key={repository.id}
                repository={repository}
                onClick={() => {}}
              />
            ))
          ) : (
            // Empty state
            <div className="col-span-3 bg-white rounded-lg shadow p-8 text-center">
              <p className="text-gray-500 mb-4">No repositories added yet</p>
              <Link href="/repositories">
                <Button size="sm">Add Repository</Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
