import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import RepositoryCard from "@/components/RepositoryCard";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { scanRepository } from "@/utils/codeAnalysis";
import { PlusCircle, RefreshCw } from "lucide-react";
import { Repository } from "@shared/schema";

export default function Repositories() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanningRepoId, setScanningRepoId] = useState<number | null>(null);
  const [newRepo, setNewRepo] = useState({
    name: "",
    description: "",
    url: "",
    languages: ["JavaScript", "TypeScript"], // Default languages
    code: "" // Sample code for vulnerability scanning
  });
  
  const { toast } = useToast();
  
  // Fetch repositories
  const { data: repositories = [], isLoading } = useQuery<Repository[]>({
    queryKey: ['/api/repositories'],
  });
  
  // Add new repository
  const handleAddRepository = async () => {
    try {
      const addedRepo = await apiRequest('POST', '/api/repositories', newRepo);
      
      queryClient.invalidateQueries({ queryKey: ['/api/repositories'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      
      setIsAddDialogOpen(false);
      setNewRepo({
        name: "",
        description: "",
        url: "",
        languages: ["JavaScript", "TypeScript"],
        code: ""
      });
      
      toast({
        title: "Repository Added",
        description: `${addedRepo.name} has been added successfully.`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add repository. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  // Scan repository
  const handleScanRepository = async (repositoryId: number) => {
    setIsScanning(true);
    setScanningRepoId(repositoryId);
    
    try {
      await scanRepository(repositoryId);
      
      queryClient.invalidateQueries({ queryKey: ['/api/vulnerabilities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/repositories'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      
      toast({
        title: "Scan Complete",
        description: "Repository scan completed successfully."
      });
    } catch (error) {
      toast({
        title: "Scan Failed",
        description: "Failed to scan repository. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsScanning(false);
      setScanningRepoId(null);
    }
  };
  
  return (
    <>
      {/* Page Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Repositories</h1>
          <p className="text-gray-600">Manage and scan your repositories for vulnerabilities</p>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <PlusCircle className="mr-2 h-4 w-4" /> Add Repository
        </Button>
      </div>
      
      {/* Repository Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          // Skeleton loaders
          Array(6).fill(0).map((_, index) => (
            <Card key={index} className="overflow-hidden">
              <div className="p-4 border-b border-gray-200">
                <div className="flex justify-between items-start">
                  <Skeleton className="h-5 w-32 mb-2" />
                  <Skeleton className="h-6 w-16 rounded-full" />
                </div>
                <Skeleton className="h-4 w-full mt-2" />
              </div>
              <div className="p-4 bg-gray-50">
                <div className="flex items-center justify-between mb-2">
                  <Skeleton className="h-4 w-16" />
                  <div className="flex space-x-1">
                    <Skeleton className="h-5 w-16 rounded-full" />
                    <Skeleton className="h-5 w-16 rounded-full" />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-4 w-24" />
                </div>
              </div>
            </Card>
          ))
        ) : repositories?.length ? (
          // Repository cards
          repositories.map((repository: Repository) => (
            <div key={repository.id} className="group relative">
              <RepositoryCard repository={repository} />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-5 transition-opacity flex items-center justify-center opacity-0 group-hover:opacity-100">
                <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={() => handleScanRepository(repository.id)}
                  disabled={isScanning && scanningRepoId === repository.id}
                >
                  <RefreshCw className={`mr-1 h-4 w-4 ${isScanning && scanningRepoId === repository.id ? 'animate-spin' : ''}`} />
                  Scan Now
                </Button>
              </div>
            </div>
          ))
        ) : (
          // Empty state
          <div className="col-span-3">
            <Card>
              <CardContent className="pt-6 flex flex-col items-center justify-center h-40">
                <p className="text-gray-500 mb-4">No repositories added yet</p>
                <Button onClick={() => setIsAddDialogOpen(true)}>
                  <PlusCircle className="mr-2 h-4 w-4" /> Add Repository
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
      
      {/* Add Repository Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Repository</DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Repository Name</Label>
              <Input 
                id="name" 
                value={newRepo.name} 
                onChange={(e) => setNewRepo({...newRepo, name: e.target.value})}
                placeholder="e.g., my-project"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Input 
                id="description" 
                value={newRepo.description} 
                onChange={(e) => setNewRepo({...newRepo, description: e.target.value})}
                placeholder="e.g., Backend API for user management"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="url">Repository URL</Label>
              <Input 
                id="url" 
                value={newRepo.url} 
                onChange={(e) => setNewRepo({...newRepo, url: e.target.value})}
                placeholder="e.g., https://github.com/username/repo"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="languages">Languages (comma separated)</Label>
              <Input 
                id="languages" 
                value={newRepo.languages.join(", ")} 
                onChange={(e) => setNewRepo({
                  ...newRepo, 
                  languages: e.target.value.split(",").map(lang => lang.trim()).filter(Boolean)
                })}
                placeholder="e.g., JavaScript, TypeScript, Python"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="code">Sample Code (for vulnerability scanning)</Label>
              <Textarea 
                id="code" 
                value={newRepo.code} 
                onChange={(e) => setNewRepo({...newRepo, code: e.target.value})}
                placeholder="Paste code here to scan for vulnerabilities"
                className="min-h-[150px] font-mono text-sm"
              />
              <p className="text-xs text-gray-500">Paste code samples that you want to scan for vulnerabilities.</p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddRepository} disabled={!newRepo.name || !newRepo.url}>
              Add Repository
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
