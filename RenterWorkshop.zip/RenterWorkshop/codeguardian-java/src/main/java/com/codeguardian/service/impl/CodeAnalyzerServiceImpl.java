package com.codeguardian.service.impl;

import com.codeguardian.model.Repository;
import com.codeguardian.model.SeverityLevel;
import com.codeguardian.model.Vulnerability;
import com.codeguardian.model.VulnerabilityStatus;
import com.codeguardian.model.dto.VulnerabilityDTO;
import com.codeguardian.repository.RepositoryRepository;
import com.codeguardian.repository.VulnerabilityRepository;
import com.codeguardian.service.ActivityService;
import com.codeguardian.service.CodeAnalyzerService;
import com.codeguardian.service.RepositoryService;
import com.codeguardian.util.EntityMapper;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
@Slf4j
public class CodeAnalyzerServiceImpl implements CodeAnalyzerService {

    private final RepositoryRepository repositoryRepository;
    private final VulnerabilityRepository vulnerabilityRepository;
    private final ActivityService activityService;
    private final RepositoryService repositoryService;
    
    // Vulnerability patterns for different types of issues
    private final Map<String, List<Pattern>> vulnerabilityPatterns = initializeVulnerabilityPatterns();
    
    // Suggested fixes for different types of vulnerabilities
    private final Map<String, String> fixPatterns = initializeFixPatterns();

    private Map<String, List<Pattern>> initializeVulnerabilityPatterns() {
        Map<String, List<Pattern>> patterns = new HashMap<>();
        
        // SQL Injection patterns
        List<Pattern> sqlInjectionPatterns = new ArrayList<>();
        sqlInjectionPatterns.add(Pattern.compile(".*execute\\(.*\\+.*\\).*"));
        sqlInjectionPatterns.add(Pattern.compile(".*executeQuery\\(.*\\+.*\\).*"));
        sqlInjectionPatterns.add(Pattern.compile(".*executeUpdate\\(.*\\+.*\\).*"));
        sqlInjectionPatterns.add(Pattern.compile(".*createStatement\\(\\).*"));
        sqlInjectionPatterns.add(Pattern.compile(".*\"SELECT.*\\+.*FROM.*"));
        sqlInjectionPatterns.add(Pattern.compile(".*\"INSERT.*\\+.*INTO.*"));
        sqlInjectionPatterns.add(Pattern.compile(".*\"UPDATE.*\\+.*SET.*"));
        patterns.put("SQL Injection", sqlInjectionPatterns);
        
        // XSS patterns
        List<Pattern> xssPatterns = new ArrayList<>();
        xssPatterns.add(Pattern.compile(".*innerHTML.*=.*"));
        xssPatterns.add(Pattern.compile(".*document\\.write\\(.*\\).*"));
        xssPatterns.add(Pattern.compile(".*eval\\(.*\\).*"));
        patterns.put("Cross-site Scripting (XSS)", xssPatterns);
        
        // Insecure direct object reference
        List<Pattern> idorPatterns = new ArrayList<>();
        idorPatterns.add(Pattern.compile(".*findById\\(.*request.*\\).*"));
        idorPatterns.add(Pattern.compile(".*getParameter\\(\"id\"\\).*"));
        patterns.put("Insecure Direct Object Reference", idorPatterns);
        
        // CSRF
        List<Pattern> csrfPatterns = new ArrayList<>();
        csrfPatterns.add(Pattern.compile(".*@CrossOrigin.*"));
        csrfPatterns.add(Pattern.compile(".*headers\\.set\\(\"Access-Control-Allow-Origin\", \"\\*\"\\).*"));
        patterns.put("Cross-site Request Forgery", csrfPatterns);
        
        // Java-specific patterns
        List<Pattern> javaPatterns = new ArrayList<>();
        javaPatterns.add(Pattern.compile(".*System\\.exit\\(.*\\).*"));
        javaPatterns.add(Pattern.compile(".*printStackTrace\\(\\).*"));
        javaPatterns.add(Pattern.compile(".*Runtime\\.getRuntime\\(\\)\\.exec\\(.*\\).*"));
        patterns.put("Java Security Issues", javaPatterns);
        
        // Hardcoded credentials
        List<Pattern> credentialPatterns = new ArrayList<>();
        credentialPatterns.add(Pattern.compile(".*password.*=.*\"[^\"]{4,}\".*"));
        credentialPatterns.add(Pattern.compile(".*apiKey.*=.*\"[^\"]{10,}\".*"));
        credentialPatterns.add(Pattern.compile(".*secret.*=.*\"[^\"]{10,}\".*"));
        credentialPatterns.add(Pattern.compile(".*token.*=.*\"[^\"]{10,}\".*"));
        patterns.put("Hardcoded Credentials", credentialPatterns);
        
        // Path traversal
        List<Pattern> pathTraversalPatterns = new ArrayList<>();
        pathTraversalPatterns.add(Pattern.compile(".*new File\\(.*\\+.*\\).*"));
        pathTraversalPatterns.add(Pattern.compile(".*new FileInputStream\\(.*\\+.*\\).*"));
        patterns.put("Path Traversal", pathTraversalPatterns);
        
        return patterns;
    }

    private Map<String, String> initializeFixPatterns() {
        Map<String, String> fixes = new HashMap<>();
        
        // SQL Injection fixes
        fixes.put("SQL Injection", "Use PreparedStatement with parameterized queries instead of string concatenation");
        
        // XSS fixes
        fixes.put("Cross-site Scripting (XSS)", "Use safe methods like textContent instead of innerHTML, or implement proper input validation and output encoding");
        
        // IDOR fixes
        fixes.put("Insecure Direct Object Reference", "Implement proper authorization checks before accessing objects based on user input");
        
        // CSRF fixes
        fixes.put("Cross-site Request Forgery", "Implement anti-CSRF tokens and validate them on each sensitive request");
        
        // Java Security Issues fixes
        fixes.put("Java Security Issues", "Replace with safer alternatives or implement proper exception handling");
        
        // Hardcoded Credentials fixes
        fixes.put("Hardcoded Credentials", "Store sensitive data in environment variables or a secure credential store");
        
        // Path Traversal fixes
        fixes.put("Path Traversal", "Validate and sanitize file paths, use Path.normalize(), or restrict to a specific directory");
        
        return fixes;
    }

    @Override
    @Transactional
    public List<VulnerabilityDTO> analyzeCode(String code, String filePath, Long repositoryId) {
        log.debug("Analyzing code for repository id: {}, file: {}", repositoryId, filePath);
        
        Repository repository = repositoryRepository.findById(repositoryId)
                .orElseThrow(() -> new EntityNotFoundException("Repository not found with id: " + repositoryId));
        
        List<Vulnerability> detectedVulnerabilities = new ArrayList<>();
        
        // Split code into lines for analysis
        String[] lines = code.split("\\n");
        
        for (int lineNumber = 0; lineNumber < lines.length; lineNumber++) {
            String line = lines[lineNumber];
            
            // Check each vulnerability pattern
            for (Map.Entry<String, List<Pattern>> entry : vulnerabilityPatterns.entrySet()) {
                String vulnerabilityType = entry.getKey();
                List<Pattern> patterns = entry.getValue();
                
                for (Pattern pattern : patterns) {
                    Matcher matcher = pattern.matcher(line);
                    if (matcher.matches()) {
                        // Create vulnerability
                        Vulnerability vulnerability = createVulnerability(vulnerabilityType, line, lineNumber + 1, filePath, repository);
                        detectedVulnerabilities.add(vulnerability);
                        
                        // Save to database
                        vulnerability = vulnerabilityRepository.save(vulnerability);
                        
                        // Record activity
                        activityService.recordVulnerabilityActivity(
                                "DETECT", 
                                "Detected " + vulnerabilityType + " vulnerability in " + filePath + " at line " + (lineNumber + 1), 
                                vulnerability.getId()
                        );
                        
                        // Only detect one vulnerability per line
                        break;
                    }
                }
            }
        }
        
        // Update repository's last scanned timestamp
        repositoryService.updateLastScanned(repositoryId);
        
        return detectedVulnerabilities.stream()
                .map(EntityMapper::mapToDTO)
                .toList();
    }

    private Vulnerability createVulnerability(String vulnerabilityType, String vulnerableCode, int lineNumber, String filePath, Repository repository) {
        String fixSuggestion = fixPatterns.getOrDefault(vulnerabilityType, "Contact security team for guidance");
        
        // Generate a suggested fix based on the vulnerability type
        String fixedCode = generateFixedCode(vulnerabilityType, vulnerableCode);
        
        return Vulnerability.builder()
                .title(vulnerabilityType + " in " + filePath)
                .description("Detected " + vulnerabilityType + " vulnerability. " + fixSuggestion)
                .filePath(filePath)
                .lineNumber(lineNumber)
                .columnNumber(1) // Default to beginning of line
                .vulnerableCode(vulnerableCode)
                .fixedCode(fixedCode)
                .severity(determineSeverity(vulnerabilityType))
                .status(VulnerabilityStatus.OPEN)
                .vulnerabilityType(vulnerabilityType)
                .repository(repository)
                .build();
    }

    private SeverityLevel determineSeverity(String vulnerabilityType) {
        return switch(vulnerabilityType) {
            case "SQL Injection", "Remote Code Execution" -> SeverityLevel.CRITICAL;
            case "Cross-site Scripting (XSS)", "Path Traversal", "Hardcoded Credentials" -> SeverityLevel.HIGH;
            case "Insecure Direct Object Reference", "Cross-site Request Forgery" -> SeverityLevel.MEDIUM;
            default -> SeverityLevel.LOW;
        };
    }

    private String generateFixedCode(String vulnerabilityType, String vulnerableCode) {
        // This would be much more sophisticated in a real implementation
        // For now, we'll provide simple examples of fixes
        return switch(vulnerabilityType) {
            case "SQL Injection" -> vulnerableCode.contains("executeQuery") ?
                    vulnerableCode.replaceAll("executeQuery\\(.*\\+.*\\)", "executeQuery(\"SELECT * FROM users WHERE id = ?\")") +
                            "\n// Use preparedStatement.setInt(1, userId); to set parameters" :
                    vulnerableCode + "\n// Replace with parameterized queries using PreparedStatement";
                    
            case "Cross-site Scripting (XSS)" -> vulnerableCode.contains("innerHTML") ?
                    vulnerableCode.replace("innerHTML", "textContent") :
                    vulnerableCode + "\n// Use appropriate encoding functions or frameworks";
                    
            case "Hardcoded Credentials" -> "String password = System.getenv(\"DB_PASSWORD\"); // Move credentials to environment variables";
            
            case "Path Traversal" -> vulnerableCode.contains("new File") ?
                    "Path safePath = Paths.get(baseDir).normalize().resolve(fileName);\n" +
                    "// Ensure the resolved path is still within the intended directory\n" +
                    "if (!safePath.startsWith(Paths.get(baseDir))) {\n" +
                    "    throw new SecurityException(\"Path traversal attempt detected\");\n" +
                    "}\n" +
                    "File file = safePath.toFile();" :
                    vulnerableCode + "\n// Validate and normalize paths";
                    
            default -> vulnerableCode + "\n// TODO: Fix this security issue";
        };
    }

    @Override
    @Transactional
    public List<VulnerabilityDTO> scanRepository(Long repositoryId) {
        log.debug("Scanning repository with id: {}", repositoryId);
        
        Repository repository = repositoryRepository.findById(repositoryId)
                .orElseThrow(() -> new EntityNotFoundException("Repository not found with id: " + repositoryId));
        
        // In a real implementation, this would clone the repository and analyze all files
        // For demonstration purposes, we'll simulate finding some vulnerabilities
        List<Vulnerability> detectedVulnerabilities = new ArrayList<>();
        
        // Simulate scanning Java files
        String[] simulatedFiles = {
            "src/main/java/com/example/controller/UserController.java",
            "src/main/java/com/example/service/AuthService.java",
            "src/main/java/com/example/repository/UserRepository.java"
        };
        
        String[] simulatedVulnerableCodes = {
            "String query = \"SELECT * FROM users WHERE username = '\" + username + \"'\";",
            "document.getElementById('output').innerHTML = userInput;",
            "return new File(basePath + userProvidedPath);"
        };
        
        String[] vulnerabilityTypes = {
            "SQL Injection",
            "Cross-site Scripting (XSS)",
            "Path Traversal"
        };
        
        for (int i = 0; i < simulatedFiles.length; i++) {
            // Create and save vulnerability
            Vulnerability vulnerability = createVulnerability(
                    vulnerabilityTypes[i], 
                    simulatedVulnerableCodes[i], 
                    i + 10, // Simulate different line numbers
                    simulatedFiles[i], 
                    repository
            );
            
            vulnerability = vulnerabilityRepository.save(vulnerability);
            detectedVulnerabilities.add(vulnerability);
            
            // Record activity
            activityService.recordVulnerabilityActivity(
                    "DETECT", 
                    "Detected " + vulnerabilityTypes[i] + " vulnerability in " + simulatedFiles[i], 
                    vulnerability.getId()
            );
        }
        
        // Update repository's last scanned timestamp
        repositoryService.updateLastScanned(repositoryId);
        
        // Record activity for the scan
        activityService.recordRepositoryActivity(
                "SCAN", 
                "Completed scan of repository '" + repository.getName() + "', found " + detectedVulnerabilities.size() + " vulnerabilities", 
                repositoryId
        );
        
        return detectedVulnerabilities.stream()
                .map(EntityMapper::mapToDTO)
                .toList();
    }

    @Override
    @Transactional
    public String generateFixedCode(Long vulnerabilityId) {
        log.debug("Generating fixed code for vulnerability with id: {}", vulnerabilityId);
        
        Vulnerability vulnerability = vulnerabilityRepository.findById(vulnerabilityId)
                .orElseThrow(() -> new EntityNotFoundException("Vulnerability not found with id: " + vulnerabilityId));
        
        // If fixed code already exists, return it
        if (vulnerability.getFixedCode() != null && !vulnerability.getFixedCode().isEmpty()) {
            return vulnerability.getFixedCode();
        }
        
        // Otherwise, generate a fix
        String fixedCode = generateFixedCode(vulnerability.getVulnerabilityType(), vulnerability.getVulnerableCode());
        
        // Update the vulnerability with the fixed code
        vulnerability.setFixedCode(fixedCode);
        vulnerabilityRepository.save(vulnerability);
        
        // Record activity
        activityService.recordVulnerabilityActivity(
                "GENERATE_FIX", 
                "Generated fixed code for vulnerability '" + vulnerability.getTitle() + "'", 
                vulnerability.getId()
        );
        
        return fixedCode;
    }

    @Override
    @Transactional
    public List<VulnerabilityDTO> runCodeQLAnalysis(Long repositoryId) {
        log.debug("Running CodeQL analysis for repository with id: {}", repositoryId);
        
        Repository repository = repositoryRepository.findById(repositoryId)
                .orElseThrow(() -> new EntityNotFoundException("Repository not found with id: " + repositoryId));
        
        // In a real implementation, this would execute CodeQL on the repository
        // For demonstration purposes, we'll simulate finding some vulnerabilities
        
        List<Vulnerability> detectedVulnerabilities = new ArrayList<>();
        
        // Simulate CodeQL findings - these would be more sophisticated in a real implementation
        String[] simulatedFiles = {
            "src/main/java/com/example/config/SecurityConfig.java",
            "src/main/java/com/example/util/EncryptionUtil.java",
            "src/main/java/com/example/service/PaymentService.java"
        };
        
        String[] simulatedVulnerableCodes = {
            "http.csrf().disable();",
            "Cipher cipher = Cipher.getInstance(\"DES\");",
            "Process process = Runtime.getRuntime().exec(command);"
        };
        
        String[] vulnerabilityTypes = {
            "CSRF Protection Disabled",
            "Weak Encryption Algorithm",
            "Command Injection"
        };
        
        SeverityLevel[] severities = {
            SeverityLevel.HIGH,
            SeverityLevel.HIGH,
            SeverityLevel.CRITICAL
        };
        
        for (int i = 0; i < simulatedFiles.length; i++) {
            // Create vulnerability with more detailed CodeQL-style information
            Vulnerability vulnerability = Vulnerability.builder()
                    .title(vulnerabilityTypes[i] + " in " + simulatedFiles[i])
                    .description("CodeQL detected " + vulnerabilityTypes[i] + ". " + 
                                 getDetailedDescription(vulnerabilityTypes[i]))
                    .filePath(simulatedFiles[i])
                    .lineNumber(i + 15) // Simulate different line numbers
                    .columnNumber(1)
                    .vulnerableCode(simulatedVulnerableCodes[i])
                    .fixedCode(getCodeQLSuggestedFix(vulnerabilityTypes[i], simulatedVulnerableCodes[i]))
                    .severity(severities[i])
                    .status(VulnerabilityStatus.OPEN)
                    .vulnerabilityType(vulnerabilityTypes[i])
                    .repository(repository)
                    .cweId(getCWEId(vulnerabilityTypes[i]))
                    .build();
            
            vulnerability = vulnerabilityRepository.save(vulnerability);
            detectedVulnerabilities.add(vulnerability);
            
            // Record activity
            activityService.recordVulnerabilityActivity(
                    "DETECT_CODEQL", 
                    "CodeQL detected " + vulnerabilityTypes[i] + " vulnerability in " + simulatedFiles[i], 
                    vulnerability.getId()
            );
        }
        
        // Update repository's last scanned timestamp
        repositoryService.updateLastScanned(repositoryId);
        
        // Record activity for the CodeQL scan
        activityService.recordRepositoryActivity(
                "CODEQL_SCAN", 
                "Completed CodeQL analysis of repository '" + repository.getName() + "', found " + 
                detectedVulnerabilities.size() + " vulnerabilities", 
                repositoryId
        );
        
        return detectedVulnerabilities.stream()
                .map(EntityMapper::mapToDTO)
                .toList();
    }
    
    private String getDetailedDescription(String vulnerabilityType) {
        return switch(vulnerabilityType) {
            case "CSRF Protection Disabled" -> 
                "Disabling CSRF protection can make the application vulnerable to Cross-Site Request Forgery " +
                "attacks. An attacker can trick a user into submitting a malicious request.";
                
            case "Weak Encryption Algorithm" -> 
                "DES is considered a weak encryption algorithm by modern standards. It uses a small key size " +
                "and is vulnerable to brute force attacks.";
                
            case "Command Injection" -> 
                "Executing system commands with user-supplied input can lead to command injection attacks. " +
                "An attacker can inject malicious commands that will be executed by the system.";
                
            default -> "This vulnerability poses a security risk and should be addressed.";
        };
    }
    
    private String getCodeQLSuggestedFix(String vulnerabilityType, String vulnerableCode) {
        return switch(vulnerabilityType) {
            case "CSRF Protection Disabled" -> 
                "// Enable CSRF protection\n" +
                "http.csrf();";
                
            case "Weak Encryption Algorithm" -> 
                "// Use a stronger encryption algorithm\n" +
                "Cipher cipher = Cipher.getInstance(\"AES/GCM/NoPadding\");";
                
            case "Command Injection" -> 
                "// Use ProcessBuilder with a list of arguments to prevent injection\n" +
                "List<String> commandList = new ArrayList<>();\n" +
                "commandList.add(\"/bin/bash\");\n" +
                "commandList.add(\"-c\");\n" +
                "// Validate and sanitize command before adding\n" +
                "commandList.add(validatedCommand);\n" +
                "ProcessBuilder processBuilder = new ProcessBuilder(commandList);\n" +
                "Process process = processBuilder.start();";
                
            default -> vulnerableCode + "\n// Fix this security issue";
        };
    }
    
    private String getCWEId(String vulnerabilityType) {
        return switch(vulnerabilityType) {
            case "CSRF Protection Disabled" -> "CWE-352";
            case "Weak Encryption Algorithm" -> "CWE-327";
            case "Command Injection" -> "CWE-78";
            default -> "";
        };
    }
}