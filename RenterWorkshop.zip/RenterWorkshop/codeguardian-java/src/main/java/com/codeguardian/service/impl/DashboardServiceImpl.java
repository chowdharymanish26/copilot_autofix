package com.codeguardian.service.impl;

import com.codeguardian.model.VulnerabilityStatus;
import com.codeguardian.model.dto.DashboardStatsDTO;
import com.codeguardian.repository.RepositoryRepository;
import com.codeguardian.repository.VulnerabilityRepository;
import com.codeguardian.service.DashboardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class DashboardServiceImpl implements DashboardService {

    private final RepositoryRepository repositoryRepository;
    private final VulnerabilityRepository vulnerabilityRepository;

    @Override
    @Transactional(readOnly = true)
    public DashboardStatsDTO getDashboardStats() {
        log.debug("Fetching dashboard statistics");
        
        Long repoCount = repositoryRepository.countRepositories();
        Long vulnerabilityCount = vulnerabilityRepository.countVulnerabilities();
        Long fixedCount = vulnerabilityRepository.countByStatus(VulnerabilityStatus.FIXED);
        Long pendingReviewCount = vulnerabilityRepository.countByStatus(VulnerabilityStatus.PENDING_REVIEW);
        Long openCount = vulnerabilityRepository.countByStatus(VulnerabilityStatus.OPEN);
        Long approvedCount = vulnerabilityRepository.countByStatus(VulnerabilityStatus.APPROVED);
        Long rejectedCount = vulnerabilityRepository.countByStatus(VulnerabilityStatus.REJECTED);
        
        // In a real implementation, we would calculate trends by comparing with historical data
        // For now, we'll just set some placeholder values
        Integer changeLastDay = 5;
        Integer changeLastWeek = 12;
        Integer changeLastMonth = 28;
        
        return DashboardStatsDTO.builder()
                .repoCount(repoCount)
                .vulnerabilityCount(vulnerabilityCount)
                .fixedCount(fixedCount)
                .pendingReviewCount(pendingReviewCount)
                .openCount(openCount)
                .approvedCount(approvedCount)
                .rejectedCount(rejectedCount)
                .changeLastDay(changeLastDay)
                .changeLastWeek(changeLastWeek)
                .changeLastMonth(changeLastMonth)
                .build();
    }
}