package com.codeguardian.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Data Transfer Object for Activity entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActivityDTO {
    
    private Long id;
    private String action;
    private String description;
    
    // Related entity information
    private Long repositoryId;
    private String repositoryName;
    private Long vulnerabilityId;
    private String vulnerabilityTitle;
    
    // Entity type information
    private String entityType;
    private Long entityId;
    
    // Timestamp
    private LocalDateTime createdAt;
}