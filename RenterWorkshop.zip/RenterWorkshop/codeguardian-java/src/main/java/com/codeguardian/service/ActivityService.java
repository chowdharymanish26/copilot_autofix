package com.codeguardian.service;

import com.codeguardian.model.dto.ActivityDTO;
import java.util.List;

public interface ActivityService {
    
    /**
     * Get all activities with optional limit
     * @param limit Maximum number of activities to return
     * @return List of activities
     */
    List<ActivityDTO> getAllActivities(Integer limit);
    
    /**
     * Get activities for a specific repository
     * @param repositoryId Repository ID
     * @param limit Maximum number of activities to return
     * @return List of activities
     */
    List<ActivityDTO> getActivitiesByRepository(Long repositoryId, Integer limit);
    
    /**
     * Get activities for a specific vulnerability
     * @param vulnerabilityId Vulnerability ID
     * @param limit Maximum number of activities to return
     * @return List of activities
     */
    List<ActivityDTO> getActivitiesByVulnerability(Long vulnerabilityId, Integer limit);
    
    /**
     * Record a new activity
     * @param activityDTO Activity data
     * @return Created activity
     */
    ActivityDTO recordActivity(ActivityDTO activityDTO);
    
    /**
     * Record a repository-related activity
     * @param action Action performed
     * @param description Activity description
     * @param repositoryId Repository ID
     * @return Created activity
     */
    ActivityDTO recordRepositoryActivity(String action, String description, Long repositoryId);
    
    /**
     * Record a vulnerability-related activity
     * @param action Action performed
     * @param description Activity description
     * @param vulnerabilityId Vulnerability ID
     * @return Created activity
     */
    ActivityDTO recordVulnerabilityActivity(String action, String description, Long vulnerabilityId);
}