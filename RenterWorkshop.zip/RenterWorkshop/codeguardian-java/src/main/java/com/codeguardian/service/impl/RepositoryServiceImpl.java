package com.codeguardian.service.impl;

import com.codeguardian.model.Repository;
import com.codeguardian.model.dto.RepositoryDTO;
import com.codeguardian.repository.RepositoryRepository;
import com.codeguardian.service.ActivityService;
import com.codeguardian.service.RepositoryService;
import com.codeguardian.util.EntityMapper;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class RepositoryServiceImpl implements RepositoryService {

    private final RepositoryRepository repositoryRepository;
    private final ActivityService activityService;

    @Override
    @Transactional(readOnly = true)
    public List<RepositoryDTO> getAllRepositories() {
        log.debug("Fetching all repositories");
        List<Repository> repositories = repositoryRepository.findAll();
        return EntityMapper.mapToDTOList(repositories);
    }

    @Override
    @Transactional(readOnly = true)
    public RepositoryDTO getRepositoryById(Long id) {
        log.debug("Fetching repository with id: {}", id);
        Repository repository = repositoryRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Repository not found with id: " + id));
        
        return EntityMapper.mapToDTO(repository);
    }

    @Override
    @Transactional
    public RepositoryDTO createRepository(RepositoryDTO repositoryDTO) {
        log.debug("Creating new repository: {}", repositoryDTO.getName());
        
        // Check if repository with same name or URL already exists
        repositoryRepository.findByName(repositoryDTO.getName())
                .ifPresent(r -> {
                    throw new IllegalArgumentException("Repository with name '" + repositoryDTO.getName() + "' already exists");
                });
        
        repositoryRepository.findByUrl(repositoryDTO.getUrl())
                .ifPresent(r -> {
                    throw new IllegalArgumentException("Repository with URL '" + repositoryDTO.getUrl() + "' already exists");
                });
        
        Repository repository = EntityMapper.mapToEntity(repositoryDTO);
        repository = repositoryRepository.save(repository);
        
        // Record activity
        activityService.recordRepositoryActivity(
                "CREATE", 
                "Repository '" + repository.getName() + "' was created", 
                repository.getId()
        );
        
        return EntityMapper.mapToDTO(repository);
    }

    @Override
    @Transactional
    public RepositoryDTO updateRepository(Long id, RepositoryDTO repositoryDTO) {
        log.debug("Updating repository with id: {}", id);
        
        Repository repository = repositoryRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Repository not found with id: " + id));
        
        // Check for name duplication if name is changing
        if (!repository.getName().equals(repositoryDTO.getName())) {
            repositoryRepository.findByName(repositoryDTO.getName())
                    .ifPresent(r -> {
                        throw new IllegalArgumentException("Repository with name '" + repositoryDTO.getName() + "' already exists");
                    });
        }
        
        // Check for URL duplication if URL is changing
        if (!repository.getUrl().equals(repositoryDTO.getUrl())) {
            repositoryRepository.findByUrl(repositoryDTO.getUrl())
                    .ifPresent(r -> {
                        throw new IllegalArgumentException("Repository with URL '" + repositoryDTO.getUrl() + "' already exists");
                    });
        }
        
        // Update properties
        repository.setName(repositoryDTO.getName());
        repository.setDescription(repositoryDTO.getDescription());
        repository.setUrl(repositoryDTO.getUrl());
        repository.setLanguages(repositoryDTO.getLanguages());
        
        repository = repositoryRepository.save(repository);
        
        // Record activity
        activityService.recordRepositoryActivity(
                "UPDATE", 
                "Repository '" + repository.getName() + "' was updated", 
                repository.getId()
        );
        
        return EntityMapper.mapToDTO(repository);
    }

    @Override
    @Transactional
    public void deleteRepository(Long id) {
        log.debug("Deleting repository with id: {}", id);
        
        Repository repository = repositoryRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Repository not found with id: " + id));
        
        String repositoryName = repository.getName();
        
        repositoryRepository.delete(repository);
        
        // Record activity (with null repository ID since it's deleted)
        activityService.recordRepositoryActivity(
                "DELETE", 
                "Repository '" + repositoryName + "' was deleted", 
                null
        );
    }

    @Override
    @Transactional
    public RepositoryDTO updateLastScanned(Long id) {
        log.debug("Updating last scanned timestamp for repository with id: {}", id);
        
        Repository repository = repositoryRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Repository not found with id: " + id));
        
        repository.setLastScanned(LocalDateTime.now());
        repository = repositoryRepository.save(repository);
        
        // Record activity
        activityService.recordRepositoryActivity(
                "SCAN", 
                "Repository '" + repository.getName() + "' was scanned", 
                repository.getId()
        );
        
        return EntityMapper.mapToDTO(repository);
    }
}