package com.codeguardian.service;

import com.codeguardian.model.dto.VulnerabilityDTO;

import java.util.List;

public interface CodeAnalyzerService {
    
    /**
     * Analyze code for a specific repository
     * @param code Source code to analyze
     * @param filePath Path to the file
     * @param repositoryId Repository ID
     * @return The analysis result (vulnerabilities found)
     */
    List<VulnerabilityDTO> analyzeCode(String code, String filePath, Long repositoryId);
    
    /**
     * Scan a repository for vulnerabilities
     * @param repositoryId Repository ID
     * @return The scan results (vulnerabilities found)
     */
    List<VulnerabilityDTO> scanRepository(Long repositoryId);
    
    /**
     * Generate fixed code for a vulnerability
     * @param vulnerabilityId Vulnerability ID
     * @return Generated fixed code
     */
    String generateFixedCode(Long vulnerabilityId);
    
    /**
     * Run CodeQL analysis on a repository
     * @param repositoryId Repository ID
     * @return The analysis results (vulnerabilities found)
     */
    List<VulnerabilityDTO> runCodeQLAnalysis(Long repositoryId);
}