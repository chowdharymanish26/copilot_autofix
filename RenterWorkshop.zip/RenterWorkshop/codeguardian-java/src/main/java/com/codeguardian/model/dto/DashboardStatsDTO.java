package com.codeguardian.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsDTO {
    private Long repoCount;
    private Long vulnerabilityCount;
    private Long fixedCount;
    private Long pendingReviewCount;
    private Long openCount;
    private Long approvedCount;
    private Long rejectedCount;
    
    // Stats for trends/changes
    private Integer changeLastDay;
    private Integer changeLastWeek;
    private Integer changeLastMonth;
}