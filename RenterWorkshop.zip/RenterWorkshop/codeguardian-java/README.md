# CodeGuardian

CodeGuardian is a comprehensive code vulnerability scanning and fixing tool. It detects and remediates security issues with minimal manual intervention, requiring user review only for final changes before committing.

## Features

- Automated detection of security vulnerabilities in code
- Intelligent remediation with suggested fixes
- Repository management and vulnerability tracking
- Pull request generation for security fixes
- Activity logging and dashboards
- Integration with CodeQL for advanced vulnerability detection

## Technology Stack

- Java 21
- Spring Boot 3.x
- Spring Data JPA
- PostgreSQL
- Maven

## Architecture

The application follows a layered architecture:

- **Controller Layer**: REST API endpoints
- **Service Layer**: Business logic
- **Repository Layer**: Data access
- **Model Layer**: Domain entities and DTOs

## Getting Started

### Prerequisites

- Java 21
- Maven
- PostgreSQL database

### Setup

1. Clone the repository
2. Configure database connection in `application.properties`
3. Run the application

```bash
mvn spring-boot:run
```

## API Endpoints

### Repositories

- `GET /api/repositories` - Get all repositories
- `GET /api/repositories/{id}` - Get repository by ID
- `POST /api/repositories` - Create a new repository
- `PUT /api/repositories/{id}` - Update a repository
- `DELETE /api/repositories/{id}` - Delete a repository

### Vulnerabilities

- `GET /api/vulnerabilities` - Get all vulnerabilities
- `GET /api/vulnerabilities?status={status}` - Filter vulnerabilities by status
- `GET /api/vulnerabilities?repositoryId={repositoryId}` - Filter vulnerabilities by repository
- `GET /api/vulnerabilities/{id}` - Get vulnerability by ID
- `POST /api/vulnerabilities` - Create a new vulnerability
- `PUT /api/vulnerabilities/{id}` - Update a vulnerability
- `PATCH /api/vulnerabilities/{id}/status` - Update vulnerability status
- `POST /api/vulnerabilities/{id}/pull-request` - Create a pull request for a fix
- `DELETE /api/vulnerabilities/{id}` - Delete a vulnerability

## License

This project is licensed under the MIT License - see the LICENSE file for details.