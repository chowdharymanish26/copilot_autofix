import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation, useRoute } from 'wouter';
import { Repository } from '@/types';
import { RepositoryForm } from '@/components/RepositoryForm';
import { ScanProgress } from '@/components/ScanProgress';
import { ScanResultsSummary } from '@/components/ScanResultsSummary';
import { VulnerabilityList } from '@/components/VulnerabilityList';

export default function Scanner() {
  const [repositoryId, setRepositoryId] = useState<number | null>(null);
  const [searchParams] = useLocation();
  const [match, params] = useRoute('/scanner');
  
  useEffect(() => {
    // Check for repo ID in URL
    const urlParams = new URLSearchParams(searchParams);
    const repoId = urlParams.get('repo');
    if (repoId) {
      setRepositoryId(parseInt(repoId));
    }
  }, [searchParams]);
  
  const { data: repository, isLoading } = useQuery<Repository>({
    queryKey: [`/api/repositories/${repositoryId}`],
    enabled: !!repositoryId
  });
  
  const handleScanComplete = (repoId: number) => {
    setRepositoryId(repoId);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">Repository Scanner</h2>
        <p className="text-slate-400">Scan GitHub repositories for vulnerabilities and get fix suggestions</p>
      </div>
      
      {/* Repository Input Form */}
      <div className="bg-background-light rounded-xl shadow-lg p-6 mb-8">
        <h3 className="text-lg font-medium mb-4">Add Repository</h3>
        <RepositoryForm onScanComplete={handleScanComplete} />
      </div>
      
      {/* Only show the sections below if a repository is selected */}
      {repositoryId && (
        <>
          {/* Scan Progress */}
          <ScanProgress repositoryId={repositoryId} />
          
          {/* Scan Results Summary */}
          <ScanResultsSummary repositoryId={repositoryId} />
          
          {/* Vulnerability Details */}
          <div className="bg-background-light rounded-xl shadow-lg p-6 mb-8">
            <VulnerabilityList repositoryId={repositoryId} />
          </div>
          
          {/* Illustrations Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="bg-slate-800 rounded-xl p-6 flex flex-col items-center text-center">
              <div className="rounded-lg mb-4 w-full h-48 bg-slate-700 flex items-center justify-center">
                <span className="material-icons text-6xl text-slate-500">code</span>
              </div>
              <h3 className="text-lg font-medium mb-2">Advanced Pattern Detection</h3>
              <p className="text-sm text-slate-400">Our pattern detection engine scans your Java code for common security vulnerabilities and suggests the best fixes.</p>
            </div>
            
            <div className="bg-slate-800 rounded-xl p-6 flex flex-col items-center text-center">
              <div className="rounded-lg mb-4 w-full h-48 bg-slate-700 flex items-center justify-center">
                <span className="material-icons text-6xl text-slate-500">security</span>
              </div>
              <h3 className="text-lg font-medium mb-2">Snyk Integration</h3>
              <p className="text-sm text-slate-400">VulnrFixer combines both custom pattern detection and Snyk's powerful vulnerability database for comprehensive coverage.</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
