import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Repository, Vulnerability } from '@/types';
import { SeverityBadge } from '@/components/ui/severity-badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { VulnerabilityCard } from '@/components/VulnerabilityCard';
import { Button } from '@/components/ui/button';
import { getVulnerabilityStats } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

export default function Vulnerabilities() {
  const [selectedRepo, setSelectedRepo] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  const { data: repositories, isLoading: isLoadingRepos } = useQuery<Repository[]>({
    queryKey: ['/api/repositories']
  });
  
  // Helper function to get all vulnerabilities for all repositories
  const getVulnerabilities = async () => {
    if (!repositories || repositories.length === 0) return [];
    
    const allVulnerabilities: Vulnerability[] = [];
    
    for (const repo of repositories) {
      const response = await fetch(`/api/repositories/${repo.id}/vulnerabilities`);
      if (response.ok) {
        const vulnerabilities: Vulnerability[] = await response.json();
        allVulnerabilities.push(...vulnerabilities);
      }
    }
    
    return allVulnerabilities;
  };
  
  const { data: vulnerabilities, isLoading: isLoadingVulns } = useQuery<Vulnerability[]>({
    queryKey: ['/api/vulnerabilities/all'],
    queryFn: getVulnerabilities,
    enabled: !!repositories && repositories.length > 0
  });
  
  const isLoading = isLoadingRepos || isLoadingVulns;
  
  // Filter vulnerabilities based on selected repo, search, and filters
  const filteredVulnerabilities = vulnerabilities?.filter(vuln => {
    // Filter by repository
    if (selectedRepo !== 'all' && vuln.repositoryId !== parseInt(selectedRepo)) {
      return false;
    }
    
    // Filter by severity
    if (severityFilter !== 'all' && vuln.severity !== severityFilter) {
      return false;
    }
    
    // Filter by status
    if (statusFilter !== 'all' && vuln.status !== statusFilter) {
      return false;
    }
    
    // Filter by search query
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase();
      return (
        vuln.title.toLowerCase().includes(searchLower) ||
        vuln.description.toLowerCase().includes(searchLower) ||
        vuln.filePath.toLowerCase().includes(searchLower)
      );
    }
    
    return true;
  });
  
  // Get stats for each severity level
  const stats = filteredVulnerabilities ? getVulnerabilityStats(filteredVulnerabilities) : { critical: 0, high: 0, moderate: 0, total: 0 };
  
  if (isLoading) {
    return (
      <div className="p-6 max-w-6xl mx-auto">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">Vulnerabilities</h2>
          <p className="text-slate-400">View and manage detected vulnerabilities</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {[1, 2, 3].map(i => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
        
        <Card className="bg-background-light border-slate-700 mb-6">
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-40 w-full" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (!repositories || repositories.length === 0) {
    return (
      <div className="p-6 max-w-6xl mx-auto">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-2">Vulnerabilities</h2>
          <p className="text-slate-400">View and manage detected vulnerabilities</p>
        </div>
        
        <Card className="bg-background-light border-slate-700">
          <CardContent className="pt-6">
            <div className="text-center p-8">
              <p className="text-xl font-medium mb-2">No repositories scanned yet</p>
              <p className="text-slate-400 mb-4">Scan a repository first to see vulnerabilities</p>
              <Button asChild>
                <a href="/scanner">Scan Repository</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">Vulnerabilities</h2>
        <p className="text-slate-400">View and manage detected vulnerabilities</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-background rounded-lg p-4 border border-critical/30">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-critical/20 flex items-center justify-center mr-4">
              <span className="material-icons text-critical">error</span>
            </div>
            <div>
              <div className="text-3xl font-bold">{stats.critical}</div>
              <div className="text-sm text-slate-400">Critical Vulnerabilities</div>
            </div>
          </div>
        </div>
        
        <div className="bg-background rounded-lg p-4 border border-high/30">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-high/20 flex items-center justify-center mr-4">
              <span className="material-icons text-high">warning</span>
            </div>
            <div>
              <div className="text-3xl font-bold">{stats.high}</div>
              <div className="text-sm text-slate-400">High Vulnerabilities</div>
            </div>
          </div>
        </div>
        
        <div className="bg-background rounded-lg p-4 border border-moderate/30">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-moderate/20 flex items-center justify-center mr-4">
              <span className="material-icons text-moderate">info</span>
            </div>
            <div>
              <div className="text-3xl font-bold">{stats.moderate}</div>
              <div className="text-sm text-slate-400">Moderate Vulnerabilities</div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-background-light rounded-xl shadow-lg mb-8">
        <div className="p-6 border-b border-slate-700">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search vulnerabilities..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-background border-slate-700"
              />
            </div>
            
            <Select value={selectedRepo} onValueChange={setSelectedRepo}>
              <SelectTrigger className="w-full md:w-48 bg-slate-700 border-none">
                <SelectValue placeholder="Select Repository" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Repositories</SelectItem>
                {repositories.map(repo => (
                  <SelectItem key={repo.id} value={repo.id.toString()}>
                    {repo.owner}/{repo.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={severityFilter} onValueChange={setSeverityFilter}>
              <SelectTrigger className="w-full md:w-40 bg-slate-700 border-none">
                <SelectValue placeholder="Filter by Severity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severities</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="moderate">Moderate</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-40 bg-slate-700 border-none">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="accepted">Accepted</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="p-6">
          <Tabs defaultValue="all">
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Vulnerabilities ({filteredVulnerabilities?.length || 0})</TabsTrigger>
              <TabsTrigger value="pending">Pending ({filteredVulnerabilities?.filter(v => v.status === 'pending').length || 0})</TabsTrigger>
              <TabsTrigger value="fixed">Fixed ({filteredVulnerabilities?.filter(v => v.status === 'accepted').length || 0})</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all">
              {filteredVulnerabilities?.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-400">No vulnerabilities match your filters</p>
                </div>
              ) : (
                filteredVulnerabilities?.map(vulnerability => (
                  <VulnerabilityCard key={vulnerability.id} vulnerability={vulnerability} />
                ))
              )}
            </TabsContent>
            
            <TabsContent value="pending">
              {filteredVulnerabilities?.filter(v => v.status === 'pending').length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-400">No pending vulnerabilities</p>
                </div>
              ) : (
                filteredVulnerabilities
                  ?.filter(v => v.status === 'pending')
                  .map(vulnerability => (
                    <VulnerabilityCard key={vulnerability.id} vulnerability={vulnerability} />
                  ))
              )}
            </TabsContent>
            
            <TabsContent value="fixed">
              {filteredVulnerabilities?.filter(v => v.status === 'accepted').length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-400">No fixed vulnerabilities</p>
                </div>
              ) : (
                filteredVulnerabilities
                  ?.filter(v => v.status === 'accepted')
                  .map(vulnerability => (
                    <VulnerabilityCard key={vulnerability.id} vulnerability={vulnerability} />
                  ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
