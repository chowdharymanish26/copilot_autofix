import React, { useEffect, useState } from 'react';
import { formatDateFromISOString, getElapsedTime } from '@/lib/utils';
import { STATUS_LABELS } from '@/lib/constants';
import { Repository, ScanProgress as ScanProgressType } from '@/types';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';

interface ScanProgressProps {
  repositoryId: number;
}

export function ScanProgress({ repositoryId }: ScanProgressProps) {
  const [startTime, setStartTime] = useState<string>('');
  const [elapsedTime, setElapsedTime] = useState<string>('');
  
  const { data: repository } = useQuery<Repository>({
    queryKey: [`/api/repositories/${repositoryId}`]
  });
  
  const { data: progress, isLoading } = useQuery<ScanProgressType>({
    queryKey: [`/api/scan/${repositoryId}/progress`],
    refetchInterval: (data) => {
      if (data && (data.status === 'completed' || data.status === 'failed')) {
        return false;
      }
      return 2000;
    }
  });
  
  useEffect(() => {
    if (repository && repository.scannedAt) {
      setStartTime(repository.scannedAt);
      
      // Update elapsed time every second
      const interval = setInterval(() => {
        setElapsedTime(getElapsedTime(repository.scannedAt));
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [repository]);
  
  if (isLoading) {
    return (
      <div className="bg-background-light rounded-xl shadow-lg p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-4 w-32" />
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i}>
              <div className="flex justify-between text-sm mb-1">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-16" />
              </div>
              <Skeleton className="h-2 w-full" />
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  if (!progress) {
    return null;
  }

  return (
    <div className="bg-background-light rounded-xl shadow-lg p-6 mb-8">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">
          {progress.status === 'completed' 
            ? 'Scan Completed' 
            : progress.status === 'failed' 
              ? 'Scan Failed' 
              : 'Scanning Repository'
          }
        </h3>
        <span className="text-sm text-slate-400">{elapsedTime || 'Just started'}</span>
      </div>
      
      <div className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Pattern detection scan</span>
            <span className={progress.patternDetectionProgress === 100 ? 'text-green-500' : 'text-blue-500'}>
              {progress.patternDetectionProgress === 100 
                ? 'Complete' 
                : progress.patternDetectionProgress > 0 
                  ? `${progress.patternDetectionProgress}%` 
                  : 'Pending'
              }
            </span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-2">
            <div 
              className={`h-2 rounded-full ${progress.patternDetectionProgress === 100 ? 'bg-green-500' : 'bg-blue-500'}`} 
              style={{ width: `${progress.patternDetectionProgress}%` }} 
            ></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Snyk vulnerability scan</span>
            <span className={progress.snykProgress === 100 ? 'text-green-500' : 'text-blue-500'}>
              {progress.snykProgress === 100 
                ? 'Complete' 
                : progress.snykProgress > 0 
                  ? `${progress.snykProgress}%` 
                  : 'Pending'
              }
            </span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-2">
            <div 
              className={`h-2 rounded-full ${progress.snykProgress === 100 ? 'bg-green-500' : 'bg-blue-500'}`} 
              style={{ width: `${progress.snykProgress}%` }} 
            ></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Analyzing results</span>
            <span className={progress.analysisProgress === 100 ? 'text-green-500' : progress.analysisProgress > 0 ? 'text-blue-500' : 'text-slate-400'}>
              {progress.analysisProgress === 100 
                ? 'Complete' 
                : progress.analysisProgress > 0 
                  ? `${progress.analysisProgress}%` 
                  : 'Pending'
              }
            </span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-2">
            <div 
              className={`h-2 rounded-full ${progress.analysisProgress === 100 ? 'bg-green-500' : 'bg-blue-500'}`} 
              style={{ width: `${progress.analysisProgress}%` }} 
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
}
