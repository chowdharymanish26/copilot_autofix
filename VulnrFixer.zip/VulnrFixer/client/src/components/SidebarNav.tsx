import React from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';

interface NavItemProps {
  icon: string;
  label: string;
  to: string;
  active: boolean;
}

function NavItem({ icon, label, to, active }: NavItemProps) {
  return (
    <Link href={to}>
      <a className={cn(
        "flex flex-col items-center justify-center w-12 h-12 rounded-lg hover:bg-slate-700 transition-colors",
        active ? "text-white bg-slate-700" : "text-slate-400"
      )}>
        <span className="material-icons">{icon}</span>
        <span className="text-xs mt-1">{label}</span>
      </a>
    </Link>
  );
}

export function SidebarNav() {
  const [location] = useLocation();

  return (
    <div className="w-20 bg-background-light flex-shrink-0 border-r border-slate-700">
      <div className="h-full flex flex-col items-center justify-between py-6">
        <div className="flex flex-col items-center space-y-6">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center justify-center w-12 h-12 rounded-xl bg-primary text-white font-bold text-lg">VF</a>
          </Link>
          
          {/* Navigation items */}
          <NavItem
            icon="dashboard"
            label="Dashboard"
            to="/dashboard"
            active={location === '/dashboard'}
          />
          
          <NavItem
            icon="search"
            label="Scanner"
            to="/scanner"
            active={location === '/scanner' || location === '/'}
          />
          
          <NavItem
            icon="bug_report"
            label="Vulns"
            to="/vulnerabilities"
            active={location === '/vulnerabilities'}
          />
        </div>
        
        <div className="flex flex-col items-center">
          <a 
            href="#" 
            className="flex flex-col items-center justify-center w-12 h-12 rounded-lg hover:bg-slate-700 transition-colors text-slate-400"
            onClick={(e) => e.preventDefault()}
          >
            <span className="material-icons">help_outline</span>
            <span className="text-xs mt-1">Help</span>
          </a>
        </div>
      </div>
    </div>
  );
}
