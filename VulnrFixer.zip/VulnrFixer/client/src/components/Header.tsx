import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { APP_NAME, APP_VERSION } from '@/lib/constants';

export function Header() {
  const { data: snykStatus, isLoading } = useQuery<{ connected: boolean }>({
    queryKey: ['/api/snyk/test'],
    staleTime: 3600000, // 1 hour
    refetchOnWindowFocus: false,
  });

  return (
    <header className="h-16 flex-shrink-0 bg-background-light border-b border-slate-700 flex items-center px-6">
      <h1 className="text-2xl font-semibold flex items-center">
        <span className="text-primary">Vulnr</span><span className="text-white">Fixer</span>
      </h1>
      <div className="ml-12 text-sm text-slate-400">Version {APP_VERSION}</div>
      <div className="ml-auto flex items-center">
        <div className="bg-background rounded-lg flex items-center px-3 py-1">
          <span className="material-icons text-slate-400 mr-2">insights</span>
          {isLoading ? (
            <span className="text-slate-400">Checking Snyk API...</span>
          ) : snykStatus?.connected ? (
            <span className="text-green-500">Snyk API Connected</span>
          ) : (
            <span className="text-critical">Snyk API Connection Failed</span>
          )}
        </div>
      </div>
    </header>
  );
}
