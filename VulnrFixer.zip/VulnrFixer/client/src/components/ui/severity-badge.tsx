import React from "react";
import { cn } from "@/lib/utils";
import { SEVERITY_COLORS, SEVERITY_LABELS } from "@/lib/constants";

interface SeverityBadgeProps {
  severity: 'critical' | 'high' | 'moderate';
  className?: string;
}

export function SeverityBadge({ severity, className }: SeverityBadgeProps) {
  return (
    <span 
      className={cn(
        "inline-flex items-center justify-center px-2 py-1 rounded text-xs font-medium",
        SEVERITY_COLORS[severity],
        className
      )}
    >
      {SEVERITY_LABELS[severity]}
    </span>
  );
}
