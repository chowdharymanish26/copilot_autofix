import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { scanRepository, getScanProgress } from "./utils/scanner";
import { testSnykConnection } from "./utils/snyk";
import { ZodError } from "zod";
import { scanRequestSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Test Snyk API connection on startup
  try {
    const connected = await testSnykConnection();
    console.log('Snyk API connection:', connected ? 'successful' : 'failed');
  } catch (error) {
    console.error('Error testing Snyk connection:', error);
  }

  // API routes with /api prefix
  
  // Get all repositories
  app.get('/api/repositories', async (req: Request, res: Response) => {
    try {
      const repositories = await storage.getRepositories();
      res.json(repositories);
    } catch (error) {
      console.error('Error fetching repositories:', error);
      res.status(500).json({ message: 'Failed to fetch repositories' });
    }
  });

  // Get repository by ID
  app.get('/api/repositories/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const repository = await storage.getRepository(id);
      
      if (!repository) {
        return res.status(404).json({ message: 'Repository not found' });
      }
      
      res.json(repository);
    } catch (error) {
      console.error('Error fetching repository:', error);
      res.status(500).json({ message: 'Failed to fetch repository' });
    }
  });

  // Scan a repository
  app.post('/api/scan', async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validatedBody = scanRequestSchema.parse(req.body);
      
      // Start scanning repository
      const repositoryId = await scanRepository(
        validatedBody.url,
        validatedBody.usePatternDetection,
        validatedBody.useSnyk
      );
      
      res.status(201).json({ repositoryId });
    } catch (error) {
      console.error('Error scanning repository:', error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: fromZodError(error).message 
        });
      }
      
      res.status(500).json({ message: `Failed to scan repository: ${error}` });
    }
  });

  // Get scan progress
  app.get('/api/scan/:repositoryId/progress', async (req: Request, res: Response) => {
    try {
      const repositoryId = parseInt(req.params.repositoryId);
      const progress = getScanProgress(repositoryId);
      
      if (!progress) {
        return res.status(404).json({ message: 'Scan not found' });
      }
      
      res.json(progress);
    } catch (error) {
      console.error('Error fetching scan progress:', error);
      res.status(500).json({ message: 'Failed to fetch scan progress' });
    }
  });

  // Get vulnerabilities by repository ID
  app.get('/api/repositories/:id/vulnerabilities', async (req: Request, res: Response) => {
    try {
      const repositoryId = parseInt(req.params.id);
      const vulnerabilities = await storage.getVulnerabilities(repositoryId);
      
      res.json(vulnerabilities);
    } catch (error) {
      console.error('Error fetching vulnerabilities:', error);
      res.status(500).json({ message: 'Failed to fetch vulnerabilities' });
    }
  });

  // Update vulnerability status (accept/reject fix)
  app.patch('/api/vulnerabilities/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !['accepted', 'rejected', 'pending'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }
      
      const vulnerability = await storage.updateVulnerabilityStatus(id, status);
      
      if (!vulnerability) {
        return res.status(404).json({ message: 'Vulnerability not found' });
      }
      
      res.json(vulnerability);
    } catch (error) {
      console.error('Error updating vulnerability:', error);
      res.status(500).json({ message: 'Failed to update vulnerability' });
    }
  });

  // Test Snyk API connection
  app.get('/api/snyk/test', async (req: Request, res: Response) => {
    try {
      const connected = await testSnykConnection();
      res.json({ connected });
    } catch (error) {
      console.error('Error testing Snyk connection:', error);
      res.status(500).json({ message: 'Failed to test Snyk connection' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
