import simpleGit, { SimpleGit } from 'simple-git';
import fs from 'fs/promises';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);
const REPO_BASE_DIR = path.join(process.cwd(), 'temp');

// Ensure the temp directory exists
async function ensureTempDir() {
  try {
    await fs.mkdir(REPO_BASE_DIR, { recursive: true });
  } catch (error) {
    console.error('Error creating temp directory:', error);
    throw error;
  }
}

// Extract owner and repo name from GitHub URL
export function parseGitHubUrl(url: string) {
  try {
    const urlObj = new URL(url);
    if (urlObj.hostname !== 'github.com') {
      throw new Error('Not a GitHub URL');
    }

    const pathParts = urlObj.pathname.split('/').filter(Boolean);
    if (pathParts.length < 2) {
      throw new Error('Invalid GitHub repository URL');
    }

    return {
      owner: pathParts[0],
      name: pathParts[1],
    };
  } catch (error) {
    throw new Error('Invalid GitHub URL');
  }
}

// Clone a GitHub repository
export async function cloneRepository(url: string): Promise<{ repoPath: string; owner: string; name: string }> {
  const { owner, name } = parseGitHubUrl(url);
  const repoDir = path.join(REPO_BASE_DIR, `${owner}_${name}_${Date.now()}`);

  await ensureTempDir();
  
  const git: SimpleGit = simpleGit();
  
  try {
    console.log(`Cloning ${url} into ${repoDir}...`);
    await git.clone(url, repoDir);
    console.log('Repository cloned successfully');
    return { repoPath: repoDir, owner, name };
  } catch (error) {
    console.error('Error cloning repository:', error);
    throw new Error(`Failed to clone repository: ${error}`);
  }
}

// Find code files by language in the repository
export async function findCodeFilesByLanguage(repoPath: string, language: string): Promise<string[]> {
  try {
    let fileExtension = "";
    switch (language.toLowerCase()) {
      case "java":
        fileExtension = "*.java";
        break;
      case "python":
        fileExtension = "*.py";
        break;
      case "javascript":
        fileExtension = "*.js";
        break;
      case "typescript":
        fileExtension = "*.ts";
        break;
      default:
        fileExtension = "*.java"; // Default to Java
    }
    
    const { stdout } = await execAsync(`find ${repoPath} -type f -name "${fileExtension}"`);
    return stdout.split('\n').filter(Boolean);
  } catch (error) {
    console.error(`Error finding ${language} files:`, error);
    throw new Error(`Failed to find ${language} files: ${error}`);
  }
}

// Legacy function for Java files (for backward compatibility)
export async function findJavaFiles(repoPath: string): Promise<string[]> {
  return findCodeFilesByLanguage(repoPath, "java");
}

// Read file content
export async function readFileContent(filePath: string): Promise<string> {
  try {
    return await fs.readFile(filePath, 'utf-8');
  } catch (error) {
    console.error(`Error reading file ${filePath}:`, error);
    throw new Error(`Failed to read file: ${error}`);
  }
}

// Clean up the cloned repository
export async function cleanupRepository(repoPath: string): Promise<void> {
  try {
    await fs.rm(repoPath, { recursive: true, force: true });
    console.log(`Repository at ${repoPath} cleaned up`);
  } catch (error) {
    console.error(`Error cleaning up repository at ${repoPath}:`, error);
    // Don't throw here, just log the error
  }
}
