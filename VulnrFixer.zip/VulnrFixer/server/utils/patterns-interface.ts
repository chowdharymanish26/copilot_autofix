export interface VulnerabilityPattern {
  id: string;
  name: string;
  severity: 'critical' | 'high' | 'moderate';
  regex: RegExp;
  description: string;
  fixExample: string;
  language: string; // 'java', 'python', 'javascript', etc.
}