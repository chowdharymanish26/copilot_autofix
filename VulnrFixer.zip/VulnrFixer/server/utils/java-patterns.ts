// Collection of vulnerability patterns in Java code

import { VulnerabilityPattern } from './patterns-interface';

// SQL Injection patterns
const sqlInjectionPatterns: VulnerabilityPattern[] = [
  {
    id: 'SQL-INJ-01',
    name: 'SQL Injection in Statement',
    severity: 'critical',
    regex: /String\s+(?:\w+)\s*=\s*(?:"|\').+?(?:"|\').*?\+\s*\w+.*?(?:Statement|createStatement|executeQuery|executeUpdate).+?(?:\((?:\w+)\))/s,
    description: 'Direct string concatenation in SQL queries can lead to SQL injection vulnerabilities. Use prepared statements with parameterized queries instead.',
    fixExample: `String sql = "SELECT * FROM users WHERE username = ?";
try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
    pstmt.setString(1, username);
    ResultSet rs = pstmt.executeQuery();
}`,
    language: 'java'
  },
  {
    id: 'SQL-INJ-02',
    name: 'SQL Injection in PreparedStatement',
    severity: 'critical',
    regex: /PreparedStatement\s+(?:\w+)\s*=\s*(?:\w+)\.prepareStatement\(\s*(?:"|\').+?(?:"|\').*?\+\s*\w+.*?\)/s,
    description: 'Even with PreparedStatement, string concatenation in the SQL query can lead to SQL injection. Use parameter placeholders (?) instead.',
    fixExample: `String sql = "SELECT * FROM users WHERE username = ?";
PreparedStatement pstmt = connection.prepareStatement(sql);
pstmt.setString(1, username);`,
    language: 'java'
  }
];

// Path Traversal patterns
const pathTraversalPatterns: VulnerabilityPattern[] = [
  {
    id: 'PATH-TRAV-01',
    name: 'Path Traversal in File Operations',
    severity: 'high',
    regex: /new\s+File\((?:[^,)]+?)\s*\+\s*(?:\w+)(?:[^,)]*?)\)/,
    description: 'Directly concatenating user input to file paths can lead to path traversal vulnerabilities. Validate and sanitize file paths.',
    fixExample: `File file = new File(basePath, fileName);
String canonicalPath = file.getCanonicalPath();
if (!canonicalPath.startsWith(new File(basePath).getCanonicalPath())) {
    throw new SecurityException("Path traversal attempt detected");
}`,
    language: 'java'
  },
  {
    id: 'PATH-TRAV-02',
    name: 'Path Traversal in FileInputStream',
    severity: 'high',
    regex: /new\s+FileInputStream\((?:[^,)]+?)\s*\+\s*(?:\w+)(?:[^,)]*?)\)/,
    description: 'Directly concatenating user input to file paths in FileInputStream constructor can lead to path traversal vulnerabilities.',
    fixExample: `Path path = Paths.get(baseDirectory, fileName);
if (path.normalize().startsWith(Paths.get(baseDirectory))) {
    try (FileInputStream fis = new FileInputStream(path.toFile())) {
        // Process the file
    }
} else {
    throw new SecurityException("Path traversal attempt detected");
}`,
    language: 'java'
  }
];

// XML External Entity (XXE) patterns
const xxePatterns: VulnerabilityPattern[] = [
  {
    id: 'XXE-01',
    name: 'XXE in DocumentBuilderFactory',
    severity: 'critical',
    regex: /DocumentBuilderFactory\s+(?:\w+)\s*=\s*DocumentBuilderFactory\.newInstance\(\)(?:(?!setFeature\(XMLConstants\.FEATURE_SECURE_PROCESSING|\s+\.setFeature\("http:\/\/apache\.org\/xml\/features\/disallow-doctype-decl").)*?\.parse\(/s,
    description: 'XML parsers can be vulnerable to XXE attacks if secure features are not enabled.',
    fixExample: `DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
dbf.setXIncludeAware(false);
dbf.setExpandEntityReferences(false);`,
    language: 'java'
  },
  {
    id: 'XXE-02',
    name: 'XXE in SAXParserFactory',
    severity: 'critical',
    regex: /SAXParserFactory\s+(?:\w+)\s*=\s*SAXParserFactory\.newInstance\(\)(?:(?!setFeature\(XMLConstants\.FEATURE_SECURE_PROCESSING).)*?\.parse\(/s,
    description: 'SAX parsers can be vulnerable to XXE attacks if secure features are not enabled.',
    fixExample: `SAXParserFactory spf = SAXParserFactory.newInstance();
spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
spf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);`,
    language: 'java'
  }
];

// Insecure Hash patterns
const insecureHashPatterns: VulnerabilityPattern[] = [
  {
    id: 'HASH-01',
    name: 'Insecure Hashing Algorithm (MD5)',
    severity: 'high',
    regex: /MessageDigest\.getInstance\(\s*(?:"|\')MD5(?:"|\')\s*\)/,
    description: 'MD5 is a cryptographically broken hashing algorithm. Use more secure alternatives like SHA-256 or better.',
    fixExample: `MessageDigest digest = MessageDigest.getInstance("SHA-256");`,
    language: 'java'
  },
  {
    id: 'HASH-02',
    name: 'Insecure Hashing Algorithm (SHA-1)',
    severity: 'moderate',
    regex: /MessageDigest\.getInstance\(\s*(?:"|\')SHA-?1(?:"|\')\s*\)/,
    description: 'SHA-1 is considered cryptographically weak. Use more secure alternatives like SHA-256 or better.',
    fixExample: `MessageDigest digest = MessageDigest.getInstance("SHA-256");`,
    language: 'java'
  }
];

// Weak Encryption patterns
const weakEncryptionPatterns: VulnerabilityPattern[] = [
  {
    id: 'CRYPT-01',
    name: 'Weak Encryption (DES)',
    severity: 'high',
    regex: /Cipher\.getInstance\(\s*(?:"|\')DES(?:"|\')\s*\)/,
    description: 'DES is an outdated encryption algorithm with known vulnerabilities. Use AES instead.',
    fixExample: `Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");`,
    language: 'java'
  },
  {
    id: 'CRYPT-02',
    name: 'Weak Encryption Mode (ECB)',
    severity: 'high',
    regex: /Cipher\.getInstance\(\s*(?:"|\')(?:AES|DES|3DES)\/ECB\/(?:"|\')\s*\)/,
    description: 'ECB mode is cryptographically weak. Use a more secure mode like GCM or CBC with proper padding.',
    fixExample: `Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");`,
    language: 'java'
  }
];

// Combine all patterns
export const vulnerabilityPatterns: VulnerabilityPattern[] = [
  ...sqlInjectionPatterns,
  ...pathTraversalPatterns,
  ...xxePatterns,
  ...insecureHashPatterns,
  ...weakEncryptionPatterns
];

// Function to analyze Java code for vulnerabilities
export function analyzeJavaCode(
  filePath: string, 
  code: string
): Array<{ 
  pattern: VulnerabilityPattern; 
  line: number; 
  matchedCode: string;
  fixedCode: string;
}> {
  const results = [];
  const lines = code.split('\n');

  for (const pattern of vulnerabilityPatterns) {
    // Reset regex lastIndex to avoid issues with global regex
    pattern.regex.lastIndex = 0;
    
    // Match against entire code
    const matches = code.match(pattern.regex);
    
    if (matches) {
      for (const match of [matches[0]]) {
        // Find the line number(s) for this match
        let lineNumber = -1;
        let lineContent = '';
        
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].includes(match)) {
            lineNumber = i + 1;
            lineContent = lines[i];
            break;
          }
        }
        
        // If we couldn't find the exact line, try to get close
        if (lineNumber === -1) {
          const codeChunks = match.split('\n');
          if (codeChunks.length > 0) {
            for (let i = 0; i < lines.length; i++) {
              if (lines[i].includes(codeChunks[0])) {
                lineNumber = i + 1;
                lineContent = codeChunks.slice(0, Math.min(5, codeChunks.length)).join('\n');
                break;
              }
            }
          }
        }
        
        // Generate a simple fixed code example by replacing vulnerable code
        // with a fixed version tailored to the found vulnerability
        let fixedCode = match;
        
        // Simplistic fix approach - this would be more sophisticated in a real scanner
        if (pattern.id.startsWith('SQL-INJ')) {
          fixedCode = pattern.fixExample;
        } else if (pattern.id.startsWith('PATH-TRAV')) {
          fixedCode = pattern.fixExample;
        } else if (pattern.id.startsWith('XXE')) {
          fixedCode = pattern.fixExample;
        } else if (pattern.id.startsWith('HASH')) {
          fixedCode = pattern.fixExample;
        } else if (pattern.id.startsWith('CRYPT')) {
          fixedCode = pattern.fixExample;
        }
        
        results.push({
          pattern,
          line: lineNumber,
          matchedCode: match,
          fixedCode
        });
      }
    }
  }

  return results;
}
