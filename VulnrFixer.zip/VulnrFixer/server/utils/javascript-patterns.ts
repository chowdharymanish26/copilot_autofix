// JavaScript vulnerability patterns

import { VulnerabilityPattern } from './patterns-interface';

// SQL Injection vulnerabilities
const sqlInjectionPatterns: VulnerabilityPattern[] = [
  {
    id: 'JS-SQL-INJ-01',
    name: 'Raw SQL Query in JavaScript',
    severity: 'critical',
    regex: /(?:connection|db|database|sql|conn|pool)\.query\(\s*(?:`|"|')(?:SELECT|INSERT|UPDATE|DELETE).*?\$\{/i,
    description: 'Unsanitized user input used in SQL queries can lead to SQL injection attacks.',
    fixExample: `// Use parameterized queries
const result = await connection.query('SELECT * FROM users WHERE username = ?', [username]);`,
    language: 'javascript'
  },
  {
    id: 'JS-SQL-INJ-02',
    name: 'String Concatenation in SQL',
    severity: 'high',
    regex: /(?:connection|db|database|sql|conn|pool)\.query\(\s*(?:'|")(?:SELECT|INSERT|UPDATE|DELETE).*?\s*\+\s*/i,
    description: 'Using string concatenation in SQL queries can lead to SQL injection.',
    fixExample: `// Use parameterized queries instead of string concatenation
const result = await connection.query('SELECT * FROM users WHERE username = ?', [username]);`,
    language: 'javascript'
  },
  {
    id: 'JS-SQL-INJ-03',
    name: 'SQL Query with Interpolation',
    severity: 'high',
    regex: /(?:connection|db|database|sql|conn|pool)\.query\(\s*\`(?:SELECT|INSERT|UPDATE|DELETE)/i,
    description: 'Using template literals in SQL queries can lead to SQL injection.',
    fixExample: `// Use parameterized queries
const result = await connection.query('SELECT * FROM users WHERE username = ?', [username]);`,
    language: 'javascript'
  }
];

// NoSQL Injection vulnerabilities
const noSqlInjectionPatterns: VulnerabilityPattern[] = [
  {
    id: 'JS-NOSQL-INJ-01',
    name: 'MongoDB Query Injection',
    severity: 'high',
    regex: /(?:collection|db|mongo)\.(?:find|findOne|update|updateOne|updateMany|replaceOne|deleteOne|deleteMany)\(\s*\{\s*(?:['"]\w+['"]|\w+)\s*:\s*(?!ObjectId|ISODate|true|false|null|undefined)\$\{/,
    description: 'Unsanitized user input in MongoDB queries can lead to NoSQL injection.',
    fixExample: `// Use proper query construction with validated inputs
const query = { username: sanitizedUsername };
const result = await collection.findOne(query);

// For more complex queries, validate and sanitize each input
const filter = { };
if (sanitizedUsername) filter.username = sanitizedUsername;
const result = await collection.find(filter);`,
    language: 'javascript'
  },
  {
    id: 'JS-NOSQL-INJ-02',
    name: 'MongoDB $where Clause',
    severity: 'critical',
    regex: /\$where\s*:\s*(?:['"`].*?\$\{|\$\{)/,
    description: 'Using $where with unvalidated inputs can lead to code injection.',
    fixExample: `// Avoid using $where with user input
// Instead, use standard query operators:
const query = {
  username: sanitizedUsername,
  points: { $gt: parseInt(sanitizedMinPoints) }
};
const result = await collection.find(query);`,
    language: 'javascript'
  }
];

// Command Injection vulnerabilities
const commandInjectionPatterns: VulnerabilityPattern[] = [
  {
    id: 'JS-CMD-INJ-01',
    name: 'Child Process Command Injection',
    severity: 'critical',
    regex: /(?:require\(['"](child_process|child-process)['"]|\bchild_process\b).*?(?:exec|execSync|spawn|spawnSync|fork)\s*\(\s*(?:['"`].*?\$\{|\$\{|['"`].*?\s*\+\s*)/,
    description: 'Using unsanitized input in system commands can lead to command injection.',
    fixExample: `// Use an array of arguments instead of a shell command
const { spawn } = require('child_process');
const child = spawn('program', ['--arg', sanitizedInput]);

// If you must use shell commands, validate inputs carefully
const { execFile } = require('child_process');
const allowlist = ['option1', 'option2'];
if (!allowlist.includes(userInput)) {
  throw new Error('Invalid input');
}
execFile('program', ['--arg', userInput]);`,
    language: 'javascript'
  },
  {
    id: 'JS-CMD-INJ-02',
    name: 'Eval Injection',
    severity: 'critical',
    regex: /(?:eval|Function|new\s+Function)\s*\(\s*(?:[^)]*?\$\{|\$\{|['"`][^)]*?\s*\+\s*)/,
    description: 'Using eval or Function constructor with unsanitized input can execute malicious code.',
    fixExample: `// Avoid eval and Function constructor altogether
// Use safer alternatives:

// For JSON parsing, use JSON.parse instead of eval
const data = JSON.parse(jsonString);

// For dynamic property access, use bracket notation
const result = object[propertyName];

// For calculations, use a dedicated math library
const math = require('mathjs');
const result = math.evaluate(sanitizedExpression);`,
    language: 'javascript'
  }
];

// Path Traversal vulnerabilities
const pathTraversalPatterns: VulnerabilityPattern[] = [
  {
    id: 'JS-PATH-TRAV-01',
    name: 'Unsafe File Path',
    severity: 'high',
    regex: /(?:require\(['"]fs['"]|\bfs\b).*?(?:readFile|readFileSync|writeFile|writeFileSync|appendFile|appendFileSync|createReadStream|createWriteStream|open|openSync)\s*\(\s*(?!path\.(?:normalize|resolve|join|dirname|basename))\s*(?:['"`].*?\$\{|\$\{|['"`].*?\s*\+\s*)/,
    description: 'Using unsanitized file paths can lead to path traversal vulnerabilities.',
    fixExample: `const path = require('path');
const fs = require('fs');

// Define a safe root directory
const safeDir = path.resolve(__dirname, 'uploads');

// Sanitize and validate the file path
function getSecurePath(userInput) {
  // Normalize to remove ../ and other path traversal attempts
  const safePath = path.normalize(userInput).replace(/^(\.\.(\/|\\|$))+/, '');
  const fullPath = path.join(safeDir, safePath);
  
  // Ensure the path is still within the safe directory
  if (!fullPath.startsWith(safeDir)) {
    throw new Error('Invalid path');
  }
  
  return fullPath;
}

// Use the secure path
const filePath = getSecurePath(filename);
const data = fs.readFileSync(filePath, 'utf8');`,
    language: 'javascript'
  }
];

// Prototype Pollution
const prototypePollutionPatterns: VulnerabilityPattern[] = [
  {
    id: 'JS-PROTO-POLL-01',
    name: 'Recursive Object Merge',
    severity: 'high',
    regex: /(?:function|const|let|var)\s+\w+\s*(?:=|\(.*?\)\s*=>|=>\s*)\s*\{.*?\}/,
    description: 'Recursive object merging can lead to prototype pollution vulnerabilities.',
    fixExample: `// Use Object.assign for shallow copies
const result = Object.assign({}, target, source);

// For deep merging, use a safe approach
function safeDeepMerge(target, source) {
  const result = {...target};
  
  for (const key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      // Skip __proto__ and constructor to prevent pollution
      if (key === '__proto__' || key === 'constructor') continue;
      
      if (source[key] instanceof Object && target[key] instanceof Object) {
        result[key] = safeDeepMerge(target[key], source[key]);
      } else {
        result[key] = source[key];
      }
    }
  }
  
  return result;
}`,
    language: 'javascript'
  },
  {
    id: 'JS-PROTO-POLL-02',
    name: 'Object Property Assignment',
    severity: 'moderate',
    regex: /(?:Object\.assign|(?:\{)\.\.\.)/,
    description: 'Carefully validate inputs when using object spread or Object.assign to avoid prototype pollution.',
    fixExample: `// Check for prototype pollution attempts
function isProtoPollution(key) {
  return key === '__proto__' || key === 'constructor' || key === 'prototype';
}

// Sanitize user input object
function sanitizeObject(obj) {
  const result = {};
  for (const key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key) && !isProtoPollution(key)) {
      if (typeof obj[key] === 'object' && obj[key] !== null) {
        result[key] = sanitizeObject(obj[key]);
      } else {
        result[key] = obj[key];
      }
    }
  }
  return result;
}

// Use sanitized input
const userInput = JSON.parse(requestBody);
const safeInput = sanitizeObject(userInput);
const result = Object.assign({}, target, safeInput);`,
    language: 'javascript'
  }
];

// Insecure Crypto
const insecureCryptoPatterns: VulnerabilityPattern[] = [
  {
    id: 'JS-CRYPTO-01',
    name: 'Weak Cryptographic Algorithm',
    severity: 'high',
    regex: /crypto\.createHash\(\s*['"`](?:md5|sha1)['"`]\s*\)/,
    description: 'MD5 and SHA-1 are cryptographically broken or weak hash algorithms.',
    fixExample: `const crypto = require('crypto');

// Use a strong hashing algorithm
const hash = crypto.createHash('sha256')
  .update(data)
  .digest('hex');`,
    language: 'javascript'
  },
  {
    id: 'JS-CRYPTO-02',
    name: 'Weak Cipher Algorithm',
    severity: 'high',
    regex: /crypto\.createCipher(?:iv)?\(\s*['"`](?:des|des3|des-ede3|rc2|rc4|idea)['"`]/i,
    description: 'Using deprecated or weak cipher algorithms.',
    fixExample: `const crypto = require('crypto');

// Generate secure random values for key and iv
const key = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);

// Use a strong algorithm and mode
const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
let encrypted = cipher.update(text, 'utf8', 'hex');
encrypted += cipher.final('hex');
const authTag = cipher.getAuthTag();`,
    language: 'javascript'
  },
  {
    id: 'JS-CRYPTO-03',
    name: 'Insecure Random Values',
    severity: 'high',
    regex: /Math\.random\(\)/,
    description: 'Math.random() is not cryptographically secure for sensitive operations.',
    fixExample: `const crypto = require('crypto');

// Generate cryptographically strong random values
const randomBytes = crypto.randomBytes(16);
const randomValue = randomBytes.toString('hex');

// For a random integer in a range
function secureRandomInt(min, max) {
  return Math.floor(
    crypto.randomInt(max - min + 1) + min
  );
}`,
    language: 'javascript'
  }
];

// Combine all patterns
export const javascriptVulnerabilityPatterns: VulnerabilityPattern[] = [
  ...sqlInjectionPatterns,
  ...noSqlInjectionPatterns,
  ...commandInjectionPatterns,
  ...pathTraversalPatterns,
  ...prototypePollutionPatterns,
  ...insecureCryptoPatterns
];

// Function to analyze JavaScript code for vulnerabilities
export function analyzeJavaScriptCode(
  filePath: string, 
  code: string
): Array<{ 
  pattern: VulnerabilityPattern; 
  line: number; 
  matchedCode: string;
  fixedCode: string;
}> {
  const results = [];
  const lines = code.split('\n');

  for (const pattern of javascriptVulnerabilityPatterns) {
    // Reset regex lastIndex to avoid issues with global regex
    pattern.regex.lastIndex = 0;
    
    // Match against entire code
    const matches = code.match(pattern.regex);
    
    if (matches) {
      for (const match of [matches[0]]) {
        // Find the line number(s) for this match
        let lineNumber = -1;
        
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].includes(match)) {
            lineNumber = i + 1;
            break;
          }
        }
        
        // If we couldn't find the exact line, try to get close
        if (lineNumber === -1) {
          const codeChunks = match.split('\n');
          if (codeChunks.length > 0) {
            for (let i = 0; i < lines.length; i++) {
              if (lines[i].includes(codeChunks[0])) {
                lineNumber = i + 1;
                break;
              }
            }
          }
        }
        
        // Generate a simple fixed code example by replacing vulnerable code
        // with a fixed version tailored to the found vulnerability
        let fixedCode = pattern.fixExample;
        
        results.push({
          pattern,
          line: lineNumber,
          matchedCode: match,
          fixedCode
        });
      }
    }
  }

  return results;
}