import axios from 'axios';
import path from 'path';
import fs from 'fs';

// Snyk API token
const SNYK_API_TOKEN = '2f5930de-9c8e-4828-98c7-ef6ef85993a4';
const SNYK_API_URL = 'https://api.snyk.io/v1';

interface SnykIssue {
  id: string;
  issueType: string;
  pkgName: string;
  pkgVersion: string;
  title: string;
  severity: string;
  fromPackages: string[];
  name: string;
  version: string;
  isUpgradable: boolean;
  isPatchable: boolean;
  remediation?: {
    upgrade?: {
      upgradeTo: string;
    };
  };
}

interface SnykVulnerability {
  title: string;
  description: string;
  severity: string;
  filePath: string;
  lineNumber: number;
  originalCode: string;
  fixedCode: string;
}

// Test Snyk API connection
export async function testSnykConnection(): Promise<boolean> {
  try {
    const response = await axios.get(`${SNYK_API_URL}/user/me`, {
      headers: {
        'Authorization': `token ${SNYK_API_TOKEN}`,
      },
    });
    
    return response.status === 200;
  } catch (error) {
    console.error('Error connecting to Snyk API:', error);
    return false;
  }
}

// Scan a repository with Snyk
export async function scanWithSnyk(
  repoPath: string
): Promise<SnykVulnerability[]> {
  // Check if there's a pom.xml or build.gradle file to determine the build system
  const hasMaven = fs.existsSync(path.join(repoPath, 'pom.xml'));
  const hasGradle = fs.existsSync(path.join(repoPath, 'build.gradle'));
  
  try {
    // Call Snyk API to scan the project
    // NOTE: In a real implementation, we would call the Snyk CLI or API
    // to perform a real scan. For this demo, we'll simulate results.
    
    // Simulate a scan response
    const vulnerabilities: SnykVulnerability[] = [
      {
        title: 'SQL Injection',
        description: 'The application constructs a SQL query using user-supplied input without proper sanitization.',
        severity: 'critical',
        filePath: 'src/main/java/com/example/dao/UserDAO.java',
        lineNumber: 42,
        originalCode: `String sql = "SELECT * FROM users WHERE username = '" + username + "';";
try (Statement stmt = connection.createStatement();
     ResultSet rs = stmt.executeQuery(sql)) {`,
        fixedCode: `String sql = "SELECT * FROM users WHERE username = ?";
try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
    pstmt.setString(1, username);
    ResultSet rs = pstmt.executeQuery();`
      },
      {
        title: 'Path Traversal',
        description: 'The application allows direct access to files based on user input without properly validating the file path.',
        severity: 'high',
        filePath: 'src/main/java/com/example/util/FileHandler.java',
        lineNumber: 31,
        originalCode: `public static File getFile(String fileName) {
    return new File(BASE_DIRECTORY + fileName);
}`,
        fixedCode: `public static File getFile(String fileName) throws IOException {
    File file = new File(BASE_DIRECTORY, fileName);
    String canonicalPath = file.getCanonicalPath();
    if (!canonicalPath.startsWith(new File(BASE_DIRECTORY).getCanonicalPath())) {
        throw new IOException("Access to file outside base directory is not allowed");
    }
    return file;
}`
      },
      {
        title: 'XML External Entity (XXE) Vulnerability',
        description: 'The XML parser is configured to resolve external entities, which could lead to information disclosure.',
        severity: 'high',
        filePath: 'src/main/java/com/example/parser/XmlParser.java',
        lineNumber: 24,
        originalCode: `DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
DocumentBuilder builder = factory.newDocumentBuilder();
Document document = builder.parse(input);`,
        fixedCode: `DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
factory.setXIncludeAware(false);
factory.setExpandEntityReferences(false);
DocumentBuilder builder = factory.newDocumentBuilder();
Document document = builder.parse(input);`
      }
    ];
    
    return vulnerabilities;
  } catch (error) {
    console.error('Error scanning with Snyk:', error);
    throw new Error(`Failed to scan with Snyk: ${error}`);
  }
}
