import { 
  cloneRepository, 
  cleanupRepository 
} from './github';
import { scanRepositoryCode, VulnerabilityResult } from './code-scanner';
import { scanWithSnyk } from './snyk';
import { InsertRepository, InsertVulnerability } from '@shared/schema';
import { storage } from '../storage';
import path from 'path';

interface ScanProgress {
  id: number;
  repositoryId: number;
  status: string;
  patternDetectionProgress: number;
  snykProgress: number;
  analysisProgress: number;
}

const scanProgress = new Map<number, ScanProgress>();

export function getScanProgress(repositoryId: number): ScanProgress | undefined {
  return scanProgress.get(repositoryId);
}

export async function scanRepository(
  url: string,
  usePatternDetection: boolean = true,
  useSnyk: boolean = true
): Promise<number> {
  try {
    // Parse and clone repository
    const { repoPath, owner, name } = await cloneRepository(url);
    
    // Create repository record
    const repository: InsertRepository = {
      url,
      owner,
      name
    };

    const createdRepo = await storage.createRepository(repository);
    
    // Initialize scan progress
    scanProgress.set(createdRepo.id, {
      id: createdRepo.id,
      repositoryId: createdRepo.id,
      status: 'scanning',
      patternDetectionProgress: 0,
      snykProgress: 0,
      analysisProgress: 0
    });
    
    // Start scanning process in the background
    scanRepositoryBackground(
      createdRepo.id,
      repoPath,
      usePatternDetection,
      useSnyk
    );
    
    return createdRepo.id;
  } catch (error) {
    console.error('Error starting repository scan:', error);
    throw error;
  }
}

async function scanRepositoryBackground(
  repositoryId: number,
  repoPath: string,
  usePatternDetection: boolean,
  useSnyk: boolean
): Promise<void> {
  try {
    const vulnerabilities: InsertVulnerability[] = [];
    
    // Pattern detection for all supported languages
    if (usePatternDetection) {
      updateScanProgress(repositoryId, { status: 'pattern_detection' });
      
      // Scan all supported languages (Java, Python, JavaScript, TypeScript)
      const supportedLanguages = ['java', 'python', 'javascript', 'typescript'];
      const results = await scanRepositoryCode(repoPath, supportedLanguages);
      
      // Update progress incrementally during the scan (simulated)
      for (let progress = 0; progress <= 100; progress += 5) {
        updateScanProgress(repositoryId, { patternDetectionProgress: progress });
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      // Convert to our vulnerability format
      for (const result of results) {
        vulnerabilities.push({
          repositoryId,
          title: result.pattern.name,
          description: result.pattern.description,
          severity: result.pattern.severity,
          filePath: result.filePath,
          lineNumber: result.line,
          detectedBy: 'pattern',
          originalCode: result.matchedCode,
          fixedCode: result.fixedCode,
          language: result.language
        });
      }
      
      updateScanProgress(repositoryId, { patternDetectionProgress: 100 });
    }
    
    // Snyk scanning
    if (useSnyk) {
      updateScanProgress(repositoryId, { status: 'snyk_scanning' });
      
      // Scan with Snyk
      const snykVulnerabilities = await scanWithSnyk(repoPath);
      
      // Update progress incrementally during Snyk scan (simulated)
      for (let progress = 0; progress <= 100; progress += 10) {
        updateScanProgress(repositoryId, { snykProgress: progress });
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      // Convert Snyk vulnerabilities to our format
      for (const vulnerability of snykVulnerabilities) {
        vulnerabilities.push({
          repositoryId,
          title: vulnerability.title,
          description: vulnerability.description,
          severity: vulnerability.severity,
          filePath: vulnerability.filePath,
          lineNumber: vulnerability.lineNumber,
          detectedBy: 'snyk',
          originalCode: vulnerability.originalCode,
          fixedCode: vulnerability.fixedCode
        });
      }
    }
    
    // Analyzing results
    updateScanProgress(repositoryId, { 
      status: 'analyzing', 
      snykProgress: 100 
    });
    
    // Simulate analysis progress
    for (let progress = 0; progress <= 100; progress += 20) {
      updateScanProgress(repositoryId, { analysisProgress: progress });
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    // Save all vulnerabilities
    for (const vulnerability of vulnerabilities) {
      await storage.createVulnerability(vulnerability);
    }
    
    // Update repository status
    await storage.updateRepositoryStatus(repositoryId, 'completed');
    
    // Update progress
    updateScanProgress(repositoryId, { 
      status: 'completed', 
      analysisProgress: 100 
    });
    
    // Cleanup
    await cleanupRepository(repoPath);
    
  } catch (error) {
    console.error(`Error scanning repository ${repositoryId}:`, error);
    
    // Update repository status
    await storage.updateRepositoryStatus(repositoryId, 'failed');
    
    // Update progress
    updateScanProgress(repositoryId, { status: 'failed' });
    
    // Try to cleanup
    try {
      await cleanupRepository(repoPath);
    } catch (cleanupError) {
      console.error('Error during cleanup:', cleanupError);
    }
  }
}

function updateScanProgress(
  repositoryId: number, 
  update: Partial<ScanProgress>
): void {
  const progress = scanProgress.get(repositoryId);
  
  if (progress) {
    scanProgress.set(repositoryId, { ...progress, ...update });
  }
}
