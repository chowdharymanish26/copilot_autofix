import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Repository schema
export const repositories = pgTable("repositories", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  name: text("name").notNull(),
  owner: text("owner").notNull(),
  scannedAt: timestamp("scanned_at"),
  status: text("status").notNull().default("pending"),
});

export const insertRepositorySchema = createInsertSchema(repositories).pick({
  url: true,
  name: true,
  owner: true,
});

// Vulnerability schema
export const vulnerabilities = pgTable("vulnerabilities", {
  id: serial("id").primaryKey(),
  repositoryId: integer("repository_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull(), // critical, high, moderate
  filePath: text("file_path").notNull(),
  lineNumber: integer("line_number").notNull(),
  detectedBy: text("detected_by").notNull(), // pattern, snyk, both
  originalCode: text("original_code").notNull(),
  fixedCode: text("fixed_code").notNull(),
  status: text("status").notNull().default("pending"), // pending, accepted, rejected
  language: text("language"), // java, python, javascript, typescript
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilities).pick({
  repositoryId: true,
  title: true,
  description: true,
  severity: true,
  filePath: true,
  lineNumber: true,
  detectedBy: true,
  originalCode: true,
  fixedCode: true,
  language: true,
});

// Repository scan types
export const scanRequestSchema = z.object({
  url: z.string().url("Please enter a valid GitHub URL"),
  usePatternDetection: z.boolean().default(true),
  useSnyk: z.boolean().default(true),
});

export type ScanRequest = z.infer<typeof scanRequestSchema>;
export type Repository = typeof repositories.$inferSelect;
export type InsertRepository = z.infer<typeof insertRepositorySchema>;
export type Vulnerability = typeof vulnerabilities.$inferSelect;
export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;
